sap.ui.define([
	'sap/m/ComboBox',
	'sap/m/ComboBoxBase'
],
	function(
		SAPComboBox,
		SAPComboBoxBase
	) {
		"use strict";

		var ComboBox = SAPComboBox.extend("com.ecolab.ZASBMasterAgr.custom.ComboBox", /** @lends sap.m.ComboBox.prototype */ {
			metadata: {
				properties: {},
				associations: {},
				events: {}
			}
		});
		
		ComboBox.prototype.init = function() {
			SAPComboBox.prototype.init.call(this);
		};
		
		ComboBox.prototype.oninput = function(oEvent) {
			SAPComboBoxBase.prototype.oninput.apply(this, arguments);

			// note: input event can be buggy
			// @see sap.m.InputBase#oninput
			if (oEvent.isMarked("invalid")) {
				return;
			}

			var aItems = this.getItems(),
				oInputDomRef = oEvent.target,
				sValue = oInputDomRef.value,
				bVisibleItems = false,
				oItem,
				bMatch,
				i = 0;

			for (; i < aItems.length; i++) {

				// the item match with the value
				oItem = aItems[i];
				bMatch = (oItem.getText().toLowerCase().indexOf(sValue.toLowerCase()) !== -1 || oItem.getAdditionalText().toLowerCase().indexOf(sValue.toLowerCase()) !== -1)?true:false;

				if (sValue === "") {
					bMatch = true;
				}

				this._setItemVisibility(oItem, bMatch);

				if (bMatch && !bVisibleItems) {
					bVisibleItems = true;
				}
			}
			// open the picker on input
			if (bVisibleItems) {
				this.open();
			} else {
				this.isOpen() ? this.close() : this.clearFilter();
			}
		};
		
		return ComboBox;

	});
