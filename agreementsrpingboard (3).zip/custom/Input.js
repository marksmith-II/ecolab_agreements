/*!
 * Custom ComboBox with table view in dropdown
 */

sap.ui.define(['jquery.sap.global', 'sap/m/Input', 'sap/m/Table'],
	function(jQuery, SAPInput, Table) {
		"use strict";

		var Input = SAPInput.extend("com.ecolab.ZASBMasterAgr.custom.Input", /** @lends sap.m.Input.prototype */ { metadata: {
			properties: {
			},
			aggregations : {},
			associations: {},
			events: {}
		}});

		/* =========================================================== */
		/* Private methods and properties                              */
		/* =========================================================== */
		/**
		 * Initializes the control
		 */
		Input.prototype.init = function() {
			SAPInput.prototype.init.call(this);
		};
		
		/* lazy loading of the suggestions table */
		Input.prototype._getSuggestionsTable = function() {
			var that = this;
	
			if (!this._oSuggestionTable) {
				this._oSuggestionTable = new Table({
					mode: sap.m.ListMode.SingleSelectMaster,
					showNoData: false,
					showSeparators: "All",
					width: "100%",
					growing: "true",
					growingThreshold: 1000,
					growingScrollToLoad:true,
					enableBusyIndicator: false,
					rememberSelections : false,
					selectionChange: function (oEvent) {
						var oSelectedListItem = oEvent.getParameter("listItem");
						that.setSelectionRow(oSelectedListItem, true);
					}
				});
				// initially hide the table on phone
				if (this._bUseDialog) {
					this._oSuggestionTable.addStyleClass("sapMInputSuggestionTableHidden");
				}
	
				this._oSuggestionTable.updateItems = function() {
					Table.prototype.updateItems.apply(this, arguments);
					that._refreshItemsDelayed();
					return this;
				};
			}
	
			return this._oSuggestionTable;
		};

		return Input;

	}, /* bExport= */ true);
