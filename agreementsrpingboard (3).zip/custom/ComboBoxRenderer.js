/*!
 * TBD
 */

// Provides default renderer for control sap.m.Input
sap.ui.define(['jquery.sap.global', 'sap/m/ComboBoxRenderer', 'sap/ui/core/Renderer'],
	function(jQuery, SAPComboBoxRenderer, Renderer) {
	"use strict";


	/**
	 * Renderer for the sap.ui.commons.Input
	 * @namespace
	 */
	var ComboBoxRenderer = Renderer.extend(SAPComboBoxRenderer);

	return ComboBoxRenderer;

}, /* bExport= */ true);
