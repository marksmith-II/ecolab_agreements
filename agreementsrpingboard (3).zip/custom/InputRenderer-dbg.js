/*!
 * TBD
 */

// Provides default renderer for control sap.m.Input
sap.ui.define(['jquery.sap.global', 'sap/m/InputRenderer', 'sap/ui/core/Renderer'],
	function(jQuery, SAPInputRenderer, Renderer) {
	"use strict";


	/**
	 * Renderer for the sap.ui.commons.Input
	 * @namespace
	 */
	var InputRenderer = Renderer.extend(SAPInputRenderer);

	return InputRenderer;

}, /* bExport= */ true);
