sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"com/ecolab/ZASBMasterAgr/model/models",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/ecolab/ZASBMasterAgr/controller/ErrorHandler"
], function (UIComponent, JSONModel, Device, models, Filter, FilterOperator, ErrorHandler) {
	"use strict";
	return UIComponent.extend("com.ecolab.ZASBMasterAgr.Component", {
		metadata: {
			manifest: "json"
		},

		init: function () {
			UIComponent.prototype.init.apply(this, arguments);
			// this.setModel(this.createDeviceModel(), "device");
			this.getRouter().initialize();

			// initialize the error handler with the component
			this._oErrorHandler = new ErrorHandler(this);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			//Set the Filter Model
			this.setModel(models.createFdModel(), "filterModel");
			
			// model to maintain wheather it is routed with MA# or Revision# to Display view from Master View
			var oMARevisionRoutingModel = new JSONModel({
				"IsRoutedWithMANum":false,
				"IsRoutedWithRevisionNum":false
			});
			this.setModel(oMARevisionRoutingModel, "MARevisionRoutingModel");
			
			//local model to maintain wheather the next button is clicked or not in the Edit view
			//By using this flag we are setting selectedKey for Icon Tab Bar on the load or on click Next btn
			var oBtnModel = new JSONModel({
				"IsNextBtnPressed":false
			});
			this.setModel(oBtnModel, "NextBtnModel");
			
			//Set the ProductsFilter Model
			this.setModel(models.createProductModel(), "ProductsFilter");
			
			//Set the MSL Pricing Filter Model M. Smith
			this.setModel(models.createMslPricingModel(), "MslFilter");
			
			//Set the MSL Hidden Model M. Smith
			this.setModel(models.createMslHiddenFieldModel(), "MslHidden");
			
			//Set the DistBuyPriceFilter Model
			this.setModel(models.createDistBuyPriceModel(), "DistBuyPriceFilter");
			
			this.setModel(models.createProductStatusModel(), "ProdStatusModel");

			// to get the Status field values in Products table filter dialog

			var oModel = this.getModel();
			var ProdStatusModel = this.getModel("ProdStatusModel");
			oModel.read("/SelectSet(EntityName='MaterialValueHelp',ComplexType='',EntityProperty='Status')", {
				urlParameters: {
					'$expand': 'FieldProperties/KeyValueSet'
				},
				success: function (oData) {
					ProdStatusModel.setProperty("/StatusList", oData.FieldProperties.KeyValueSet.results);
				},
				error: function (oError) {
					//To do - Errorhandler
				}
			});

			//Products Filter Dialogue Condition Data. We are creating this model at component mode
			//because it is used in both display and edit
			var oConditionModel = new JSONModel();
			this.setModel(oConditionModel, "ConditionModel");
			var sPath = "/SelectSet(EntityName='Product',ComplexType='',EntityProperty='ConditionKey')";
			var oAddEmptyRowFilter = new Filter("AddEmptyRow", FilterOperator.EQ, true);
			var oModel = this.getModel();

			oModel.read(sPath, {
				filters: [oAddEmptyRowFilter],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oConditionModel.setProperty("/Product", oData);
					oConditionModel.updateBindings(true);
				},
				error: function (oError) {
					sap.m.MessageToast.show(oError);
				}
			});
			
			//MSL Tier ID Filter Dialogue  Data. We are creating this model at component mode
			//because it is used in both display and edit M.Smith
			var oTierIDModel = new JSONModel();
			this.setModel(oTierIDModel, "TierIDModel");
			var sPath2 = "/SelectSet(EntityName='MSLPrice',ComplexType='',EntityProperty='TierID')";
			var oAddEmptyRowFilter2 = new Filter("AddEmptyRow", FilterOperator.EQ, true);
			var oModel2 = this.getModel();

			oModel2.read(sPath2, {
				filters: [oAddEmptyRowFilter2],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oTierIDModel.setProperty("/MSLPrice", oData);
					oTierIDModel.updateBindings(true);
				},
				error: function (oError) {
					sap.m.MessageToast.show(oError);
				}
			});

			//FlatFee condition types
			sPath = "/SelectSet(EntityName='FlatFee',ComplexType='',EntityProperty='ConditionKey')";
			var ApplicationFilter = new Filter("Application", "EQ", "V");
			var ConditionTypeFilter = new Filter([new Filter("ConditionType", "EQ", "ZFTP"), new Filter("ConditionType", "EQ", "Z1MP")], false);
			var ConditionTableFilter = new Filter([new Filter("ConditionTable", "EQ", "758"), new Filter("ConditionTable", "EQ", "668")], false);
			var oFliters = new Filter([ApplicationFilter, ConditionTypeFilter, ConditionTableFilter], true);
			oModel.read(sPath, {
				filters: [oFliters],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oConditionModel.setProperty("/FlatFee", oData);
					oConditionModel.updateBindings(true);
				},
				error: function (oError) {}
			});

			//DiscountsOff condition types
			sPath = "/SelectSet(EntityName='DiscountOff',ComplexType='',EntityProperty='ConditionKey')";
			ApplicationFilter = new Filter("Application", "EQ", "V");
			ConditionTypeFilter = new Filter("ConditionType", "EQ", "Z1PD");
			ConditionTableFilter = new Filter([new Filter("ConditionTable", "EQ", "758"), new Filter("ConditionTable", "EQ", "657")], false);
			oFliters = new Filter([ApplicationFilter, ConditionTypeFilter, ConditionTableFilter], true);
			oModel.read(sPath, {
				filters: [oFliters],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oConditionModel.setProperty("/DiscountOff", oData);
					oConditionModel.updateBindings(true);
				},
				error: function (oError) {
					sap.m.MessageToast.show(oError);
				}
			});

			//OnInvoiceDiscounts condition types
			sPath = "/SelectSet(EntityName='OnInvoiceDiscount',ComplexType='',EntityProperty='ConditionKey')";
			ApplicationFilter = new Filter("Application", "EQ", "V");
			ConditionTypeFilter = new Filter([new Filter("ConditionType", "EQ", "Z1VL"), new Filter("ConditionType", "EQ", "Z1VR")], false);
			ConditionTableFilter = new Filter([new Filter("ConditionTable", "EQ", "976"),
				new Filter("ConditionTable", "EQ", "654"),
				new Filter("ConditionTable", "EQ", "758"),
				new Filter("ConditionTable", "EQ", "657")
			], false);
			oFliters = new Filter([ApplicationFilter, ConditionTypeFilter, ConditionTableFilter], true);
			oModel.read(sPath, {
				filters: [oFliters],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oConditionModel.setProperty("/OnInvoiceDiscount", oData);
					oConditionModel.updateBindings(true);
				},
				error: function (oError) {
					sap.m.MessageToast.show(oError);
				}
			});

			oModel.refresh();
		},

		/**
		 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
		 * design mode class should be set, which influences the size appearance of some controls.
		 * @public
		 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
		 */
		getContentDensityClass: function () {
			if (this._sContentDensityClass === undefined) {

				// check whether FLP has already set the content density class; do nothing in this case
				if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {

					this._sContentDensityClass = "";

				} else if (!Device.support.touch) { // apply "compact" mode if touch is not supported

					this._sContentDensityClass = "sapUiSizeCompact";

				} else {

					// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
					this._sContentDensityClass = "sapUiSizeCozy";

				}
			}

			return this._sContentDensityClass;
		}

	});

});