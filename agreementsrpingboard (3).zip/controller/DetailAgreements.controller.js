sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"com/ecolab/ZASBMasterAgr/model/formatter"
], function (UIComponent, Controller, JSONModel, Filter, Sorter, FilterOperator, formatter) {
	"use strict";
	return Controller.extend("com.ecolab.ZASBMasterAgr.controller.DetailAgreements", {
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the MasterAgreements controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var me = this;
			me._oRouter = UIComponent.getRouterFor(me);
			me._oRouter.getRoute("DetailAgreements").attachPatternMatched(this._onDetailAgreementMatched, this);
			/**************Detail Header Info Model*******************/
			var oDetailHeaderInfo = new JSONModel();
			me.getView().setModel(oDetailHeaderInfo, "DetailHeaderInfo");

			me.IsBulkFrieghtChanged = false;
			me.IsOrigAgrChanged = false;
			me.IsBidChanged = false;
			// User Status values for  displaying edit Link in Display Screen
			this.E001 = "E0001";
			this.E002 = "E0002";
			this.E005 = "E0005";
			this.E006 = "E0006";
			
		    /**********MSL Hidden Fields Model ******/
            var oModel = this.getOwnerComponent().getModel("MslHidden");
			var oData2 = {
				"HiddenField": false
				
			};
			// Check if there is MSL number, if MSL number than show Hidden field if not hide. 
			
			
			oModel.setData(oData2);	

		},

		/*
		 * @param oEvent - the click event.
		 * Here we also cehcking the Authorization by calling the CheckAuthorization function import 
		 * Navigates to EditAgreementView With DocumentNumber/RevisionNumber as a Parameter
		 */
		onEditHeaderInfoPress: function (oEvent) {

			var that = this;
			var oView = that.getView();
			var urlParam;
			var oControl = oEvent.getSource();
			var oContext = oControl.getBindingContext().getObject();
			var oAdminFields = oContext.AdminFields;
			var oValueFields = oContext.ValueFields;
			var oDocumentType = oContext.ValueFields.DocumentType;
			var oRevisionType = oContext.ValueFields.RevisionType;
			var oRevisionNumber = oContext.ValueFields.RevisionNumber;
			var oDataModel = oView.getModel();
			var NextBtnModel = that.getOwnerComponent().getModel("NextBtnModel");
			if (oContext.AdminFields.IsRevision) {
				if (oContext.AdminFields.HasActiveRevision) {
					urlParam = {
						Activity: "03",
						DocumentType: oRevisionType
					};
				} else {
					urlParam = {
						Activity: "01",
						DocumentType: "ACR"
					};
				}

			} else {
				urlParam = {
					Activity: "02",
					DocumentType: oDocumentType
				};
			}
			oDataModel.callFunction("/CheckAuthorization", {
				method: "POST",
				urlParameters: urlParam,
				success: function (oData, response) {
					oDataModel.callFunction("/CheckEditAccess", {
						method: "POST",
						urlParameters: {
							DocumentNumber: oRevisionNumber
						},
						success: function (odata, oRes) {
							NextBtnModel.setProperty("/IsNextBtnPressed", false);
							// Here we have used UserStatus value as a condition for navigation and Display of Edit link Text
							if (oAdminFields.IsEditable === false && oAdminFields.HasActiveRevision === false) {
								that._oRouter.navTo("EditAgreement", {
									DetailAgreementId: that.sDocumentNumber
								}, false);
							} else if ((oAdminFields.IsEditable === false && oAdminFields.HasActiveRevision === true && oAdminFields.IsRevision ===
									false) &&
								(oAdminFields.UserStatus === that.E001 || oAdminFields.UserStatus === that.E005 || oAdminFields.UserStatus === that.E006 ||
									oAdminFields.UserStatus === that.E002)) {
								that._oRouter.navTo("DetailAgreements", {
									DocumentNumber: oValueFields.RevisionNumber
								}, false);
							} else if ((oAdminFields.IsEditable === true && oAdminFields.HasActiveRevision === true && oAdminFields.IsRevision ===
									false) &&
								(oAdminFields.UserStatus === that.E001 || oAdminFields.UserStatus === that.E005 || oAdminFields.UserStatus === that.E006)
							) {
								that._oRouter.navTo("EditAgreement", {
									DetailAgreementId: oValueFields.RevisionNumber
								}, false);
							} else if (oAdminFields.IsEditable === true && oAdminFields.HasActiveRevision === true && oAdminFields.IsRevision ===
								false &&
								oAdminFields.UserStatus === that.E002) {
								that._oRouter.navTo("DetailAgreements", {
									DocumentNumber: oValueFields.RevisionNumber
								}, false);
							} else if ((oAdminFields.IsEditable === true && oAdminFields.IsRevision === true) && (oAdminFields.UserStatus === that.E001 ||
									oAdminFields.UserStatus === that.E005 || oAdminFields.UserStatus === that.E006)) {
								that._oRouter.navTo("EditAgreement", {
									DetailAgreementId: oValueFields.RevisionNumber
								}, false);
							}
						},
						error: function (oError) {}
					});
				},
				error: function (oError) {}
			});

		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onDetailAgreementMatched: function (oEvent) {
			var oView = this.getView();
			if (oEvent.getParameter("name") === "DetailAgreements") {
				this.sDocumentNumber = oEvent.getParameter("arguments").DocumentNumber;
				//Making FLP Backbutton visible as it was hidden in the first page
				sap.ui.getCore().byId("backBtn").setVisible(true);
				this._bindView("/HeaderSet('" + this.sDocumentNumber + "')", this.sDocumentNumber);

				//rebind Flat Fee smart table 
				oView.byId("idFlatFeeTable").rebindTable(true);

				//rebind OnInvoiceDiscount smart table 
				oView.byId("idInvoiceDiscountsTable").rebindTable(true);

				//rebind DiscountOff List smart table 
				oView.byId("idDiscountsOffListTable").rebindTable(true);

				//rebind Regional smart table 
				oView.byId("idRegionalTable").rebindTable(true);

				//rebind FuelSurcharge smart table 
				oView.byId("idFuelSurchargeTable").rebindTable(true);

				//rebind PickupAllowance smart table 
				oView.byId("idPickupAllowanceTable").rebindTable(true);

				//rebind MinimumOrder smart table 
				oView.byId("idMiniOrderTable").rebindTable(true);

				//rebind PrepayAndAddFrieght smart table 
				oView.byId("idPrepayAndAddFrieght").rebindTable(true);

				//rebind MSNL Pricing smart table 
				oView.byId("idMSLTable").rebindTable(true);

				//Attachments related 
				var arrAtchmntFilters = [];

				//Funtion to update productsset table title with total products/material count.
				this.updateProductSetCount();

				//Funtion to update PriceException table title with total PriceExceptions/material count.
				this.updatePriceExceptionSetCount();

				//Funtion to update FlatFee table title with total Flatfees/material count.
				this.updateFlatFeeSetCount();

				//Funtion to update MSL Pricing table title with total MSL Pricing count.
				this.updateMslPricingCount();

				//Funtion to update DistBuyPrice table title with total DistBuyPrice count.
				this.updateDistBuyPriceSetCount();

				arrAtchmntFilters.push(
					new Filter({
						path: "ObjectNumber",
						operator: "EQ",
						value1: this.sDocumentNumber
					}));
				oView.byId("idMAAtchmntsUploadCollection").getBinding("items").filter(arrAtchmntFilters);
			}
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function (sObjectPath, sDocumentNumber) {
			var oView = this.getView();

			oView.bindElement({
				path: sObjectPath,
				parameters: {
					expand: "ManagementNoteSet"
				}
			});

			var aFilters = [];
			aFilters.push(new Filter("DocumentNumber", "EQ", sDocumentNumber));

			//ProductSetTable - Getting Products table items by passing DocumentNumber as a filter
			oView.byId("idProductsTbl").getBinding("items").filter(aFilters);

			//DistBuyPriceSetTable - Getting Distributor Buy Price table items by passing DocumentNumber as a filter
			oView.byId("IdDistributorBuyPrice").getBinding("items").filter(aFilters);
			//RebateSetTable - Getting Incentives & Rebate table items by passing DocumentNumber as a filter
			oView.byId("idIncentivesTbl").getBinding("items").filter(aFilters);
			//PriceExceptionSetTable - Getting Direct Customer Price Exception table items by passing DocumentNumber as a filter
			oView.byId("idPriceExceptionTbl").getBinding("items").filter(aFilters);
			//AuthDistributorSet Table - Getting Distribution table items by passing DocumentNumber as a filter
			oView.byId("idDistributionTable").getBinding("items").filter(aFilters);
			//AssetSetTable - Getting Asset table items by passing DocumentNumber as a filter
			oView.byId("idAssetMagtTable").getBinding("items").filter(aFilters);
			this.getView().getModel().refresh();
		},
		/**
		 * Function is called when rebind the Flat Fee,InVoiceDiscount,DiscountOffList smart tables .
		 * Method to populate on Smart table filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onBeforeRebindTable: function (oEvent) {

			// Get bindingParams Object, which includes filters
			var oBindingParams = oEvent.getParameter("bindingParams");
			oBindingParams.filters.push(new Filter("DocumentNumber", "EQ", this.sDocumentNumber));
		},
		/**
		 * Function is called when rebind the Regional smart table .
		 * Method to populate on Smart table filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onBeforeRebindRegionalTable: function (oEvent) {

			// Get bindingParams Object, which includes filters
			var oBindingParams = oEvent.getParameter("bindingParams");
			var oRegionalFilters = new Filter([new Filter("DocumentNumber", "EQ", this.sDocumentNumber), new Filter("ConditionType",
				FilterOperator.EQ, "Z1AL")], true);
			oBindingParams.filters.push(oRegionalFilters);
		},

		/**
		 * Function is called when rebind the FuelSurcharge smart table .
		 * Method to populate on Smart table filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onBeforeRebindFuelSurchargeTable: function (oEvent) {

			// Get bindingParams Object, which includes filters
			var oBindingParams = oEvent.getParameter("bindingParams");
			var oConditionTypeFilters = new Filter([
				new Filter("ConditionType", FilterOperator.EQ, "Z1FS"),
				new Filter("ConditionType", FilterOperator.EQ, "Z1BC"),
				new Filter("ConditionType", FilterOperator.EQ, "Z1F9"),
				new Filter("ConditionType", FilterOperator.EQ, "Z1F1")
			], false);
			var oFuelSurchargeFilters = new Filter([
				new Filter("DocumentNumber", "EQ", this.sDocumentNumber),
				oConditionTypeFilters
			], true);

			oBindingParams.filters.push(oFuelSurchargeFilters);
		},

		/**
		 * Function is called when rebind the PickUpAllowance smart table .
		 * Method to populate on Smart table filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onBeforeRebindPickUpAllowTable: function (oEvent) {

			// Get bindingParams Object, which includes filters
			var oBindingParams = oEvent.getParameter("bindingParams");
			var oPickupAllowFilters = new Filter([new Filter("DocumentNumber", "EQ", this.sDocumentNumber), new Filter("ConditionType",
				FilterOperator.EQ, "Z1PU")], true);
			oBindingParams.filters.push(oPickupAllowFilters);
		},

		/**
		 * Function is called when rebind the Minimum Order Charge smart table .
		 * Method to populate on Smart table filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onBeforeRebindMiniOrderTable: function (oEvent) {

			// Get bindingParams Object, which includes filters 
			var oBindingParams = oEvent.getParameter("bindingParams");
			var ConditionTypeFilters = new Filter([
					new Filter("ConditionType", FilterOperator.EQ, "Z1H1"),
					new Filter("ConditionType", FilterOperator.EQ, "Z1H2"),
					new Filter("ConditionType", FilterOperator.EQ, "Z1H3"),
					new Filter("ConditionType", FilterOperator.EQ, "Z1H5"),
					new Filter("ConditionType", FilterOperator.EQ, "Z1H7"),
					new Filter("ConditionType", FilterOperator.EQ, "Z1H6")
				],
				false);
			var oPickupAllowFilters = new Filter([new Filter("DocumentNumber", "EQ", this.sDocumentNumber), ConditionTypeFilters], true);
			oBindingParams.filters.push(oPickupAllowFilters);
		},

		/**
		 * Function is called when rebind the PrepayAndAddFrieght smart table .
		 * Method to populate on Smart table filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onBeforePrepayAndAddFrieghtTable: function (oEvent) {

			// Get bindingParams Object, which includes filters 
			var oBindingParams = oEvent.getParameter("bindingParams");
			var ConditionTypeFilters = new Filter([
					new Filter("ConditionType", FilterOperator.EQ, "Z1PA")
				],
				false);
			var oPrepayAndAddFrieghtFilters = new Filter([new Filter("DocumentNumber", "EQ", this.sDocumentNumber), ConditionTypeFilters], true);
			oBindingParams.filters.push(oPrepayAndAddFrieghtFilters);
		},

		onBeforeRebindMsnlTable: function (oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");
			var oMslFilters = new Filter("DocumentNumber", "EQ", this.sDocumentNumber);
			oBindingParams.filters.push(oMslFilters);
		},

		/**
		 * Method to populate Sort dialog & Filter dialog in Pricing Section
		 * @private
		 */
		_getProdSortAndFilterDialog: function () {
			if (!this._oProdSortAndFilterDialog) {
				this._oProdSortAndFilterDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.ProductsSortAndFilter", this);
				this.getView().addDependent(this._oProdSortAndFilterDialog);
				var oModel = this.getOwnerComponent().getModel("ProductsFilter");
				var oData = {
					"MaterialNum": "",
					"MaterialDesc": "",
					"Condition": undefined,
					"ConditionVal": "",
					"FreightIncl": false,
					"OnOrigAgr": false,
					"Bid": false,
					"MaterialSearch": {
						"MaterialNum": "",
						"MaterialDesc": "",
						"Status": "",
						"SelectedStatuses": [],
						"StatusList": [],
						"MaterialList": [],
						"MaterialValueHelpSet": [],
						"tableBusy": false
					},
					"Status": ""
				};
				oModel.setData(oData);
			}
			this._oProdSortAndFilterDialog._getNavContainer().attachAfterNavigate({}, function (evt) {
				if (evt.getParameter("isBack")) {
					this._oProdSortAndFilterDialog._getDialog().setContentWidth("auto");
				}
			}, this);

			return this._oProdSortAndFilterDialog;
		},
		/**
		 * Method to populate Sort dialog & Filter dialog in MSL Pricing Section
		 * @private M.Smith
		 */
		_getMSLSortAndFilterDialog: function () {
			if (!this._oMSLSortAndFilterDialog) {
				this._oMSLSortAndFilterDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.MslSortAndFilter", this);
				this.getView().addDependent(this._oMSLSortAndFilterDialog);
				var oModel = this.getOwnerComponent().getModel("MslFilter");
				var oData = {
					"MaterialNumber": "",
					"MaterialDesc": "",
					"TierID": "",
					"TierRate": "",
					"Condition": undefined,
					"ConditionVal": "",
					"FreightIncl": false,
					"OnOrigAgr": false,
					"Bid": false,
					"MaterialSearch": {
						"MaterialNumber": "",
						"MaterialDesc": "",
						"TierID": "",
						"TierRate": "",
						"SelectedStatuses": [],
						"StatusList": [],
						"MaterialList":[],
						"MaterialValueHelpSet": [],
						"tableBusy": false
					}
				};
				oModel.setData(oData);
			}
			this._oMSLSortAndFilterDialog._getNavContainer().attachAfterNavigate({}, function (evt) {
				if (evt.getParameter("isBack")) {
					this._oMSLSortAndFilterDialog._getDialog().setContentWidth("auto");
				}
			}, this);

			return this._oMSLSortAndFilterDialog;
		},
		/**
		 * Function is called when you click on Sort Button & Filter Button.
		 * Method to populate Sort dialog & Filter dialog
		 * @private 
		 */
		ProductsSortAndFilterPress: function (oEvent) {
			var oSource = oEvent.getSource();
			var oCustomData = oSource.data("SortKey");
			var ProductsFilterModel = this.getOwnerComponent().getModel("ProductsFilter");
			ProductsFilterModel.checkUpdate(true);
			if (oCustomData === "Sort") {
				this._getProdSortAndFilterDialog().open("sort");
			} else {
				this._getProdSortAndFilterDialog().open("filter");

			}
			this._oProdSortAndFilterDialog._getDialog().setContentWidth("350px");
			this._oProdSortAndFilterDialog.setModel(this.getView().getModel());
			this._oProdSortAndFilterDialog.setModel(sap.ui.getCore().getModel("i18n"), "i18n");
		},
		/*
		 * Function is called when you click on Sort Button & Filter Button.
		 * Method to populate Sort dialog & Filter dialog
		 * @private M.Smith
		 */
		MSLSortAndFilterPress: function (oEvent) {
			var oSource = oEvent.getSource();
			var oCustomData = oSource.data("SortKey");
			var MslFilterModel = this.getOwnerComponent().getModel("MslFilter");
			MslFilterModel.checkUpdate(true);
			if (oCustomData === "Sort") {
				this._getMSLSortAndFilterDialog().open("sort");
			} else {
				this._getMSLSortAndFilterDialog().open("filter");

			}
			this._oMSLSortAndFilterDialog._getDialog().setContentWidth("350px");
			this._oMSLSortAndFilterDialog.setModel(this.getView().getModel());
			this._oMSLSortAndFilterDialog.setModel(sap.ui.getCore().getModel("i18n"), "i18n");
		},

		/**
		 * Method to populate Sort dialog & Filter dialog in Pricing Section
		 * @private
		 */
		_getDistBuyPriceSortDialog: function () {
			if (!this._oDistBuyPriceSortDialog) {
				this._oDistBuyPriceSortDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.DistBuyPriceSortDialog", this);
				this.getView().addDependent(this._oDistBuyPriceSortDialog);

				var oModel = this.getOwnerComponent().getModel("DistBuyPriceFilter");
				var oData = {
					"MaterialNum": "",
					"MaterialDesc": "",
					"DistributorNumber": "",
					"DistributorDesc": "",
					"MaterialSearch": {
						"MaterialNum": "",
						"MaterialDesc": "",
						"Status": "",
						"SelectedStatuses": [],
						"StatusList": [],
						"MaterialList": [],
						"MaterialValueHelpSet": [],
						"tableBusy": false
					},
					"Status": ""
				};
				oModel.setData(oData);
			}

			return this._oDistBuyPriceSortDialog;
		},

		/**
		 * Function is called when you click on Sort Button.
		 * Method to populate Sort dialog
		 * @private
		 */
		DistBuyPriceSortPress: function (oEvent) {

			var oSource = oEvent.getSource();
			var oCustomData = oSource.data("SortKey");
			var DistBuyPriceFilterModel = this.getOwnerComponent().getModel("DistBuyPriceFilter");
			DistBuyPriceFilterModel.checkUpdate(true);
			if (oCustomData === "Sort") {
				this._getDistBuyPriceSortDialog().open("sort");
			} else {
				this._getDistBuyPriceSortDialog().open("filter");
			}
			// this._getDistBuyPriceSortDialog().open("sort");
			this._oDistBuyPriceSortDialog._getDialog().setContentWidth("350px");
			this._oDistBuyPriceSortDialog.setModel(sap.ui.getCore().getModel("i18n"), "i18n");
		},

		/*
		 * Function is called when click on Ok Button in Dist Sort.
		 * Method to do  Sort operations and close the Sort Dialogue
		 * @param {oEvent} - the click event.
		 * @private
		 */
		onDistBuyPriceSortConfirm: function (oEvent) {

			var aFilters = [];
			var oStatusFilter = [];
			var oTable = this.getView().byId("IdDistributorBuyPrice"); //
			var oBinding = oTable.getBinding("items");

			//Sorting
			var mParams = oEvent.getParameters();
			var sPath;
			var bDescending;
			var aSorters = [];
			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));
			}
			oBinding.sort(aSorters);
			var DistBuyPriceFilterModel = this.getOwnerComponent().getModel("DistBuyPriceFilter");
			var oMaterialDesc = DistBuyPriceFilterModel.getProperty("/MaterialDesc");
			var oDistNmuner = DistBuyPriceFilterModel.getProperty("/DistributorNumber");
			var oDistDesc = DistBuyPriceFilterModel.getProperty("/DistributorDesc");

			var oStatus = DistBuyPriceFilterModel.getProperty("/Status");
			var aMaterialList = DistBuyPriceFilterModel.getProperty("/MaterialSearch/MaterialList");
			DistBuyPriceFilterModel.setProperty("/IsFiltered", "Default");
			if (aMaterialList.length !== 0) {
				var MatFilter;
				for (var idx = 0; idx < aMaterialList.length; idx++) {
					MatFilter = new Filter("MaterialNumber", FilterOperator.EQ, aMaterialList[idx]);
					aFilters.push(MatFilter);
				}
				this._handleDistBuyPriceFilterIcon();
			}
			if (oMaterialDesc !== "") {
				var oFilter2 = new Filter("MaterialDesc", "Contains", oMaterialDesc);
				aFilters.push(oFilter2);
				this._handleDistBuyPriceFilterIcon();
			}
			if (oDistNmuner !== "") {
				var oFilter3 = new Filter("DistributorNumber", "Contains", oDistNmuner);
				aFilters.push(oFilter3);
				this._handleDistBuyPriceFilterIcon();
			}
			if (oDistDesc !== "") {
				var oFilter4 = new Filter("DistributorDesc", "Contains", oDistDesc);
				aFilters.push(oFilter4);
				this._handleDistBuyPriceFilterIcon();
			}

			if (oStatus !== "" && oStatus.length !== 0) {
				for (var j = 0; j < oStatus.length; j++) {
					var oFilter7 = new Filter("UserStatus", FilterOperator.EQ, oStatus[j]);
					oStatusFilter.push(oFilter7);
				}
				var statusFilter = new Filter({
					filters: oStatusFilter,
					and: false
				});
				aFilters.push(statusFilter);
				this._handleDistBuyPriceFilterIcon();
			}
			aFilters.push(new Filter("DocumentNumber", "EQ", this.sDocumentNumber));
			oBinding.filter(aFilters);
			this.getOwnerComponent().getModel("DistBuyPriceFilter").updateBindings(true);
		},

		/*
		 * Function is called when changing Bulk switch in Products Sort&Filter Dialogue .
		 * Method to know whether any user interaction has happened on bulk switch
		 * @param {oEvent} - the click event.
		 * @private
		 */
		onChangeBulkFrieght: function () {
			this.IsBulkFrieghtChanged = true;
		},
		/*
		 * Function is called when changing Orig. Agr switch in Products Sort&Filter Dialogue .
		 * Method to know whether any user interaction has happened on Orig. Agr switch
		 * @param {oEvent} - the click event.
		 * @private
		 */
		onChangeOrigAgr: function () {
			this.IsOrigAgrChanged = true;
		},
		/*
		 * Function is called when changing Govt. Bid switch in Products Sort&Filter Dialogue .
		 * Method to know whether any user interaction has happened on govt bid switch
		 * @param {oEvent} - the click event.
		 * @private
		 */
		onChangeBid: function () {
			this.IsBidChanged = true;
		},
		/*
		 * Function is called when changing Condition Type combo box selection in Products Sort&Filter Dialogue .
		 * Method to set the selected key
		 * @param {oEvent} - the click event.
		 * @private
		 */
		onChangeConditionType: function (oEvent) {
			var oSource = oEvent.getSource();
			var sSelectedKey = oSource.getSelectedKey();
			var ProductsFilterModel = this.getOwnerComponent().getModel("ProductsFilter");
			ProductsFilterModel.setProperty("/Condition", sSelectedKey);
		},
		/*
		 * Function is called when click on Ok Button in Products Sort&Filter Dialogue .
		 * Method to do  Sort&Filter operations and close the Sort&Filter Dialogue
		 * @param {oEvent} - the click event.
		 * @private  
		 */
		onProdSortAndFilterConfirm: function (oEvent) {
			var aFilters = [];
			var oStatusFilter = [];
			var oTable = this.getView().byId("idProductsTbl");
			var oBinding = oTable.getBinding("items");

			//Sorting
			var mParams = oEvent.getParameters();
			var sPath;
			var bDescending;
			var aSorters = [];
			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));
			}
			oBinding.sort(aSorters);
			var ProductsFilterModel = this.getOwnerComponent().getModel("ProductsFilter");
			var oMaterialDesc = ProductsFilterModel.getProperty("/MaterialDesc");
			var oCondition = ProductsFilterModel.getProperty("/Condition");
			var oOnOrgAgmt = ProductsFilterModel.getProperty("/OnOrigAgr");
			var oBid = ProductsFilterModel.getProperty("/Bid");
			var oFreightIncl = ProductsFilterModel.getProperty("/FreightIncl");
			var oStatus = ProductsFilterModel.getProperty("/Status");
			var aMaterialList = ProductsFilterModel.getProperty("/MaterialSearch/MaterialList");
			ProductsFilterModel.setProperty("/IsFiltered", "Default");
			if (aMaterialList.length !== 0) {
				var MatFilter;
				for (var idx = 0; idx < aMaterialList.length; idx++) {
					MatFilter = new Filter("MaterialNumber", FilterOperator.EQ, aMaterialList[idx]);
					aFilters.push(MatFilter);
				}
				this._handleFilterIcon();
			}
			if (oMaterialDesc !== "") {
				var oFilter2 = new Filter("MaterialDesc", "Contains", oMaterialDesc);
				aFilters.push(oFilter2);
				this._handleFilterIcon();
			}
			if (oCondition !== undefined) {
				var oFilter3 = new Filter("ConditionType", FilterOperator.EQ, oCondition);
				aFilters.push(oFilter3);
				this._handleFilterIcon();
			}
			if (this.IsOrigAgrChanged) {
				var oFilter4 = new Filter("OriginalAgreement", FilterOperator.EQ, oOnOrgAgmt);
				aFilters.push(oFilter4);
				this._handleFilterIcon();
			}
			if (this.IsBidChanged) {
				var oFilter5 = new Filter("GovtBids", FilterOperator.EQ, oBid);
				aFilters.push(oFilter5);
				this._handleFilterIcon();
			}
			if (this.IsBulkFrieghtChanged) {
				var oFilter6 = new Filter("PriceInclFreight", FilterOperator.EQ, oFreightIncl);
				aFilters.push(oFilter6);
				this._handleFilterIcon();
			}
			if (oStatus !== "" && oStatus.length !== 0) {
				for (var j = 0; j < oStatus.length; j++) {
					var oFilter7 = new Filter("UserStatus", FilterOperator.EQ, oStatus[j]);
					oStatusFilter.push(oFilter7);
				}
				var statusFilter = new Filter({
					filters: oStatusFilter,
					and: false
				});
				aFilters.push(statusFilter);
				this._handleFilterIcon();
			}
			aFilters.push(new Filter("DocumentNumber", "EQ", this.sDocumentNumber));
			oBinding.filter(aFilters);
			this.getOwnerComponent().getModel("ProductsFilter").updateBindings(true);

		},

		/*
		 * Function is called when click on Ok Button in MSL Price Sort&Filter Dialogue .
		 * Method to do  Sort&Filter operations and close the Sort&Filter Dialogue
		 * @param {oEvent} - the click event.
		 * @private M.Smith 
		 */
		onMSLPriceSortAndFilterConfirm: function (oEvent) {
			var aFilters = [];
			var oTable = this.getView().byId("idMSLPriceTbl");
			var oBinding = oTable.getBinding("rows");
			//var oStatusFilter = [];

			//Sorting
			var mParams = oEvent.getParameters();
			var sPath;
			var bDescending;
			var aSorters = [];

			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));
			}

			oBinding.sort(aSorters);

			var MslFilterModel = this.getOwnerComponent().getModel("MslFilter");
			// var oMaterial = MslFilterModel.getProperty("/MaterialNumber");
			var oMaterialDesc = MslFilterModel.getProperty("/MaterialDesc");
			var oTierId = MslFilterModel.getProperty("/TierID");
			var oRate = MslFilterModel.getProperty("/TierRate");
			//var oCondition = MslFilterModel.getProperty("/Condition");
			var oOnOrgAgmt = MslFilterModel.getProperty("/OnOrigAgr");
			var oBid = MslFilterModel.getProperty("/Bid");
			var oFreightIncl = MslFilterModel.getProperty("/FreightIncl");
			//var oStatus = MslFilterModel.getProperty("/Status");
			var aMaterialList = MslFilterModel.getProperty("/MaterialSearch/MaterialList");
			MslFilterModel.setProperty("/IsFiltered", "Default");

			if (aMaterialList.length !== 0) {
				var MatFilter;
				for (var idx = 0; idx < aMaterialList.length; idx++) {
					MatFilter = new Filter("MaterialNumber", FilterOperator.EQ, aMaterialList[idx]);
					aFilters.push(MatFilter);
				}
				this._handleFilterIcon();
			}

			if (oMaterialDesc !== "") {
				var oFilter3 = new Filter("MaterialDesc", "Contains", oMaterialDesc);
				aFilters.push(oFilter3);
				this._handleFilterIcon();
			}
			if (oTierId !== undefined && oTierId !== "") {
				var oFilter4 = new Filter("TierID", FilterOperator.EQ, oTierId);
				aFilters.push(oFilter4);
				this._handleFilterIcon();
			}
			if (oRate !== undefined && oRate !== "") {
				var oFilter5 = new Filter("TierRate", FilterOperator.EQ, oRate);
				aFilters.push(oFilter5);
				this._handleFilterIcon();
			}
		
			if (this.IsOrigAgrChanged) {
				var oFilter7 = new Filter("OriginalAgreement", FilterOperator.EQ, oOnOrgAgmt);
				aFilters.push(oFilter7);
				this._handleFilterIcon();
			}
			if (this.IsBidChanged) {
				var oFilter8 = new Filter("GovtBids", FilterOperator.EQ, oBid);
				aFilters.push(oFilter8);
				this._handleFilterIcon();
			}
			if (this.IsBulkFrieghtChanged) {
				var oFilter9 = new Filter("PriceInclFreight", FilterOperator.EQ, oFreightIncl);
				aFilters.push(oFilter9);
				this._handleFilterIcon();
			}

			oBinding.filter(aFilters);
			this.getOwnerComponent().getModel("MslFilter").updateBindings(true);
		
			
		},
		/*
		 * Method to change the filter button icon type
		 * @param oEvent - the click event.
		 * @private
		 */
		_handleFilterIcon: function () {
			var me = this;
			var ProductsFilterModel = this.getOwnerComponent().getModel("ProductsFilter");
			me.getView().getModel().attachEventOnce("batchRequestCompleted", function (oControlEvent) {
				if (oControlEvent.getParameters().success) {
					ProductsFilterModel.setProperty("/IsFiltered", "Emphasized");
				} else {
					ProductsFilterModel.setProperty("/IsFiltered", "Default");
				}
			}, me);
		},
		onSort: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Sort");
			}
		},

		onFilter: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Filter");
			}
		},

		_getSmartTable: function () {
			if (!this._oSmartTable) {
				this._oSmartTable = this.getView().byId("idMSLTable");
			}
			return this._oSmartTable;
		},

		/*
		 * Method to change the filter button icon type
		 * @param oEvent - the click event.
		 * @private
		 */
		_handleDistBuyPriceFilterIcon: function () {
			var me = this;
			var DistBuyPriceFilterModel = this.getOwnerComponent().getModel("DistBuyPriceFilter");
			me.getView().getModel().attachEventOnce("batchRequestCompleted", function (oControlEvent) {
				if (oControlEvent.getParameters().success) {
					DistBuyPriceFilterModel.setProperty("/IsFiltered", "Emphasized");
				} else {
					DistBuyPriceFilterModel.setProperty("/IsFiltered", "Default");
				}
			}, me);
		},
		/**
		 * Function is called when you select the reset button in Filter Dialogue.
		 * Method to reset the Filter values 
		 * @private
		 */
		onResetProductsFilterValues: function (oEvent) {
			var oProductsFilterModel = this.getOwnerComponent().getModel("ProductsFilter");
			var oData = {
				"MaterialNum": "",
				"MaterialDesc": "",
				"Condition": undefined,
				"ConditionVal": "",
				"FreightIncl": false,
				"OnOrigAgr": false,
				"Bid": false,
				"MaterialSearch": {
					"MaterialNum": "",
					"MaterialDesc": "",
					"Status": "",
					"SelectedStatuses": [],
					"MaterialList": [],
					"MaterialValueHelpSet": [],
					"tableBusy": false
				},
				"Status": ""
			};
			oData['MaterialSearch']['StatusList'] = oProductsFilterModel.getProperty('/MaterialSearch/StatusList');
			oProductsFilterModel.setData(oData);
			this._oDistBuyPriceSortDialog._getDialog().setContentWidth("350px");
			this.IsBulkFrieghtChanged = false;
			this.IsOrigAgrChanged = false;
			this.IsBidChanged = false;
			
		},
		/**
		 * Function is called when you select the reset button in Filter Dialogue.
		 * Method to reset the Filter values 
		 * @private M. Smith
		 */
		onResetMSLPricingFilterValues: function (oEvent) {
			var oMSLFilterModel = this.getOwnerComponent().getModel("MslFilter");
			var oData = {
				"MaterialNumber": "",
				"MaterialDesc": "",
				"TierID": "",
				"TierRate": "",
				"Condition": "",
				"ConditionVal": "",
				"FreightIncl": "",
				"OnOrgAgmt": "",
				"Bid": "",
				"MaterialSearch": {
					"MaterialNumber": "",
					"MaterialDesc": "",
					"TierID": "",
					"TierRate": "",
					"Status": "",
					"SelectedStatuses": [],
					"MaterialList": [],
					"MaterialValueHelpSet": [],
					"tableBusy": false
				},
				"Status": ""

			};
			oData['MaterialSearch']['StatusList'] = oMSLFilterModel.getProperty('/MaterialSearch/StatusList');
			oMSLFilterModel.setData(oData);
			//this._oDistBuyPriceSortDialog._getDialog().setContentWidth("350px");
			this.IsBulkFrieghtChanged = false;
			this.IsOrigAgrChanged = false;
			this.IsBidChanged = false;
			//this.getOwnerComponent().getModel("MslFilter").getBindings("rows");

		},

		/**
		 * Function is called when Rebate Agreement # pressed from Incentiv

		},

		/**
		 * Function is called when you select the reset button in Filter Dialogue.
		 * Method to reset the Filter values 
		 * @private
		 */
		onResetDistBuyPriceFilterValues: function (oEvent) {
			var oDistBuyPriceFilterModel = this.getOwnerComponent().getModel("DistBuyPriceFilter");
			var oData = {
				"MaterialNum": "",
				"MaterialDesc": "",
				"DistributorNumber": "",
				"DistributorDesc": "",
				"MaterialSearch": {
					"MaterialNum": "",
					"MaterialDesc": "",
					"Status": "",
					"SelectedStatuses": [],
					"MaterialList": [],
					"MaterialValueHelpSet": [],
					"tableBusy": false
				},
				"Status": ""
			};
			oData['MaterialSearch']['StatusList'] = oDistBuyPriceFilterModel.getProperty('/MaterialSearch/StatusList');
			oDistBuyPriceFilterModel.setData(oData);
			this._oDistBuyPriceSortDialog._getDialog().setContentWidth("350px");

		},

		/**
		 * Function is called when Products table filter dialog - Material Fitler Go button pressed
		 * Method to get the Materials by filtering Material#, Material Desc & Status in Products table filter dialog
		 * @private
		 */
		onMaterailNumSerachPress: function (evt) {
			var oView = this.getView();
			var ProductsFilterModel = oView.getModel("ProductsFilter");
			var MaterialSearchData = ProductsFilterModel.getData().MaterialSearch;
			ProductsFilterModel.setProperty("/MaterialSearch/tableBusy", true);
			var aFilter = [];
			if (MaterialSearchData.MaterialNum.trim().length !== 0) {
				aFilter.push(new Filter("MaterialNumber", "Contains", MaterialSearchData.MaterialNum));
			}
			if (MaterialSearchData.MaterialDesc.trim().length !== 0) {
				aFilter.push(new Filter("MaterialDescription", "Contains", MaterialSearchData.MaterialDesc));
			}
			if (MaterialSearchData.SelectedStatuses.length !== 0) {
				for (var iStatus = 0; iStatus < MaterialSearchData.SelectedStatuses.length; iStatus++) {
					aFilter.push(new Filter("Status", "EQ", MaterialSearchData.SelectedStatuses[iStatus]));
				}
			}
			var oModel = oView.getModel();
			oModel.read("/MaterialValueHelpSet", {
				filters: aFilter,
				success: function (oData) {
					ProductsFilterModel.setProperty("/MaterialSearch/MaterialValueHelpSet", oData.results);
					ProductsFilterModel.checkUpdate(true);
					ProductsFilterModel.setProperty("/MaterialSearch/tableBusy", false);
				},
				error: function (oError) {
					ProductsFilterModel.setProperty("/MaterialSearch/tableBusy", false);
					//To Do - Error handling
				}
			});
		},
		/**
		 * Function is called when Products table filter dialog - Material Fitler Go button pressed
		 * Method to get the Materials by filtering Material#, Tier, RATE in MSL table filter dialog
		 * @private M.Smith
		 */
		onMSLNumSearchPress: function (evt) {
			var oView = this.getView();
			var MslFilterModel = oView.getModel("MslFilter");
			var MaterialSearchData = MslFilterModel.getData().MaterialSearch;
			MslFilterModel.setProperty("/MaterialSearch/tableBusy", true);
			var aFilter = [];
			if (MaterialSearchData.MaterialNumber.trim().length !== 0) {
				aFilter.push(new Filter("MaterialNumber", "Contains", MaterialSearchData.MaterialNumber));
			}
			if (MaterialSearchData.MaterialDesc.trim().length !== 0) {
				aFilter.push(new Filter("MaterialDescription", "Contains", MaterialSearchData.MaterialDesc));
			}
			if (MaterialSearchData.SelectedStatuses.length !== 0) {
				for (var iStatus = 0; iStatus < MaterialSearchData.SelectedStatuses.length; iStatus++) {
					aFilter.push(new Filter("Status", "EQ", MaterialSearchData.SelectedStatuses[iStatus]));
				}
			}

			var oModel = oView.getModel();
			oModel.read("/MaterialValueHelpSet", {
				filters: aFilter,
				success: function (oData) {
					MslFilterModel.setProperty("/MaterialSearch/MaterialValueHelpSet", oData.results);
					MslFilterModel.checkUpdate(true);
					MslFilterModel.setProperty("/MaterialSearch/tableBusy", false);
				},
				error: function (oError) {
					MslFilterModel.setProperty("/MaterialSearch/tableBusy", false);
					//To Do - Error handling
				}
			});
		},

		/**
		 * Function is called when Distributor table filter dialog - Material Fitler Go button pressed
		 * Method to get the Materials by filtering Material#, Material Desc & Status in Distributor table filter dialog
		 * @private
		 */
		onDistBuyPriceMaterailNumSerachPress: function (evt) {
			var oView = this.getView();
			var DistBuyPriceModel = oView.getModel("DistBuyPriceFilter");
			var MaterialSearchData = DistBuyPriceModel.getData().MaterialSearch;
			DistBuyPriceModel.setProperty("/MaterialSearch/tableBusy", true);
			var aFilter = [];
			if (MaterialSearchData.MaterialNum.trim().length !== 0) {
				aFilter.push(new Filter("MaterialNumber", "Contains", MaterialSearchData.MaterialNum));
			}
			if (MaterialSearchData.MaterialDesc.trim().length !== 0) {
				aFilter.push(new Filter("MaterialDescription", "Contains", MaterialSearchData.MaterialDesc));
			}
			if (MaterialSearchData.SelectedStatuses.length !== 0) {
				for (var iStatus = 0; iStatus < MaterialSearchData.SelectedStatuses.length; iStatus++) {
					aFilter.push(new Filter("Status", "EQ", MaterialSearchData.SelectedStatuses[iStatus]));
				}
			}
			var oModel = oView.getModel();
			oModel.read("/MaterialValueHelpSet", {
				filters: aFilter,
				success: function (oData) {
					DistBuyPriceModel.setProperty("/MaterialSearch/MaterialValueHelpSet", oData.results);
					DistBuyPriceModel.checkUpdate(true);
					DistBuyPriceModel.setProperty("/MaterialSearch/tableBusy", false);
				},
				error: function (oError) {
					DistBuyPriceModel.setProperty("/MaterialSearch/tableBusy", false);
					//To Do - Error handling
				}
			});
		},

		/**
		 * Function is called when Products table filter dialog detail page opened.
		 * Method to set the Filter dialog width. In Material Number serach filter we are displaying a table.
		 * * For this we need to increase the width of the filter dialog
		 * @private
		 */
		onProdFilterDetailPageOpened: function (oEvent) {
			var selectedItem = oEvent.getParameter("parentFilterItem").getKey();
			if (selectedItem === "MaterialNum") {
				this._oProdSortAndFilterDialog._getDialog().setContentWidth("1000px");
			} else {
				this._oProdSortAndFilterDialog._getDialog().setContentWidth("350px");
			}
		},
		/**
		 * Function is called when Products table filter dialog detail page opened.
		 * Method to set the Filter dialog width. In Material Number serach filter we are displaying a table.
		 * * For this we need to increase the width of the filter dialog
		 * @private M. Smith
		 */
		onMSLPriceFilterDetailPageOpened: function (oEvent) {
			var selectedItem = oEvent.getParameter("parentFilterItem").getKey();
			if (selectedItem === "MaterialNumber") {
				this._oMSLSortAndFilterDialog._getDialog().setContentWidth("1000px");
			} else {
				this._oMSLSortAndFilterDialog._getDialog().setContentWidth("350px");
			}
		},

		/**
		 * Function is called when Distributor table filter dialog detail page opened.
		 * Method to set the Filter dialog width. In Material Number serach filter we are displaying a table.
		 * * For this we need to increase the width of the filter dialog
		 * @private
		 */
		onDistBuyPriceFilterDetailPageOpened: function (oEvent) {
			var selectedItem = oEvent.getParameter("parentFilterItem").getKey();
			if (selectedItem === "MaterialNum") {
				this._oDistBuyPriceSortDialog._getDialog().setContentWidth("1000px");
			} else {
				this._oDistBuyPriceSortDialog._getDialog().setContentWidth("350px");
			}
		},

		/**
		 * Function is called when selecting Materials from Material table in Products filter dialog.
		 * Method to get Materail numbers from the selected records in the Products filter dialog Material table
		 * @private
		 */
		onMaterialListTableSelect: function (oEvent) {
			var ProductsFilterModel = this.getView().getModel("ProductsFilter");
			var aSelectedCtxs = oEvent.getSource().getSelectedContexts();
			var aMaterailList = [];
			for (var oCtx = 0; oCtx < aSelectedCtxs.length; oCtx++) {
				aMaterailList.push(aSelectedCtxs[oCtx].getProperty("MaterialNumber"));
			}
			ProductsFilterModel.setProperty("/MaterialSearch/MaterialList", aMaterailList);
			aMaterailList = [];
		},
		/**
		 * Function is called when selecting Materials from Material table in MSL Table filter dialog.
		 * Method to get Material numbers from the selected records in the MSL Table filter dialog Material table
		 * @private M. Smith
		 */
		onMSLTableSelect: function (oEvent) {
			var MSLFilterModel = this.getView().getModel("MslFilter");
			var aSelectedCtxs = oEvent.getSource().getSelectedContexts();
			var aMaterialList = [];
			for (var oCtx = 0; oCtx < aSelectedCtxs.length; oCtx++) {
				aMaterialList.push(aSelectedCtxs[oCtx].getProperty("MaterialNumber"));
			}
			MSLFilterModel.setProperty("/MaterialSearch/MaterialList", aMaterialList);
			aMaterialList = [];
		},

		/**
		 * Function is called when selecting Materials from Material table in Distributor Buy price filter dialog.
		 * Method to get Materail numbers from the selected records in the Ditributor Buy price filter dialog Material table
		 * @private
		 */
		onDistBuyPriceMaterialListTableSelect: function (oEvent) {
			var DistBuyPriceFilterModel = this.getView().getModel("DistBuyPriceFilter");
			var aSelectedCtxs = oEvent.getSource().getSelectedContexts();
			var aMaterailList = [];
			for (var oCtx = 0; oCtx < aSelectedCtxs.length; oCtx++) {
				aMaterailList.push(aSelectedCtxs[oCtx].getProperty("MaterialNumber"));
			}
			DistBuyPriceFilterModel.setProperty("/MaterialSearch/MaterialList", aMaterailList);
			aMaterailList = [];
		},

		/**
		 * Function is called when you search Products table.
		 * Method to search Products Table
		 * @private
		 */
		onSearchProducts: function (evt) {
			var aFilters = [];
			var sQuery = evt.getSource().getValue();
			sQuery = sQuery;
			if (sQuery) {
				aFilters.push(new Filter("SearchField", "Contains", sQuery));
			}
			aFilters.push(new Filter("DocumentNumber", "EQ", this.sDocumentNumber));
			this.getView().byId("idProductsTbl").getBinding("items").filter(aFilters);
		},
		/**
		 * Function is called when you search Distributor Buy Price  table.
		 * Method to search Distributor Buy Price Table
		 * @private
		 */
		onSearchDist: function (evt) {
			var aFilters = [];
			var sQuery = evt.getSource().getValue();
			sQuery = sQuery;
			if (sQuery) {
				aFilters.push(new Filter("SearchField", "Contains", sQuery));
			}
			aFilters.push(new Filter("DocumentNumber", "EQ", this.sDocumentNumber));
			this.getView().byId("IdDistributorBuyPrice").getBinding("items").filter(aFilters);
		},

		/**
		 * Function is called when you search Member Ship List table.
		 * Method to search Member Ship List Table
		 * @private Note: 
		 */
		onSearchMsl: function (evt) {
			var aFilters = [];
			var sQuery = evt.getSource().getValue();
			sQuery = sQuery;
			if (sQuery) {
				aFilters.push(new Filter("SearchField", "Contains", sQuery));
			}
			// aFilters.push(new Filter("DocumentNumber", "EQ", this.sDocumentNumber));
			this.getView().byId("idMSLTable").getTable().getBinding("rows").filter(aFilters);
		},

		/**
		 * Function is called when Rebate Agreement # pressed from Incentives & Rebates section
		 * Method to cross app navigation to Rebate agreemetns app
		 * @private
		 */
		onRebateNumPress: function (oEvent) {

			var that = this;
			var oView = that.getView();
			var oControl = oEvent.getSource();
			var oDataModel = oView.getModel();
			var urlParam = {
				Activity: "03",
				DocumentType: "RA"
			};
			oDataModel.callFunction("/CheckAuthorization", {
				method: "POST",
				urlParameters: urlParam,
				success: function (oData, response) {
					var sAgreementNumber = oControl.getText();
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "EcolabRebateAgreements",
							action: "display&/" + sAgreementNumber + "/DetailRebates"
						},
						params: {}
					})) || "";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				},
				error: function (oError) {}
			});

		},

		/**
		 * Story No ASB-2312
		 * Function is called when click on Add Incentive Button in the Incentives & Rebates Section .
		 * Method to navigate to Incentives&Rebates New CRA view.
		 * @param oEvent - the click event of Add Incentive Button.
		 * @private
		 */
		onAddIncentivePress: function (oEvent) {
			var oAdminFields = oEvent.getSource().getBindingContext().getObject().AdminFields;
			var oValueFields = oEvent.getSource().getBindingContext().getObject().ValueFields;
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "EcolabRebateAgreements",
					action: "display"
				},
				params: {
					"MasterAgreementNumber": oValueFields.AgreementNumber,
					"MasterAgreementDesc": oValueFields.Description,
					"Currency": oValueFields.Currency,
					"DistributionChannel": oValueFields.DistributionChannel,
					"Division": oValueFields.Division,
					"SalesOrg": oValueFields.SalesOrg
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		/**
		 * Function is called when click on Scale Icon Press .
		 * Method to Show the From and To Scales Values.
		 * @param oEvent - the click event of Scales in Smart Table.
		 * @private
		 */
		onScalePress: function (oEvent) {
			var me = this;
			me.oPopOverSrc = oEvent.getSource();
			var oCurrentObj = me.oPopOverSrc.getBindingContext().getObject();
			var nConditionNumber = oCurrentObj.ConditionNumber;
			if (!this._oScalesPopover) {
				this._oScalesPopover = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.ScalesPopover", this);
				this.getView().addDependent(this._oScalesPopover);
			}
			this._oScalesPopover.getContent()[0].getBinding("items").filter([new sap.ui.model.Filter(
				"ConditionNumber",
				sap.ui.model.FilterOperator.EQ, nConditionNumber
			), new sap.ui.model.Filter(
				"DocumentNumber",
				sap.ui.model.FilterOperator.EQ, me.sDocumentNumber
			)]);
			me.getView().getModel().attachEventOnce("batchRequestCompleted", function (oControlEvent) {
				me._oScalesPopover.openBy(me.oPopOverSrc);
			}, me);
		},
		/**
		 * Downloads the particular File 
		 * @function
		 * @param {sap.ui.base.Event} oEvent 
		 * @private
		 */
		onShowFileContent: function (oEvent) {
			var oSource = oEvent.getSource();
			var oDataModel = this.getView().getModel();
			var oCurrentObj = oSource.getBindingContext().getObject();
			window.open(oDataModel.sServiceUrl + "/AttachmentSet(ObjectNumber='" + oCurrentObj.ObjectNumber + "',FileID='" + oCurrentObj.FileID +
				"')/$value");
		},

		updateProductSetCount: function () {
			var that = this;
			var oView = this.getView();
			var oModel = that.getOwnerComponent().getModel();

			that._updateListItemCount(oView.byId("idProductsTbl"), "");
			oModel.read("/ProductSet/$count", {
				filters: [new sap.ui.model.Filter("DocumentNumber", "EQ", that.sDocumentNumber)],
				success: function (count) {
					that._updateListItemCount(oView.byId("idProductsTbl"), count);
				},
				error: function (oError) {}
			});
		},

		updatePriceExceptionSetCount: function () {
			var that = this;
			var oView = this.getView();
			var oModel = that.getOwnerComponent().getModel();

			that._updateListItemCount(oView.byId("idPriceExceptionTbl"), "");
			oModel.read("/PriceExceptionSet/$count", {
				filters: [new sap.ui.model.Filter("DocumentNumber", "EQ", that.sDocumentNumber)],
				success: function (count) {
					that._updateListItemCount(oView.byId("idPriceExceptionTbl"), count);
				},
				error: function (oError) {}
			});
		},

		updateFlatFeeSetCount: function () {
			var that = this;
			var oView = this.getView();
			var oModel = that.getOwnerComponent().getModel();

			that._updateListItemCount(oView.byId("idFlatFeeTable"), "");
			oModel.read("/FlatFeeSet/$count", {
				filters: [new sap.ui.model.Filter("DocumentNumber", "EQ", that.sDocumentNumber)],
				success: function (count) {
					that._updateListItemCount(oView.byId("idFlatFeeTable"), count);
				},
				error: function (oError) {}
			});
		},
		updateMslPricingCount: function () {
			var that = this;
			var oView = this.getView();
			var oModel = that.getOwnerComponent().getModel();

			that._updateListItemCount(oView.byId("idMSLPriceTbl"), "");
			oModel.read("/MSLPriceSet/$count", {
				filters: [new sap.ui.model.Filter("DocumentNumber", "EQ", that.sDocumentNumber)],
				success: function (count) {
					that._updateListItemCount(oView.byId("idMSLPriceTbl"), count);
				},
				error: function (oError) {}
			});
		},

		updateDistBuyPriceSetCount: function () {
			var that = this;
			var oView = this.getView();
			var oModel = that.getOwnerComponent().getModel();

			that._updateListItemCount(oView.byId("IdDistributorBuyPrice"), "");
			oModel.read("/DistBuyPriceSet/$count", {
				filters: [new sap.ui.model.Filter("DocumentNumber", "EQ", that.sDocumentNumber)],
				success: function (count) {
					that._updateListItemCount(oView.byId("IdDistributorBuyPrice"), count);
				},
				error: function (oError) {}
			});
		},

		/**
		 * After list data is available, this handler method updates the
		 * master list counter.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			var oList = oEvent.getSource();
			// update the master list object counter after new data is loaded
			// only update the counter if the length is final
			if (oList.getBinding("items").isLengthFinal()) {
				this._updateListItemCount(oList, oEvent.getParameter("total"));
			} else {
				this._updateListItemCount(oList, "");
			}
		},

		/**
		 * Sets the item count on the list header
		 * @param {Object} oList List object
		 * @param {int} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function (oList, iTotalItems) {
			var sTitle = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(oList.data("titlecount"));
			this.getView().getModel("DetailHeaderInfo").setProperty("/" + oList.data("titlecount"), (sTitle !== "") ? sTitle + " (" +
				iTotalItems + ")" : "");
		},

		/**
		 * Story No ASB-473 ---- Start
		 * Function is called when click on History Link .
		 * Method to populate it navigates to the Master Agreement History Application
		 * @param oEvent - the click event.
		 * @private
		 */
		onHistoryButtonpress: function (oEvent) {
			var sCuurentObj = oEvent.getSource().getBindingContext().getObject();
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ASBRebateHistory",
					action: "display"
				},
				params: {
					"AgreementNumber": sCuurentObj.DocumentNumber
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		onDistBuyPriceUpdateFinished: function (oEvent) {
			var oList = oEvent.getSource();
			this._updateListItemCount(oList, oEvent.getParameter("total"));
		}
	});
});