sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (UI5Object, MessageBox, Filter, FilterOperator, MessageToast) {
	"use strict";

	return UI5Object.extend("com.ecolab.ZASBMasterAgr.controller.ErrorHandler", {

		/**
		 * Handles application errors by automatically attaching to the model events and displaying errors when needed.
		 * @class
		 * @param {sap.ui.core.UIComponent} oComponent reference to the app's component
		 * @public
		 * @alias com.hd.rtvcreate.controller.ErrorHandler
		 */
		constructor: function (oComponent) {
			this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			this._oComponent = oComponent;
			this._oModel = oComponent.getModel();
			this._bMessageOpen = false;
			this._sErrorText = this._oResourceBundle.getText("errorText");

			this._oModel.attachMetadataFailed(function (oEvent) {
				var oParams = oEvent.getParameters();

				this._showMetadataError(oParams.response);
			}, this);

			var oBusyIndicator = new sap.m.BusyDialog();
			this._oModel.attachRequestSent(function (oEvent) {
				oBusyIndicator.open();
			}, this);
			this._oModel.attachRequestCompleted(function (oEvent) {

				oBusyIndicator.close();
			}, this);

			this._oModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();

				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				// if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf("Cannot POST") === 0)) {
				this._showServiceError(oParams.response);
				// }
			}, this);
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when the metadata call has failed.
		 * The user can try to refresh the metadata.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showMetadataError: function (sDetails) {
			var oXML = jQuery.parseXML(sDetails.body);
			var oXMLMsg = oXML.querySelector("message");
			if (oXMLMsg) {
				var messageText = oXMLMsg.textContent;
				MessageBox.error(
					this._sErrorText + "\n\n" + messageText, {
						id: "serviceErrorMessageBox",
						styleClass: this._oComponent.getContentDensityClass(),
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this._bMessageOpen = false;
						}.bind(this)
					}
				);
			}
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed.
		 * Only the first error message will be display.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showServiceError: function (sDetails) {
			var errorMsg;
			this._bMessageOpen = true;
			if(sDetails.statusCode !== "412"){
				if (sDetails.responseText.indexOf('{"') !== -1) {
					var sDetailsJSONError = JSON.parse(sDetails.responseText).error;
					if(sDetailsJSONError.innererror){
						if(sDetailsJSONError.innererror.errordetails && sDetailsJSONError.innererror.errordetails.length > 0){
							errorMsg = sDetailsJSONError.innererror.errordetails[0].message;
						} else {
							errorMsg = sDetailsJSONError.message.value;
						}
					} else {
						errorMsg = sDetailsJSONError.message.value;
					}
					MessageBox.error(
						this._sErrorText + "\n\n" + errorMsg, {
							id: "serviceErrorMessageBox",
							styleClass: this._oComponent.getContentDensityClass(),
							actions: [MessageBox.Action.CLOSE],
							onClose: function () {
								this._bMessageOpen = false;
							}.bind(this)
						}
					);
				} else {
					if (jQuery.parseXML(sDetails.responseText)) {
						var oXMLMsg = jQuery.parseXML(sDetails.responseText).querySelector("message");
						var oXMLH1 = jQuery.parseXML(sDetails.responseText).querySelector("h1");
						if(oXMLMsg !== null && oXMLMsg.length > 0){
							errorMsg = oXMLMsg[0].childNodes[0].nodeValue;
						} else {
							errorMsg = oXMLH1.childNodes[0].nodeValue;
						}
					} else {
						errorMsg = sDetails.responseText;
					}
					MessageBox.error(
						this._sErrorText + "\n\n" + errorMsg, {
							id: "serviceErrorMessageBox",
							styleClass: this._oComponent.getContentDensityClass(),
							actions: [MessageBox.Action.CLOSE],
							onClose: function () {
								this._bMessageOpen = false;
							}.bind(this)
						}
					);
				}
			}
		}

	});
});