sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"com/ecolab/ZASBMasterAgr/model/formatter",
	"sap/ui/core/routing/History"
], function (UIComponent, Controller, JSONModel, Sorter, Filter, FilterOperator, MessageBox, formatter, History) {
	"use strict";
	return Controller.extend("com.ecolab.ZASBMasterAgr.controller.MasterAgreements", {
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the MasterAgreements controller is instantiated.
		 * @public
		 */
		onInit: function () {
			this._oRouter = UIComponent.getRouterFor(this);
			/***********StatusModel****/
			var oStatusModel = new JSONModel();
			this.getOwnerComponent().setModel(oStatusModel, "StatusModel");
			this.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this._oRouter.attachRoutePatternMatched(this._handleRouteMatched, this);
		},
		
		/**
		 * This Method is called when the Route gets Matched.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_handleRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "MasterAgreements") {
				this.getView().getModel().refresh();
				//Hide FLP back button because it does not need in the first page
				sap.ui.getCore().byId("backBtn").setVisible(false);
			}
		},
		/*
		 * @param evt - the click event.
		 * Navigates to DetailPage With DocumentNumber as a Parameter
		 */
		onMasterListAgreementPress: function (evt) {
			var that = this;
			var oView = that.getView();
			var oControl = evt.getSource();
			var oContext = oControl.getBindingContext().getObject();
			var MARevisionRoutingModel = that.getOwnerComponent().getModel("MARevisionRoutingModel");
			var sPath = oContext.DocumentNumber;
			var oDataModel = oView.getModel();
			var urlParam = {
				Activity: "03",
				DocumentType: "MA"
			};
			oDataModel.callFunction("/CheckAuthorization", {
				method: "POST",
				urlParameters: urlParam,
				success: function (oData, response) {
					if (oContext.AdminFields.IsViewable === true && oContext.AdminFields.IsStakeholder === false) {
						MessageBox.error(that.bundle.getText("MAlistPressError"));
					} else {
						MARevisionRoutingModel.setProperty("/IsRoutedWithMANum",true);
						MARevisionRoutingModel.setProperty("/IsRoutedWithRevisionNum",false);
						that._oRouter.navTo("DetailAgreements", {
							DocumentNumber: sPath
						}, false);
					}
				},
				error: function (oError) {}
			});

		},

		/**
		 * This funciton handles Search operation on Master Agreements List
		 * @param evt - the search event.
		 * @private
		 */
		onSearchMA: function (evt) {
			var me = this;
			var filterModel = me.getOwnerComponent().getModel("filterModel");
			var sQuery = evt.getSource().getValue();
			filterModel.setProperty("/SearchValue",sQuery);
			me._combineAllSortandFilters(me.SortFilterEventParams);
		},
		/**
		 * Function is called when you press on Add Agreement Button
		 * Here we also cehcking the Authorization by calling the CheckAuthorization function import 
		 * Method to Populate Add Agreement Button 
		 **/
		onAddAgreementPress: function (oEvent) {
			var that = this;
			var oView = that.getView();
			var oDataModel = oView.getModel();
			var urlParam = {
				Activity: "01",
				DocumentType: "CMA"
			};
			oDataModel.callFunction("/CheckAuthorization", {
				method: "POST",
				urlParameters: urlParam,
				success: function (oData, response) {
					that._oRouter.navTo("EditAgreement");
				},
				error: function (oError) {}
			});
		},

		/**
		 * Method to populate Sort dialog & Filter dialog
		 * @private
		 */
		_getDialog: function () {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.SortandFilter", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},

		/************On MA Sort Button Click********/
		/**
		 * Function is called when click on Sort Button & Filter Button.
		 * Method to populate Sort dialog & Filter dialog
		 * @private
		 */
		onSortFilterAgreementPress: function (oEvent) {
			var oCustomData = oEvent.getSource().getCustomData()[0].getValue();
			//MA Filter Dialogue Status Data
			var sPath = "/SelectSet(EntityName='Document',ComplexType='',EntityProperty='UserStatus')";
			var value1 = "YMREQ001";
			var oStatusfilter = new Filter("StatusProfile", FilterOperator.EQ, value1);
			var oModel = this.getView().getModel();
			var oStatusModel = this.getOwnerComponent().getModel("StatusModel");
			oModel.read(sPath, {
				filters: [oStatusfilter],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oStatusModel.setData(oData);
					oStatusModel.updateBindings(true);
				},
				error: function (oError) {
					sap.m.MessageToast.show(oError);
				}
			});
			if (oCustomData === "Sort") {
				this._getDialog().open("sort");
			} else {
				this._getDialog().open("filter");
			}
			sap.ui.getCore().setModel(this.getView().getModel());
			sap.ui.getCore().setModel(this.getView().getModel("filterModel"));
			this._oDialog.setModel(this.getView().getModel());
			this._oDialog.setModel(sap.ui.getCore().getModel("i18n"), "i18n");
		},

		/*****************on Owner Items Search in Filter Dialog**********/
		/**
		 * This funciton handles Search operation on Owner List
		 * @param evt - the search event.
		 * @private
		 */
		handleOwnersearch: function (evt) {
			var that = this;
			var aListItems = sap.ui.getCore().byId("idOwnerList").getItems();
			var sTypedChars = evt.getSource().getValue();
			for (var i = 0; i < aListItems.length; i++) {
				if (that.filterOwnerResults(sTypedChars, aListItems[i])) {
					aListItems[i].setVisible(true);
				} else {
					aListItems[i].setVisible(false);
				}
			}
		},
		
		/**
		 * Function that takes the user typed value in EBS Owner and Row in list.
		 * Based on user typed value it determines whether a row is eligible for display or not
		 * @param {String} sValue - User typed text
		 * @param {sap.m.StandardListItem} oStandardListItem - oStandardListItem object
		 * @returns {boolean} If return Boolean value is true then it displays corresponding row otherwise it won't display
		 * @private
		 */
		 filterOwnerResults : function (sValue, oStandardListItem) {
			return ( !sValue || sValue === "" ||
					oStandardListItem.getTitle() && (oStandardListItem.getTitle().toUpperCase().indexOf(sValue.toUpperCase())) !== -1 || 
					oStandardListItem.getInfo() && (oStandardListItem.getInfo().toUpperCase().indexOf(sValue.toUpperCase())) !== -1 );
		},

		/*
		 * Function is called when click on Ok Button in Sort&Filter Dialogue .
		 * Method to do  Sort&Filter operations and close the Sort&Filter Dialogue
		 * @param oEvent - the click event.
		 * @private
		 */
		handleConfirm: function (oEvent) {
			var me = this;
			me.SortFilterEventParams = oEvent.getParameters();
			var arrSelectedItems = [];
			var oDataModel = me.getView().getModel();
			var oOwnerList = sap.ui.getCore().byId("idOwnerList");
			var oStatusDropDownList = sap.ui.getCore().byId("idStatusDropDownList");
			var filterModel = this.getOwnerComponent().getModel("filterModel");
			var sPath;
			for(var idx=0; idx<oOwnerList.getSelectedContextPaths().length; idx++){
				sPath = oOwnerList.getSelectedContextPaths()[idx];
				arrSelectedItems.push(oDataModel.getObject(sPath).EBSID);
			}
			filterModel.setProperty("/validOnOld",filterModel.getProperty("/validOn"));
			filterModel.setProperty("/Status",oStatusDropDownList.getSelectedKeys());
			filterModel.setProperty("/Owner",arrSelectedItems);
			if(filterModel.getProperty("/Owner").length > 0){
				filterModel.setProperty("/OwnerFilterCount",filterModel.getProperty("/Owner").length);
			} else {
				filterModel.setProperty("/OwnerFilterCount",0);
			}
			if(filterModel.getProperty("/Status").length > 0){
				filterModel.setProperty("/StatusFilterCount",filterModel.getProperty("/Status").length);
			} else {
				filterModel.setProperty("/StatusFilterCount",0);
			}
			if(filterModel.getProperty("/validOn") && filterModel.getProperty("/validOn") !== ""){
				filterModel.setProperty("/ValidOnFilterCount",1);
			} else {
				filterModel.setProperty("/ValidOnFilterCount",0);
			}
			me._combineAllSortandFilters(me.SortFilterEventParams);
		},
		
		/*
		 * Method to combine all the sortings and filters
		 * @param oEvent - the click event.
		 * @private
		 */
		_combineAllSortandFilters: function(mParams){
			var me = this;
			var oView = me.getView();
			var oTable = oView.byId("idTableMA");
			var oBinding = oTable.getBinding("items");
			var filterModel = me.getOwnerComponent().getModel("filterModel");
			var oFilterData = filterModel.getProperty("/");
			// apply sorter to binding
			var sPath;
			var bDescending;
			var aSorters = [];
			if (mParams && mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));
			} else {
				aSorters.push(new Sorter("ValidFrom", true));
			}
			//aSorters.push(new Sorter("ValidFrom", true));
			oBinding.sort(aSorters);
			oView.getModel().updateBindings(true);
			// apply filters to binding
			var aFilters = [];
			var oOwnerFilter = [];
			var oStatusFilter = [];
			var oOwner = oFilterData.Owner;
			var oStatus = oFilterData.Status;
			var sSearchValue = oFilterData.SearchValue;
			var oOnDate = oFilterData.validOn;
			var targetoDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-ddT00:00:00+00:00",
				UTC: true
			});
			oOnDate = targetoDateFormat.format(new Date(oOnDate));
			/*By default set filter button type to Default*/
			filterModel.setProperty("/IsFiltered","Default");
			if (oOwner !== "" && oOwner.length !== 0) {
				for (var i = 0; i < oOwner.length; i++) {
					oOwnerFilter.push(new Filter("OwnerNum", FilterOperator.EQ, oOwner[i]));
				}
				var ownerFilter = new Filter({
					filters: oOwnerFilter,
					and: false
				});
				aFilters.push(ownerFilter);
				me._handleFilterIcon();
			}
			if (oOnDate !== "") {
				aFilters.push(new Filter({
                    filters: [
                        new Filter({
                            path: "ValidFrom",
                            operator: FilterOperator.LE,
                            value1: oOnDate
                        }),
                        new Filter({
                            path: "ValidTo",
                            operator: FilterOperator.GE,
                            value1: oOnDate
                        })
                        ],
                    and: true
                }));
				me._handleFilterIcon();
			}
			if (oStatus !== "" && oStatus.length !== 0) {
				for (var j = 0; j < oStatus.length; j++) {
					oStatusFilter.push(new Filter("UserStatus", FilterOperator.EQ, oStatus[j]));
				}
				var statusFilter = new Filter({
					filters: oStatusFilter,
					and: false
				});
				aFilters.push(statusFilter);
				me._handleFilterIcon();
			}
			if (sSearchValue && sSearchValue !== "") {
				var oQuery = "*" + sSearchValue + "*";
				aFilters.push(new Filter("SearchField", FilterOperator.EQ, oQuery));
			}
			oBinding.filter(aFilters);
			this.getOwnerComponent().getModel("filterModel").updateBindings(false);
		},
		handleCancel: function(oEvent){
			var me =this;
			var filterModel = me.getOwnerComponent().getModel("filterModel");
			var oStatus = filterModel.getProperty("/Status");
			var originalValidOnDate = filterModel.getProperty("/validOnOld");
			var newValidOnDate = filterModel.getProperty("/validOn");
			filterModel.setProperty("/Statuskey",oStatus);
			if(originalValidOnDate !== newValidOnDate){
				filterModel.setProperty("/validOn",originalValidOnDate);
			}
		},
		/*
		 * Method to change the filter button icon type
		 * @param oEvent - the click event.
		 * @private
		 */
		_handleFilterIcon: function(){
			var me = this;
			var filterModel = me.getOwnerComponent().getModel("filterModel");
			me.getView().getModel().attachEventOnce("batchRequestCompleted",function(oControlEvent){
				if(oControlEvent.getParameters().success){
					filterModel.setProperty("/IsFiltered","Emphasized");
				} else {
					filterModel.setProperty("/IsFiltered","Default");
				}
			},me);
		},
		
		/*
		 * Function is called when owner list gets updated
		 * Method to set the selected items manually based on the aleady maintained owner filters
		 * @param oEvent - the click event.
		 * @private
		 */
		onOwnerListUpdated: function(oEvent){
			var me =this;
			var oSource = oEvent.getSource();
			var oListItems = oSource.getItems();
			var filterModel = me.getOwnerComponent().getModel("filterModel");
			var aOwner = filterModel.getProperty("/Owner");
			if(aOwner.length > 0 && oSource.getSelectedContextPaths().length === 0){
				for(var idx=0; idx<oListItems.length; idx++){
					for(var ownerindex=0; ownerindex<aOwner.length; ownerindex++){
						if (oListItems[idx].getInfo() === aOwner[ownerindex]) {
					        oListItems[idx].setSelected(true);
					    }
					}
				}
			}
		},
		/*****************Status item select in Filter dialog ******/
		/**
		 * Function is called when you select the Status in MultiComboBox.
		 * Method to get selected Status in MultiCombobox
		 * @param oEvent - the click event.
		 * @private
		 */
		onStatusClick: function (oEvent) {
			var oSource = oEvent.getSource();
			var filterModel = this.getOwnerComponent().getModel("filterModel");
			filterModel.setProperty("/Status",oSource.getSelectedKeys());
			if(filterModel.getProperty("/Status").length > 0){
				filterModel.setProperty("/StatusFilterCount",filterModel.getProperty("/Status").length);
			} else {
				filterModel.setProperty("/StatusFilterCount",0);
			}
		},
		/*****************Owner  item select ******/
		/**
		 * Function is called when you select the Owner in the List.
		 * Method to get Selected items in List 
		 * @param oEvent - the click event.
		 * @private
		 */
		onOwnerListClick: function (oEvent) {
			var mParams = oEvent.getParameters();
			var filterModel = this.getOwnerComponent().getModel("filterModel");
			var oOwner = filterModel.getProperty("/Owner");
			jQuery.each(mParams.listItems, function (i, oItem) {
				if (oItem.getSelected()) {
					oOwner.push(oItem.getInfo());
				} else {
					var oIndex = oOwner.indexOf(oItem.getInfo());
					oOwner.splice(oIndex, 1);
				}
			});
			if(oOwner.length > 0){
				filterModel.setProperty("/OwnerFilterCount",oOwner.length);
			} else {
				filterModel.setProperty("/OwnerFilterCount",0);
			}
		},
		/********resets the filter values*******/
		/**
		 * Function is called when you select the reset button in Filter Dialogue.
		 * Method to reset the Filter values 
		 * @private
		 */
		onResetFilterValues: function () {
			var oStatusDropDownList = sap.ui.getCore().byId("idStatusDropDownList");
			var oModel = this.getOwnerComponent().getModel("filterModel");
			var sSearchValue = oModel.getProperty("/SearchValue");
			var oData = {
				"H5": "",
				"Description": "",
				"ExternalDescription": "",
				"validOn": "",
				"Status": [],
				"Owner": [],
				"Selectedkey": [],
				"Statuskey": [],
				"OwnerFilterCount":0,
				"StatusFilterCount":0,
				"ValidOnFilterCount":0,
				"SearchValue":sSearchValue
			};
			oModel.setProperty("/",oData);
			var OwnerList = sap.ui.getCore().byId("idOwnerList");
			OwnerList.removeSelections(true);
			oStatusDropDownList.setSelectedKeys([]);
		},
		/**
		 * @param oEvent - the click event.
		 * Here we also cehcking the Authorization by calling the CheckAuthorization function import 
		 * Navigates to DetailPage With RevisionNumber as a Parameter
		 **/
		onRevisionButtonPress: function (oEvent) {
			// var oSrc = oEvent.getSource().getCustomData()[0].getValue();
			var that = this;
			var oView = that.getView();
			var urlParam;
			var oControl = oEvent.getSource();
			var oRevisionNumber = oControl.data("MAButtonFlag");
			var oContext = oControl.getBindingContext().getObject();
			var oRevisionType = oContext.RevisionType;
			var oDataModel = oView.getModel();
			var MARevisionRoutingModel = that.getOwnerComponent().getModel("MARevisionRoutingModel");
			if (oContext.AdminFields.IsEditable) {
				urlParam = {
					Activity: "02",
					DocumentType: oRevisionType
				};
			} else {
				urlParam = {
					Activity: "03",
					DocumentType: oRevisionType
				};
			}
			oDataModel.callFunction("/CheckAuthorization", {
				method: "POST",
				urlParameters: urlParam,
				success: function (oData, response) {
					MARevisionRoutingModel.setProperty("/IsRoutedWithMANum",false);
					MARevisionRoutingModel.setProperty("/IsRoutedWithRevisionNum",true);
					that._oRouter.navTo("DetailAgreements", {
							DocumentNumber: oRevisionNumber
						},
						false);
				},
				error: function (oError) {}
			});

		}

	});
});