sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/ecolab/ZASBMasterAgr/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	'sap/m/MessageBox',
	'com/ecolab/ZASBMasterAgr/model/xlsx.core.min',
	'sap/ui/core/format/NumberFormat'
], function (UIComponent, Controller, JSONModel, formatter, Filter, Sorter, FilterOperator, MessageToast, MessageBox, xlsx, NumberFormat) {
	"use strict";
	return Controller.extend("com.ecolab.ZASBMasterAgr.controller.EditAgreement", {
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the EditAgreement controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var me = this;
			var oView = this.getView();
			me.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			me._oRouter = sap.ui.core.UIComponent.getRouterFor(me);
			me._oRouter.getRoute("EditAgreement").attachPatternMatched(this._onEditAgreementMatched, this);
			var oDropdownData = {
				"SalesOrg": [],
				"DistributionChannel": [],
				"Division": [],
				"ProfitCenter": [],
				"AgreementCategory": [],
				"LegalAgreementStatus": [],
				"PriceAdjType": [],
				"PriceAdjFreq": [],
				"PaymentTerms:": [],
				"MOPIndicator": [],
				"HierApprovalReq": [],
				"CommunicationMethod": [],
				"FieldCommLevel": [],
				"AgrPriceRanking": [],
				"PrefInvDelivery": [],
				"ProductCategory": [],
				"AgrMaterialsOnly": [],
				"DistributorApproval": [],
				"PortfolioID": [],
				"PriceGroup": [],
				"AreDropdownValuesReceived":false
			};
			var oDropdownModel = new JSONModel(oDropdownData);
			oView.setModel(oDropdownModel, "DropdownModel");
			oDropdownModel.setSizeLimit(1020);
			var oEditModel = new JSONModel();
			oView.setModel(oEditModel, "EditModel");
			//Listener function to update ProductChanged flag depening on user modification
			oEditModel.attachPropertyChange({}, this._propertyChangeCheck, this);

			//Notes related Model
			var oNotesModel = new JSONModel();
			oView.setModel(oNotesModel, "NotesModel");

			var oAssetModel = new JSONModel(jQuery.sap.getModulePath("com.ecolab.ZASBMasterAgr.model", "/localmodel.json"));
			oView.setModel(oAssetModel, "oAssetModel");

			var oCountryModel = new JSONModel();
			oView.setModel(oCountryModel, "CountryModel");
			oCountryModel.setSizeLimit(1020);
			var messageModel = new JSONModel();
			oView.setModel(messageModel, "messageModel");
			messageModel.setData({
				show: false
			});
			var oMessageProcessor = new sap.ui.core.message.ControlMessageProcessor();
			var oMessageManager = sap.ui.getCore().getMessageManager();
			oMessageManager.registerMessageProcessor(oMessageProcessor);

			this.productsUploadErrMsgs = [];
			this.discountOffDeleteOldFlag = [];
			this.OnInvoiceDiscountsDeleteOldFlag = [];

			this.oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-ddT00:00:00",
				UTC: true
			});
			
			//To create a initial map of file type to content MIME type for file upload
			this.createFileTypeToContentTypeMap();
			
			//EBS Owner input having tabular suggestion view with filtering.
			//As on version 1.44 of UI5 input control with tabular suggestion having inconcistent implementation between suggestion table
			//and SelectTableDialogue hence this logic
			var oOwnerInput = this.byId("ebsOwnerInput");
			oOwnerInput.setSuggestionRowValidator(this.ownerSuggestionRowValidator);
			oOwnerInput.setFilterSuggests(true);
			oOwnerInput.setFilterFunction(this.filterOwnerSuggestionResults);

			//Code to populate the EBS Owner input by invoking row seletion in suggestion table.
			this.ebsOwnerInputSet = false;
			this.getOwnerComponent().getModel().attachRequestCompleted({},this.handleODataEntityLoading, this);
			
			// Country dropdown
			this._getCountryDropdown();
		},

		/**
		 * Listener function to update ProductChanged flag depening on user modification
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_propertyChangeCheck: function (oEvent) {
			//Product view change flag updation
			var oModel = this.getView().getModel("EditModel");
			var oContext = oEvent.getParameter("context");
			if (oContext && oContext.getPath().indexOf("EditableProducts") && oModel.getProperty(
					oContext.getPath() + "/ProductChanged") !== "N" && oModel.getProperty(
					oContext.getPath() + "/ProductChanged") !== "I" && oEvent.getParameter && (oEvent.getParameter("path") === "NewRate" || oEvent.getParameter(
						"path") === "NewPer" || oEvent.getParameter("path") === "NewConditionKey" || oEvent.getParameter("path") ===
					"NewPriceInclFreight" || oEvent.getParameter("path") === "NewGovtBids" || oEvent.getParameter("path") === "NewOriginalAgreement")) {
				if (oModel.getProperty(oContext.getPath() + "/ChangeFlag") !== "E") {
					oModel.setProperty(oContext.getPath() + "/ProductChanged", "U");
				} else {
					oModel.setProperty(oContext.getPath() + "/ProductChanged", "N");
				}
			}
			//To change the asset Change Flag to reflect weather an asset modified from its initial copy.
			else if (oContext && oContext.getPath().indexOf("EditableAssets") && oModel.getProperty(
					oContext.getPath() + "/ChangeFlag") !== "N" && oModel.getProperty(
					oContext.getPath() + "/ChangeFlag") !== "I" && oEvent.getParameter && (oEvent.getParameter("path") === "Rate" || oEvent.getParameter(
						"path") === "Terms" || oEvent.getParameter("path") === "MPPRAmount" || oEvent.getParameter("path") === "ExcessRackCharge" ||
					oEvent.getParameter("path") === "CorpSign" || oEvent.getParameter("path") === "LegalAgreement" || oEvent.getParameter("path") ===
					"HQPay" || oEvent.getParameter("path") === "SummaryBill" || oEvent.getParameter("path") === "BillingDay" || oEvent.getParameter(
						"path") === "NewConditionKey" || oEvent.getParameter("path") === "EligibleFOCPeriod" || oEvent.getParameter("path") ===
					"AgreementMachOnly" || oEvent.getParameter("path") === "SpecialInstructions" || oEvent.getParameter("path") === "SecurityDeposit"
				)) {
				oModel.setProperty(oContext.getPath() + "/ChangeFlag", "U");
			}
			//To change the discountoff Change Flag to reflect weather an asset modified from its initial copy.
			else if (oContext && oContext.getPath().indexOf("EditableDiscountOffSet") && oModel.getProperty(
					oContext.getPath() + "/ChangeFlag") !== "N" && oModel.getProperty(
					oContext.getPath() + "/ChangeFlag") !== "I" && oEvent.getParameter && (oEvent.getParameter("path") === "Rate" || oEvent.getParameter(
						"path") === "CustomerNumber"
				)) {
				oModel.setProperty(oContext.getPath() + "/ChangeFlag", "U");
			}
			//To change the OnInvoiceDiscount Change Flag from its initial copy.
			else if (oContext && oContext.getPath().indexOf("EditableOnInvoiceDiscountSet") && oModel.getProperty(
					oContext.getPath() + "/ChangeFlag") !== "N" && oModel.getProperty(
					oContext.getPath() + "/ChangeFlag") !== "I" && oEvent.getParameter && (oEvent.getParameter("path") === "Rate" || oEvent.getParameter(
						"path") === "CustomerNumber"
				)) {
				oModel.setProperty(oContext.getPath() + "/ChangeFlag", "U");
			}
		},
		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onEditAgreementMatched: function (oEvent) {
			var oView = this.getView();
			if (oEvent.getParameter("name") === "EditAgreement") {
				//Making FLP Backbutton visible as it was hidden in the first page
				sap.ui.getCore().byId("backBtn").setVisible(true);
				var sDocumentNumber = oEvent.getParameter("arguments").DetailAgreementId;
				if (sDocumentNumber === "" || sDocumentNumber === undefined) {
					sDocumentNumber = "";
				}
				this.sDocumentNumber = sDocumentNumber;
				this._bindView("/HeaderSet('" + this.sDocumentNumber + "')", this.sDocumentNumber);
				var oEditData = {
					"PreviousBtn": false,
					"NextBtn": true,
					"SaveBtn": true,
					"SubmitBtn": false,
					"DiscardBtn": true,
					"HeaderInfoTab": true,
					"PricingTab": false,
					"DiscountsTab": false,
					"SurchargeTab": false,
					"AttachmentsTab": false,
					"NotesTab": false,
					"ChangeEffectiveDate": new Date(),
					"ChangeEffectiveDateEnable": true,
					"sObjectId": "",
					"EditableProducts": [],
					"EditablePriceExcep": [],
					"EditableFlatFee": [],
					"MaterialSearch": {
						"MaterialNum": "",
						"MaterialDesc": "",
						"Status": "",
						"SelectedStatuses": [],
						"SelectedMaterial": "",
						"SelectedMaerialDesc": "",
						"MaterialValueHelpSet": [],
						"tableBusy": false
					},
					"HeaderInfoErrorDetails": {
						"DescriptionState": "None",
						"ValidFromState": "None",
						"ValidToState": "None",
						"SalesOrgState": "None",
						"DistributionChannelState": "None",
						"DivisionState": "None",
						"ProfitCenterState": "None",
						"EBSOwnerState": "None",
						"AgrCategoryState": "None",
						"EffectiveChangeDate":"None"
					}
				};
				oView.getModel("EditModel").setData(oEditData);
				oView.getModel("EditModel").setProperty("/sObjectId", this.sDocumentNumber);
				oView.getModel("EditModel").updateBindings(false);
				var NextBtnModel = this.getOwnerComponent().getModel("NextBtnModel");
				var Icontab = oView.byId("idIconTabBar");
				if(Icontab.getSelectedKey() === "PricingTabKey" && NextBtnModel.getProperty("/IsNextBtnPressed")){
					oView.getModel("EditModel").setProperty("/DiscardBtn", false);
					oView.getModel("EditModel").setProperty("/PreviousBtn", true);
					oView.getModel("EditModel").setProperty("/PricingTab", true);
					oView.getModel("EditModel").setProperty("/HeaderInfoTab", false);
					oView.getModel("EditModel").setProperty("/ChangeEffectiveDateEnable", false);
				} else {
					Icontab.setSelectedKey("HeaderInfoKey");
				}
				// Attachment related 
				this._getDataForAttachments();
				oView.getModel().resetChanges();
			}
			
			//Code to populate EffectiveChangeDate incase it is empty
			this.EffectiveChangeDateSet = false;
		},
		/**
		 * Binds the view to the object path.
		 * @param {String} sObjectPath path to the object to be bound
		 * @param {String} sDocumentNumber document number for view binding
		 * @private
		 */
		_bindView: function (sObjectPath, sDocumentNumber) {
			var oView = this.getView();
			var oDropdownModel = oView.getModel("DropdownModel");
			oView.bindElement({
				path: sObjectPath
			});
			if(!oDropdownModel.getProperty("/AreDropdownValuesReceived")){
				this._onDropdownSets("Header", "ValueFields", "SalesOrg");
				this._onDropdownSets("Header", "ValueFields", "DistributionChannel");
				this._onDropdownSets("Header", "ValueFields", "Division");
				this._onDropdownSets("Header", "ValueFields", "ProfitCenter");
				this._onDropdownSets("Header", "ValueFields", "AgreementCategory");
				this._onDropdownSets("Header", "ValueFields", "AgreementClass");
				this._onDropdownSets("Header", "ValueFields", "LegalAgreementStatus");
				this._onDropdownSets("Header", "ValueFields", "PriceAdjType");
				this._onDropdownSets("Header", "ValueFields", "PriceAdjFreq");
				this._onDropdownSets("Header", "ValueFields", "PaymentTerms");
				this._onDropdownSets("Header", "ValueFields", "MOPIndicator");
				this._onDropdownSets("Header", "ValueFields", "HierApprovalReq");
				this._onDropdownSets("Header", "ValueFields", "CommunicationMethod");
				this._onDropdownSets("Header", "ValueFields", "FieldCommLevel");
				this._onDropdownSets("Header", "ValueFields", "AgrPriceRanking");
				this._onDropdownSets("Header", "ValueFields", "PrefInvDelivery");
				this._onDropdownSets("Header", "ValueFields", "ProductCategory");
				this._onDropdownSets("Header", "ValueFields", "AgrMaterialsOnly");
				this._onDropdownSets("Header", "ValueFields", "DistributorApproval");
				this._onDropdownSets("Header", "ValueFields", "PortfolioID");
				this._onDropdownSets("Asset", "", "BillingDay");
				this._onDropdownSets("Asset", "", "BillingFrequency");
				this._onDropdownSets("Asset", "", "LegalAgreement");
				this._onDropdownSets("DiscountOff", "", "PriceGroup");
				this._onDropdownSets("OnInvoiceDiscount", "", "MaterialType");
			}
			this._getNotesData();
		},

		/**
		 * Function is called when Component.js loaded .
		 * Method to populate it binds all the dropdown fields
		 * @param {String} sEntityName to retrive droupdown set
		 * @param {String} sComplexType to retrive droupdown set
		 * @param {String} sEntityProperty to retrive for given sEntityName/sComplexType
		 * @private
		 */
		_onDropdownSets: function (sEntityName, sComplexType, sEntityProperty) {
			var oView = this.getView();
			var sPath = "/SelectSet(EntityName='" + sEntityName + "',ComplexType='" + sComplexType + "',EntityProperty='" + sEntityProperty +
				"')";
			var oModel = oView.getModel();
			var oDropdownModel = oView.getModel("DropdownModel");
			var oBusyIndicator = new sap.m.BusyDialog();
			oBusyIndicator.open();
			oModel.read(sPath, {
				async: true,
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					oBusyIndicator.close();
					if (oData.EntityProperty !== "") {
						oDropdownModel.setProperty("/" + oData.EntityProperty, oData.FieldProperties.KeyValueSet.results);
						oDropdownModel.setProperty("/AreDropdownValuesReceived",true);
					}
					oDropdownModel.updateBindings(true);
				},
				error: function (oError) {
					oBusyIndicator.close();
				}
			});
		},

		/**
		 * Function is called when you click on post MessageBox ok Button press .
		 * Method to populate it handles front Errors.
		 * @param {sap.ui.base.Event} oEvent object
		 * @private
		 * @return {boolean} boolean value with error status
		 */
		onHeaderInfoValidations: function (oEvent) {
			var that = this;
			var oView = that.getView();
			var oEditModel = oView.getModel("EditModel");
			var error = false;
			var oCurrentObj = oEvent.getSource().getBindingContext().getObject();
			that._IsEffectiveChangeDateValid = false;
			oEditModel.setProperty("/HeaderInfoErrorDetails/DescriptionState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/SalesOrgState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/DistributionChannelState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/DivisionState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/ProfitCenterState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/EBSOwnerState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/AgrCategoryState", "None");
			oEditModel.setProperty("/HeaderInfoErrorDetails/EffectiveChangeDate", "None");
			if (oCurrentObj.ValueFields.EffectiveChangeDate === null || oCurrentObj.ValueFields.EffectiveChangeDate === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/EffectiveChangeDate", "Error");
			}
			if (oCurrentObj.ValueFields.Description === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/DescriptionState", "Error");
			}
			if (oCurrentObj.ValueFields.BusinessPartner === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/BusinessPartner", "Error");
			}			
			if (oCurrentObj.ValueFields.ValidFrom === null) {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/ValidFromState", "Error");
			}
			if (oCurrentObj.ValueFields.ValidTo === null) {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/ValidToState", "Error");
			}
			if (oCurrentObj.ValueFields.SalesOrg === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/SalesOrgState", "Error");
			}
			if (oCurrentObj.ValueFields.DistributionChannel === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/DistributionChannelState", "Error");
			}
			if (oCurrentObj.ValueFields.Division === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/DivisionState", "Error");
			}
			if (oCurrentObj.ValueFields.ProfitCenter === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/ProfitCenterState", "Error");
			}
			if (oCurrentObj.ValueFields.PortfolioID === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/EBSOwnerState", "Error");
			}
			if (oCurrentObj.ValueFields.AgreementCategory === "") {
				error = true;
				oEditModel.setProperty("/HeaderInfoErrorDetails/AgrCategoryState", "Error");
			}
			if ((oCurrentObj.ValueFields.EffectiveChangeDate >= oCurrentObj.ValueFields.ValidFrom) && (oCurrentObj.ValueFields.EffectiveChangeDate <= oCurrentObj.ValueFields.ValidTo)) {
				that._IsEffectiveChangeDateValid = true;
			} else {
				error = true;
			}
			
			//Invalid date inputs Error status check
			if (oView.byId("headerEffectiveChangeDate").getValueState() === "Error"
				|| oView.byId("headerCMAEffectiveChangeDate").getValueState() === "Error"
				|| oView.byId("headerValidFrom").getValueState() === "Error"
				|| oView.byId("headerValidTo").getValueState() === "Error"
				|| oView.byId("headerLegalStartDate").getValueState() === "Error"
				|| oView.byId("headerLegalEndDate").getValueState() === "Error"
				|| oView.byId("headerLastPriceAdjDate").getValueState() === "Error"
				|| oView.byId("headerPricePlanAdjDate").getValueState() === "Error") {
				error = true;
			}		
			return error;
		},
		
		/**
		 * Function to populate Owner input control in header section. This function called after every odata read call and owner 
		 * input is pouplated depending on PortfolioID and HierarchyType of header section
		 * @private
		 * @param {Object} oData response data
		 * @param {function} fnFunction callback function
		 * @param {Object} oListener listener object
		 * 
		 */
		handleODataEntityLoading: function(oData, fnFunction, oListener){
			var oDataModel = this.getOwnerComponent().getModel();

			//Updating EffectiveChangeDate to current date if empty
			var withTimeZone = new Date();
			if(!this.EffectiveChangeDateSet && oDataModel.getObject("/HeaderSet('')") 
				&& oDataModel.getObject("/HeaderSet('')").ValueFields
				&& !oDataModel.getObject("/HeaderSet('')").ValueFields.EffectiveChangeDate){
			//	oDataModel.setProperty("/HeaderSet('')/ValueFields/EffectiveChangeDate", new Date(Date.UTC(withTimeZone.getFullYear(), withTimeZone.getMonth(), withTimeZone.getDate(),0,0,0,0)));//new Date((new Date()).setHours(0,0,0,0)));//oDataModel.getProperty("/HeaderSet('')/ValueFields/ValidFrom"));
				oDataModel.setProperty("/HeaderSet('')/ValueFields/ValidFrom", new Date(Date.UTC(withTimeZone.getFullYear(), withTimeZone.getMonth(), withTimeZone.getDate(),0,0,0,0)));
				this.EffectiveChangeDateSet = true;
			} /*else if(!this.EffectiveChangeDateSet && oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')") 
				&& oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields
				&& !oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.EffectiveChangeDate){
				oDataModel.setProperty("/HeaderSet('" + this.sDocumentNumber + "')/ValueFields/EffectiveChangeDate", new Date(Date.UTC(withTimeZone.getFullYear(), withTimeZone.getMonth(), withTimeZone.getDate(),0,0,0,0)));//new Date((new Date()).setHours(0,0,0,0)));
				this.EffectiveChangeDateSet = true;
			}*/
			
			//Invoked if HeaderSet response comes after ebsOwnerInput suggested values loading 
			// if(!this.ebsOwnerInputSet && oData.getParameter("url").indexOf("HeaderSet") !== -1 && oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')") && oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.PortfolioID !== ""){
				if(this.getView().byId("ebsOwnerInput").getSuggestionRows() && oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')") && oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.PortfolioID && oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.PortfolioID !== ""){
					for(var idx = 0; idx < this.getView().byId("ebsOwnerInput").getSuggestionRows().length; idx++){
						if(this.getView().byId("ebsOwnerInput").getSuggestionRows()[idx].getBindingContext().getObject().PortfolioID === oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.PortfolioID
						&& this.getView().byId("ebsOwnerInput").getSuggestionRows()[idx].getBindingContext().getObject().HierarchyType === oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.HierarchyType){
							this.getView().byId("ebsOwnerInput").setSelectedRow(this.getView().byId("ebsOwnerInput").getSuggestionRows()[idx]);
							//this.ebsOwnerInputSet = true;
						}
					}
				}
			// }
			//Invoked if HeaderSet response comes before ebsOwnerInput suggested values loading 
			if(this.getView().byId("ebsOwnerInput").getSuggestionRows() 
				&& oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')") 
				&& oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields
				&& oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.PortfolioID){
				for(var idx = 0; idx < this.getView().byId("ebsOwnerInput").getSuggestionRows().length; idx++){
					if(this.getView().byId("ebsOwnerInput").getSuggestionRows()[idx].getBindingContext().getObject().PortfolioID === oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.PortfolioID
					&& this.getView().byId("ebsOwnerInput").getSuggestionRows()[idx].getBindingContext().getObject().HierarchyType === oDataModel.getObject("/HeaderSet('" + this.sDocumentNumber + "')").ValueFields.HierarchyType){
						this.getView().byId("ebsOwnerInput").setSelectedRow(this.getView().byId("ebsOwnerInput").getSuggestionRows()[idx]);
						// this.ebsOwnerInputSet = true;
					}
				}
			}
		},

		/**
		 * Function to show tabular value help with Selection Table Dialog
		 * @private
		 */
		handleEbsOwnerValueHelp : function () {
			// create value help dialog
			if (!this._ebsOwnerValueHelp) {
				this._ebsOwnerValueHelp = sap.ui.xmlfragment(
					"com.ecolab.ZASBMasterAgr.fragment.edit.EbsOwnerValueHelpDialog",
					this
				);
				this.getView().addDependent(this._ebsOwnerValueHelp);
			}

			// open value help dialog
			this._ebsOwnerValueHelp.open();
		},
		
		/**
		 * Input control with tabular suggestion needs a core Item to display the selected value.
		 * Upon row selection in tabular suggestion validator creates a dummy item to diaplay selected row content
		 * @param {sap.m.ColumnListItem}  oColumnListItem - Selected Row inside tabular suggestion
		 * @private
		 */
		ownerSuggestionRowValidator: function (oColumnListItem) {
			var aCells = oColumnListItem.getCells();
			return new sap.ui.core.Item({
				key: aCells[1].getText(),
				text: aCells[0].getText()
			});
		},

		/**
		 * Funtion to update the model binding property with selected Key. Here
		 * Key is send to backend as a change. During the diplay other table columns are used. 
		 * In this case EBS Name and ProfileID are used.
		 * @param {sap.ui.base.Event} oEvent - Event object to work with selected row
		 * @private
		 */
		ownerSuggestionItemSelected: function (oEvent) {
			var src = oEvent.getSource();
			var oModelContext = src.getBindingContext();
			var oModel = oModelContext.getModel();
			if(oEvent.getParameter("selectedRow") && oEvent.getParameter("selectedRow").getBindingContext()){
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/PortfolioID",oEvent.getParameter("selectedRow").getBindingContext().getObject().PortfolioID);
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/HierarchyType",oEvent.getParameter("selectedRow").getBindingContext().getObject().HierarchyType);
			}else{
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/PortfolioID","");
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/HierarchyType","");
			}
		},
		
		/**
		 * Function that takes the user typed value in EBS Owner and Row in suggestion table.
		 * Based ser typed value it determines weather a row elegible for diplay or not
		 * @param {String} sValue - User typed text
		 * @param {sap.m.ColumnListItem} oColumnListItem - ColumnListItem object
		 * @returns {boolean} Boolean value true to diplay the or false to hide
		 * @private
		 */
		 filterOwnerSuggestionResults : function (sValue, oColumnListItem) {
		 	var aCells = oColumnListItem.getCells();
			return ( !sValue || sValue === "" ||
					aCells[0].getText() && (aCells[0].getText().toUpperCase().indexOf(sValue.toUpperCase())) !== -1 || 
					aCells[1].getText() && (aCells[1].getText().toUpperCase().indexOf(sValue.toUpperCase())) !== -1  || 
					aCells[2].getText() && (aCells[2].getText().toUpperCase().indexOf(sValue.toUpperCase())) !== -1  || 
					aCells[3].getText() && (aCells[3].getText().toUpperCase().indexOf(sValue.toUpperCase())) !== -1  || 
					aCells[4].getText() && (aCells[4].getText().toUpperCase().indexOf(sValue.toUpperCase())) !== -1 );
		},
		
		/**
		 * Function to filter Price Group Drop Down values in Discounts off table.
		 * @private
		 * @param {String} sTerm string to search for
		 * @param {Object} oItem object to do the contains check
		 * @return {boolean} boolean value with true if search string matches
		 */
		filterPriceGroupItems: function(sTerm, oItem){
			// A case-insensitive 'string contains' style filter
			return oItem.getText().match(new RegExp(sTerm, "i"));
		},
		
		/**
		 * Function to invoke suggestion filtering if use does the selection from EBS Owner input value help dialog
		 * @param {sap.ui.base.Event} oEvent - Eevent object to retrive the source table an check its row for diplay/hide
		 * @private
		 */
		handleEBSOwnerSearch: function(oEvent){
			var that = this;
			var aTabularRows = oEvent.getSource().getItems();
			var sTypedChars = oEvent.getParameter("value");
			for (var i = 0; i < aTabularRows.length; i++) {
				if (that.filterOwnerSuggestionResults(sTypedChars, aTabularRows[i])) {
					aTabularRows[i].setVisible(true);
				} else {
					aTabularRows[i].setVisible(false);
				}
			}
		},
		
		/**
		 * Function to confirm the EBS Owner selection form EBS Owner Input value help dialogue
		 * @param {sap.ui.base.Event} oEvent - Event to get the selected row
		 * @private
		 */
		handleEBSOwnerConfirm: function(oEvent) {
			this.getView().byId("ebsOwnerInput").setSelectedRow(oEvent.getParameter("selectedItem"));
			var src = oEvent.getSource();
			var oModelContext = src.getBindingContext();
			var oModel = oModelContext.getModel();
			if(oEvent.getParameter("selectedItem") && oEvent.getParameter("selectedItem").getBindingContext()){
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/PortfolioID", oEvent.getParameter("selectedItem").getBindingContext().getObject().PortfolioID);
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/HierarchyType", oEvent.getParameter("selectedItem").getBindingContext().getObject().HierarchyType);
			}else{
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/PortfolioID", "");
				oModel.setProperty(oModelContext.getPath() + "/ValueFields/HierarchyType", "");
			}
		},
		
		/**
		 * Function to validate date inputs given in header section
		 * @param {sap.ui.base.Event} oEvent - Event to get the selected row
		 * @private
		 */
		validateDateChange: function(oEvent){
			var src = oEvent.getSource();
			var oEditModel = src.getModel("EditModel");
			if(src.getBinding("valueState")){
				oEditModel.setProperty(src.getBinding("valueState").getPath(), "None");
			}else{
				src.setValueState("None");
			}
			if(src.getValue().trim() !== "" && new Date(src.getValue()) == "Invalid Date"){
				if(src.getBinding("valueState")){
					oEditModel.setProperty(src.getBinding("valueState").getPath(), "Error");
				}else{
					src.setValueState("Error");
				}
			}else if(src.getValue().trim() !== ""){
				var oModel = src.getModel();
				var bindingContextPath = src.getBindingContext().getPath();
				var valueBindingPath = src.getBinding("value").getPath();
				var withTimeZone = new Date(src.getValue());
				oModel.setProperty(bindingContextPath + "/" + valueBindingPath, new Date(Date.UTC(withTimeZone.getFullYear(), withTimeZone.getMonth(), withTimeZone.getDate(),0,0,0,0)));// new Date(withTimeZone.setHours(0,0,0,0)));//new Date(Date.UTC(withTimeZone.getFullYear(), withTimeZone.getMonth(), withTimeZone.getDate(),0,0,0,0)));
				if(valueBindingPath === "ValueFields/EffectiveChangeDate" && (oModel.getObject(bindingContextPath).ValueFields.RevisionType === "CMA")){
					oModel.setProperty(bindingContextPath + "/ValueFields/ValidFrom", new Date(Date.UTC(withTimeZone.getFullYear(), withTimeZone.getMonth(), withTimeZone.getDate(),0,0,0,0)));
				}
			}
		},
		
		/**
		 * Function is called when combobox selection Changes .
		 * Method to populate it validate all the combobox.
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onComboBoxValidate: function (oEvent) {
			var ComboBox = oEvent.getSource();
			var Items = ComboBox.getItems();
			var Arr = [];
			var value = ComboBox.getValue().trim();
			for (var i = 0; i < Items.length; i++) {
				Arr.push(Items[i].getText());
			}
			if (Arr.indexOf(value) < 0) {
				ComboBox.setValueState("Error");
			} else {
				ComboBox.setValueState("None");
			}
		},

		/**
		 * Function is called when InputField Value changes .
		 * Method to validate InputField value as per SpreadSheet and throw error.
		 * @param oEvent - the click event.
		 * @private
		 */
		onValidateMinPriceAdjPerc: function (oEvent) {
			var oSource = oEvent.getSource();
			var oValue = oSource.getValue();
			var oNumber = isNaN(oValue);
			// Here oValue should not be more than 10 
			if (oValue > 10 || oNumber === true) {
				oSource.setValueState("Error");
			} else {
				oSource.setValueState("None");
			}
		},

		/**
		 * Function is called when InputField Value changes .
		 * Method to validate InputField value as per SpreadSheet and throw error.
		 * @param oEvent - the click event.
		 * @private
		 */
		onValidateMaxPriceAdjPerc: function (oEvent) {
			var oSource = oEvent.getSource();
			var oValue = oSource.getValue();
			var oNumber = isNaN(oValue);
			// Here oValue should not be more than 100 
			if (oValue > 100 || oNumber === true) {
				oSource.setValueState("Error");
			} else {
				oSource.setValueState("None");
			}
		},

		/**
		 * Function is called when InputField Value changes .
		 * Method to validate InputField value as per SpreadSheet and throw error.
		 * @param oEvent - the click event.
		 * @private
		 */
		onValidateAdjPercRate: function (oEvent) {
			var oSource = oEvent.getSource();
			var oValue = oSource.getValue();
			var oNumber = isNaN(oValue);
			var DecimalCheck = oValue.toString().split(".")[1].length;
			if (oValue !== "") {
				// Here oValue should not be more than 100
				//DecimalCheck should not be more than 2
				if (oValue > 100 || oNumber === true || DecimalCheck > 2) {
					oSource.setValueState("Error");
				} else {
					oSource.setValueState("None");
				}
			}
		},

		/**
		 * Function is called when InputField Value changes .
		 * Method to validate InputField value as per SpreadSheet and throw error.
		 * @param oEvent - the click event.
		 * @private
		 */
		onValidateAdvanceNotice: function (oEvent) {
			var oSource = oEvent.getSource();
			var oValue = oSource.getValue();
			if (Number.isInteger(oValue) || oValue >= 0) {
				oSource.setValueState("None");
			} else {
				oSource.setValueState("Error");
			}
		},

		/**
		 * Function is called when click on message-popup Button press .
		 * Method to populate it handles all messages.
		 * @param oEvent - the click event.
		 * @private
		 */
		onMessagePopoverPress: function (oEvent) {
			var me = this;
			if (!me.oMessagePopover) {
				var oMessageTemplate = new sap.m.MessagePopoverItem({
					type: '{message>type}',
					title: '{message>message}',
					description: '{message>description}'
				});
				me.oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: 'message>/',
						template: oMessageTemplate
					}
				});
				me.oMessagePopover.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
			}
			me.oMessagePopover.openBy(oEvent.getSource());
		},

		/**
		 * Function is called when click on ok Button press .
		 * Method to populate it handles all Success,Error,Warning messages.
		 * @param oEvent - the click event.
		 * @private
		 */
		handleSucessWarningMsgs: function (oData, error) {
			var me = this;
			var sMessage;
			var oXML;
			var oXMLMessage;
			var oXMLH1;
			var oMessageProcessor = new sap.ui.core.message.ControlMessageProcessor();
			var oMessageManager = sap.ui.getCore().getMessageManager();
			if (error) {
				var errorMsg = "";
				if (error.responseText) {
					if(error.responseText.indexOf('{"') !== -1){
						var responseTextError = JSON.parse(error.responseText).error;
						if(responseTextError.innererror){
							if(responseTextError.innererror.errordetails && responseTextError.innererror.errordetails.length > 0){
								errorMsg = responseTextError.innererror.errordetails[0].message;
							} else {
								errorMsg = responseTextError.message.value;
							}
						} else if(responseTextError.message) {
							errorMsg = responseTextError.message.value;
						}
					} else {
						oXML = jQuery.parseXML(error.responseText);
						oXMLMessage = oXML.querySelector("message");
						oXMLH1 = oXML.querySelector("h1");
						if(oXMLMessage !== null && oXMLMessage.length > 0){
							errorMsg = oXMLMessage[0].childNodes[0].nodeValue;
						} else {
							errorMsg = oXMLH1.childNodes[0].nodeValue;
						}
					}
					sMessage = new sap.ui.core.message.Message({
						type: me.bundle.getText("Error"),
						message: me.bundle.getText("ErrorMsg"),
						description: errorMsg,
						processor: oMessageProcessor
					});
					oMessageManager.addMessages(sMessage);
				} else if (error.response && error.response.body) {
					errorMsg = JSON.parse(error.response.body).error.message.value;
					sMessage = new sap.ui.core.message.Message({
						type: me.bundle.getText("Error"),
						message: me.bundle.getText("ErrorMsg"),
						description: errorMsg,
						processor: oMessageProcessor
					});
					oMessageManager.addMessages(sMessage);
				} else if (error.responseRaw) {
					oXML = jQuery.parseXML(error.responseRaw);
					oXMLMessage = oXML.querySelector("message");
					if(oXMLMessage.length > 0){
						errorMsg = oXMLMessage[0].childNodes[0].nodeValue;
						sap.m.MessageBox.show(me.bundle.getText("errorText"), {
							title: me.bundle.getText("Error"),
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						sMessage = new sap.ui.core.message.Message({
							type: me.bundle.getText("Error"),
							message: me.bundle.getText("ErrorMsg"),
							description: errorMsg,
							processor: oMessageProcessor
						});
						oMessageManager.addMessages(sMessage);
					} else if(oXMLMessage.textContent) {
						errorMsg = oXMLMessage.textContent;
						sap.m.MessageBox.show(me.bundle.getText("errorText"), {
							title: me.bundle.getText("Error"),
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						sMessage = new sap.ui.core.message.Message({
							type: me.bundle.getText("Error"),
							message: me.bundle.getText("ErrorMsg"),
							description: errorMsg,
							processor: oMessageProcessor
						});
						oMessageManager.addMessages(sMessage);
					}
				} else if (error.response) {
					sMessage = new sap.ui.core.message.Message({
						type: me.bundle.getText("Error"),
						message: me.bundle.getText("ErrorMsg"),
						description: error.response,
						processor: oMessageProcessor
					});
					oMessageManager.addMessages(sMessage);
				}
			}
		},

		/**
		 * Method to handle Post call Payload.
		 * @param oControl - the click event control.
		 * @private
		 */
		_prepareHeaderInfoPayload: function (oControl) {
			var me = this;
			var oDataModel = me.getView().getModel();
			var oNotesModel=me.getView().getModel("NotesModel");
			var newNotes=oNotesModel.getProperty("/Notes");
			var oldNotes = oDataModel.getObject("/ManagementNoteSet('" + me.sDocumentNumber + "')");
			var oPayLoad = oControl.getBindingContext().getObject();
			var oValueFields = oPayLoad.ValueFields;
			var oPayLoadData = {
				"ValueFields": {
					"AdvanceNotice": oValueFields.AdvanceNotice,
					"AgreementCategory": oValueFields.AgreementCategory,
					"AgreementClass": oValueFields.AgreementClass,
					"AgreementNumber": oValueFields.AgreementNumber,
					"AgrMaterialsOnly": oValueFields.AgrMaterialsOnly,
					"AgrPriceRanking": oValueFields.AgrPriceRanking,
					"ApplyOrderBudget": oValueFields.ApplyOrderBudget,
					"AutoRenewal": oValueFields.AutoRenewal,
					"BusinessPartner": oValueFields.BusinessPartner,
					"BusinessPartnerHierarchy": oValueFields.BusinessPartnerHierarchy,
					"CommunicationMethod": oValueFields.CommunicationMethod,
					"CorpHQBillToNum": oValueFields.CorpHQBillToNum,
					"CorpHQPayerNum": oValueFields.CorpHQPayerNum,
					"Description": oValueFields.Description,
					"DistributionChannel": oValueFields.DistributionChannel,
					"DistributorApproval": oValueFields.DistributorApproval,
					"Division": oValueFields.Division,
					"DocumentType": oValueFields.DocumentType,
					"ExternalDescription": oValueFields.ExternalDescription,
					"ExtraordinaryLang": oValueFields.ExtraordinaryLang,
					"FieldCommLevel": oValueFields.FieldCommLevel,
					"HierApprovalReq": oValueFields.HierApprovalReq,
					"LastPriceAdjDate": oValueFields.LastPriceAdjDate,
					"LastPriceAdjRate": oValueFields.LastPriceAdjRate,
					"LegalAgreementStatus": oValueFields.LegalAgreementStatus,
					"LegalEndDate": oValueFields.LegalEndDate,
					"LegalStartDate": oValueFields.LegalStartDate,
					"MaxPriceAdjPerc": oValueFields.MaxPriceAdjPerc,
					"MinPriceAdjPerc": oValueFields.MinPriceAdjPerc,
					"MOPIndicator": oValueFields.MOPIndicator,
					"MostFavCustomer": oValueFields.MostFavCustomer,
					"MSLNumber": oValueFields.MSLNumber,
					"OwnerNum": oValueFields.OwnerNum,
					"OwnerRole": oValueFields.OwnerRole,
					"HierarchyType":oValueFields.HierarchyType,
					"PaymentTerms": oValueFields.PaymentTerms,
					"PONumRequired": oValueFields.PONumRequired,
					"PortfolioID": oValueFields.PortfolioID,
					"PrefInvDelivery": oValueFields.PrefInvDelivery,
					"PriceAdjFreq": oValueFields.PriceAdjFreq,
					"PriceAdjType": oValueFields.PriceAdjType,
					"PricePlanAdjDate": oValueFields.PricePlanAdjDate,
					"PricePlanAdjPerc": oValueFields.PricePlanAdjPerc,
					"PricePlanVersion": oValueFields.PricePlanVersion,
					"PricingAgreement": oValueFields.PricingAgreement,
					"ProductCategory": oValueFields.ProductCategory,
					"ProfitCenter": oValueFields.ProfitCenter,
					"RelatedAgrID": oValueFields.RelatedAgrID,
					"RevisionNumber": oValueFields.RevisionNumber,
					"RevisionType": oValueFields.RevisionType,
					"SalesOrg": oValueFields.SalesOrg,
					"TaxExemptFormReq": oValueFields.TaxExemptFormReq,
					"TerminationClause": oValueFields.TerminationClause,
					"ThirdPartyDesignator": oValueFields.ThirdPartyDesignator,
					"ThirdPartyName": oValueFields.ThirdPartyName,
					"EffectiveChangeDate": oValueFields.EffectiveChangeDate,
					"UnitNumRequired": oValueFields.UnitNumRequired,
					"ValidFrom": oValueFields.ValidFrom,
					"ValidTo": oValueFields.ValidTo,
					"VersionNumber": oValueFields.VersionNumber
				},
				"AdminFields": {
					"ChangeFlag": oPayLoad.AdminFields.ChangeFlag
				},
				"DocumentNumber": oPayLoad.DocumentNumber,
				"ETAG":oPayLoad.ETAG,
				"ProductSet": {
					"results": []
				},
				"PriceExceptionSet": {
					results: []
				},
				"FlatFeeSet": {
					results: []
				},
				"AssetSet": {
					results: []
				},
				"DiscountOffSet": {
					results: []
				},
				"OnInvoiceDiscountSet": {
					results: []
				},
				"ManagementNoteSet": {
					"NoteText":""
					
				}
			};
			if (newNotes && oldNotes) {
				if (newNotes.NoteText !== oldNotes.NoteText) {
					oPayLoadData.ManagementNoteSet = {
						"NoteText": newNotes.NoteText
					};
				} else {
					oPayLoadData.ManagementNoteSet = {
						"NoteText": oldNotes.NoteText
					};
				}
			}
			return oPayLoadData;
		},
		
		/**
		 * This method handles the post call 
		 * @ param {event} - the click event
		 * @ oCustomData - Based on oCustomData the Next Button Functionality works 
		 * @oPayload - we are passing payload to the post call
		 */
		_onCreateRevision: function (oEvent, oCustomData, oPayload, sSelectedKey) {
			var me = this;
			var oView = me.getView();
			var oModel = oView.getModel();
			var Icontab = oView.byId("idIconTabBar");
			var oEditModel = oView.getModel("EditModel");
			var MARevisionRoutingModel = me.getOwnerComponent().getModel("MARevisionRoutingModel");
			//edited by Shinjan - Saving should always happen with Revision number, not any document number.
			oPayload.DocumentNumber = oPayload.ValueFields.RevisionNumber;
			oModel.create("/HeaderSet", oPayload, {
				method: "POST",
				success: function (oData, oResponse) {
					oModel.setProperty(me.getView().getBindingContext().sPath + "/ValueFields/RevisionNumber", oData.ValueFields.RevisionNumber);
					MessageBox.show(
						me.bundle.getText("HeaderInfoSuccess", [oData.ValueFields.RevisionNumber]), {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [MessageBox.Action.OK],
							onClose: function (oAction) {
								if (sSelectedKey === "HeaderInfoKey" || sSelectedKey === "PricingTabKey" || sSelectedKey === "DiscountsTabKey") {
									me._getDataForTabs(sSelectedKey);
								}
								if (oCustomData === "Next") {
									me._onNextPress();
								}
								if(sSelectedKey === "HeaderInfoKey"){
									// In Some cases we are having Master Agreement number but not the revision Number .So in that case we have to save the details with revision number only
									// Here we are Navigating bacause we are passing the revision Number to the pattern 
									me._oRouter.navTo("EditAgreement", {
										DetailAgreementId: oData.ValueFields.RevisionNumber
									}, true);
								/*	me.sDocumentNumber = oData.ValueFields.RevisionNumber;
									var sPath = "/HeaderSet('"+me.sDocumentNumber+"')";
									oView.bindElement({
										path: sPath
									});
									oView.getModel("EditModel").setProperty("/sObjectId", me.sDocumentNumber);*/
								}
							}
						});
				},
				error: function (error, resp) {
					if(error.statusCode === "412"){
						sap.m.MessageBox.show(me.bundle.getText("sameRevisionEditWarnMsg"), {
							title: me.bundle.getText("Warning"),
							icon: sap.m.MessageBox.Icon.WARNING,
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {
								if(MARevisionRoutingModel.getProperty("/IsRoutedWithRevisionNum")){
									me._oRouter.navTo("DetailAgreements", {
										DocumentNumber: me.sDocumentNumber
									}, false);
								} else {
									me._oRouter.navTo("DetailAgreements", {
										DocumentNumber: oModel.getProperty("/HeaderSet('"+me.sDocumentNumber+"')/ValueFields/AgreementNumber")
									}, false);
								}
							}
						});
					} else {
						sap.ui.getCore().getMessageManager().removeAllMessages();
						me.handleSucessWarningMsgs("", error);
					}
				}
			});
		},

		/**
		 * Function is called when click on  Save Button press .
		 * Method to handle Saving the revision .
		 * @param oEvent - the click event.
		 * @param oCustomData - it is a parameter 
		 * @private
		 */
		onEditDetailsSavePress: function (oEvent, oCustomData) {
			var me = this;
			var oCurrentObject=oEvent.getSource().getBindingContext().getObject();
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var Icontab = oView.byId("idIconTabBar");
			var sSelectedKey = Icontab.getSelectedKey();
			var oHeaderInfoPayload, oPricingPayload, oDiscountsload,OnInvoiceDiscountsload;
			var hasErrors = false;
			var hasonInvoiceErrors=false;
			switch (sSelectedKey) {
			case "HeaderInfoKey":
				if (!me.onHeaderInfoValidations(oEvent)) {
					oHeaderInfoPayload = me._prepareHeaderInfoPayload(oEvent.getSource());
					me._onCreateRevision(oEvent, oCustomData, oHeaderInfoPayload,sSelectedKey);
				}else{
					if(!me._IsEffectiveChangeDateValid){
						MessageBox.error(me.bundle.getText("EffectiveDateError"), {
							title: me.bundle.getText("Error"),
							actions: [MessageBox.Action.OK]
						});
					} else {
						MessageBox.error(me.bundle.getText("SaveHeaderError"), {
							title: me.bundle.getText("Error"),
							actions: [MessageBox.Action.OK]
						});
					}
				}
				break;
			case "PricingTabKey":
				oHeaderInfoPayload = me._prepareHeaderInfoPayload(oEvent.getSource());
				oPricingPayload = me._preparePricingPayload(oHeaderInfoPayload);
				//Error dialogue if there any product has errors
				if(!this._isProductsValid() || me._hasProductsWithErrors(oHeaderInfoPayload.ProductSet.results)) {
					MessageBox.error(me.bundle.getText("SavePricingProdError"), {
						title: me.bundle.getText("Error"),
						actions: [MessageBox.Action.OK]
					});
					hasErrors = true;
				} 

				//Error dialogue if there any product has errors
				if(!this._isPriceExceptionsValid() && !hasErrors) {
					MessageBox.error(me.bundle.getText("SavePriceExceptionError"), {
						title: me.bundle.getText("Error"),
						actions: [MessageBox.Action.OK]
					});
					hasErrors = true;
				} 
				if(!this._isFlatFeeManagementValid() && !hasErrors) {
					MessageBox.error(me.bundle.getText("FlatFeeManagementError"), {
						title: me.bundle.getText("Error"),
						actions: [MessageBox.Action.OK]
					});
					hasErrors = true;
				} 
		
				//Check weather for all mandatory inputs of assets
				var oAassetWithErrors = me._getAssetsWithErrors(oEditModel.getProperty("/EditableAssets"));
				if (oAassetWithErrors) {
					oEditModel.updateBindings(false);
					me._setAsssetCarouselActivePage(oAassetWithErrors.ProductHierarchy);
					if (!hasErrors) {
						MessageBox.error(me.bundle.getText("SavePricingAssetError"), {
							title: me.bundle.getText("Error"),
							actions: [MessageBox.Action.OK]
						});
						hasErrors = true;
					}
				}

				if (!hasErrors) {
					me._onCreateRevision(oEvent, oCustomData, oPricingPayload, sSelectedKey);
				}
				break;
			case "DiscountsTabKey":
				oHeaderInfoPayload = me._prepareHeaderInfoPayload(oEvent.getSource());
				oPricingPayload = me._preparePricingPayload(oHeaderInfoPayload);
				oDiscountsload = me._prepareDiscountsPayload(oHeaderInfoPayload);
				OnInvoiceDiscountsload=me._prepareOnInvoiceDiscountsPayload(oHeaderInfoPayload);
				//Error dialogue if there any product has errors
				if(!this._isDiscountsOffValid()){
					MessageBox.error(me.bundle.getText("SaveDiscountsOffError"), {
						title: me.bundle.getText("Error"),
						actions: [MessageBox.Action.OK]
					});
					hasErrors = true;
				}else if(!this._isOnInVoiceDiscountsOffValid()){
					MessageBox.error(me.bundle.getText("SaveOnInvoiceDiscountsError"), {
						title: me.bundle.getText("Error"),
						actions: [MessageBox.Action.OK]
					});
					hasErrors = true;
				}
				if(!hasErrors){
					me._onCreateRevision(oEvent, oCustomData, OnInvoiceDiscountsload, sSelectedKey);
				}
				break;
			case "SurchargeTabKey":
				me._getDataForAttachments();
				me._onNextPress();
				break;
			case "AttachmentsTabKey":
				me._getNotesData();
				me._onNextPress();
				var oAdminFields=oCurrentObject.AdminFields.UserStatus;
				if(oAdminFields ==="E0001" || oAdminFields ==="E0004"){
					oEditModel.setProperty("/SaveBtn", false);
				}else{
					oEditModel.setProperty("/SaveBtn", true);
				}
				break;
			case "NotesTabKey":
				var oNotesModel=me.getView().getModel("NotesModel");
				var oNotesData=oNotesModel.getProperty("/Notes/NoteText");
				oHeaderInfoPayload = me._prepareHeaderInfoPayload(oEvent.getSource());
				oHeaderInfoPayload.ManagementNoteSet.NoteText=oNotesData;
				me._onCreateRevision(oEvent, oCustomData, oHeaderInfoPayload);
			}
		},

		/**
		 * Function to clear input error state of src control. This is done by changing the valueState propety to None 
		 * @param {object} oEvent
		 * to None in its binding context model path.
		 */
		clearInputErrorState: function (oEvent) {
			var src = oEvent.getSource();
			if(src.getBindingInfo("valueState")){
				if(src.getBindingContext("EditModel")){
					src.getModel("EditModel").setProperty(src.getBindingContext("EditModel").getPath() + "/" + src.getBindingInfo("valueState").binding.getPath(), "None");
				}else{
					src.setValueState("None");
				}	
			}
		},

		/**
		 * Function to check weathre there is any product with errors in pricing tab
		 * @param oProductSet - ProductSet to verify the ChangeFlag.
		 * @private
		 * @return {boolean} true is return of any product with ChangeFlag E else false
		 */
		_hasProductsWithErrors: function (oProductSet) {
			var hasErrors = false;
			oProductSet.forEach(function (oProduct, idx) {
				if (oProduct && oProduct.ChangeFlag === "E") {
					hasErrors = true;
				}
			});
			return hasErrors;
		},

		/**
		 * Function to check weathre there is any asset with invalid inputs in pricing tab
		 * @private 
		 * @param {object} oAssetSet - AssetSet to verify the inputs.
		 * @return {object} returns asset object that has erros else false is returned
		 */
		_getAssetsWithErrors: function (oAssetSet) {
			var oAassetWithErrors = false;
			oAssetSet.forEach(function (oAsset, idx) {
				if(oAsset.ChangeFlag !== "D"){
					if (!oAsset.PriceGroup || oAsset.PriceGroup === "") {
						oAsset.PriceGroupState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.PriceGroupState = "None";
					}
	
					if (!oAsset.Rate || oAsset.Rate === "") {
						oAsset.RateState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.RateState = "None";
					}
	
					if (!oAsset.Terms || oAsset.Terms === "") {
						oAsset.TermsState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.TermsState = "None";
					}
	
					if (!oAsset.MPPRAmount || oAsset.MPPRAmount === "") {
						oAsset.MPPRAmountState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.MPPRAmountState = "None";
					}
	
					if (!oAsset.FreeLoads || oAsset.FreeLoads === "") {
						oAsset.FreeLoadsState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.FreeLoadsState = "None";
					}
	
					if (!oAsset.ExcessRackCharge || oAsset.ExcessRackCharge === "") {
						oAsset.ExcessRackChargeState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.ExcessRackChargeState = "None";
					}
	
					if (!oAsset.BillingFrequency || oAsset.BillingFrequency === "") {
						oAsset.BillingFrequencyState = "Error";
						oAassetWithErrors = oAsset;
					} else {
						oAsset.BillingFrequencyState = "None";
					}
				}
			});
			return oAassetWithErrors;
		},
		
		/**
		 * Function that returns approval note dialgoue object
		 * @private
		 * @returns {Control} Dialog control
		 */	
		_getApprovalNotesDialog: function () {
			if (!this._ApprovalNoteDialog) {
				this._ApprovalNoteDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.edit.SubmitNoteDlg", this);
				this.getView().addDependent(this._ApprovalNoteDialog);
			}
			return this._ApprovalNoteDialog;
		},
		
		/**
		 * Function to show Approval note dialogue.
		 * @private
		 */	
		onSubmitPress: function () {
			var oView = this.getView();
			var EditModel = oView.getModel("EditModel");
			if(EditModel.getProperty("/ActorComment")){
				EditModel.setProperty("/ActorComment","");
			}
			this._getApprovalNotesDialog().open();	
		},

		/**
		 * Function is called when click on  Submit Button press and while ending the Agreement.
		 * Method handles Submitting the revision and navigates to display view.
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onConfirmSubmitPress: function (oEvent) {
			var that = this;
			var oView = that.getView();
			var oDataModel = oView.getModel();
			var EditModel = oView.getModel("EditModel");
			var clearNotes = false;
			var managementComments = '';
			var oCurrentObject = oEvent.getSource().getBindingContext().getObject();
			var oNotesModel = oView.getModel("NotesModel");
			var newNotes = oNotesModel.getProperty("/Notes");
			var oldNotes = oDataModel.getObject("/ManagementNoteSet('" + this.sDocumentNumber + "')");
			var oBusyDialog = new sap.m.BusyDialog();
			if (newNotes && oldNotes) {
				if (newNotes.NoteText !== oldNotes.NoteText) {
					managementComments = newNotes.NoteText;
					if (newNotes.NoteText === "" || newNotes.NoteText.length === 0) {
						clearNotes = true;
					}
				}
			}
			/*if (newNotes && oldNotes) {
				if (newNotes.NoteText !== oldNotes.NoteText) {
					managementComments = newNotes.NoteText;
				}
			}*/
			var oChangeEffectiveDate = oCurrentObject.ValueFields.EffectiveChangeDate;
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: 'dd MMM YYYY',
				UTC: true
			});
			oChangeEffectiveDate = oDateFormat.format(new Date(oChangeEffectiveDate));
			var ActCommentValue=EditModel.getProperty("/ActorComment");
			var urlParam = {
				DocumentNumber: oCurrentObject.ValueFields.RevisionNumber,
				NoteText: managementComments,
				ActorComment: ActCommentValue === undefined ? "" : ActCommentValue,
				ClearNotes: clearNotes
			};
			if (that.EndAgreement) {
				urlParam.EffectiveChangeDate = oChangeEffectiveDate;
				delete urlParam.ClearNotes;
			}
			oBusyDialog.open();
			oDataModel.callFunction("/Submit", {
				method: "POST",
				urlParameters:urlParam,
				success: function (oData, response) {
					oBusyDialog.close();
					that._getApprovalNotesDialog().close();
					MessageBox.show(
						that.bundle.getText("SubmitInfo", [oCurrentObject.ValueFields.RevisionNumber]), {
							icon: MessageBox.Icon.SUCCESS,
							title: that.bundle.getText("Success"),
							actions: [MessageBox.Action.OK],
							onClose: function (oAction) {
								that._oRouter.navTo("MasterAgreements", {},false);
							}
						});
				},
				error: function (oError) {
					oBusyDialog.close();
					that._getApprovalNotesDialog().close();
					sap.ui.getCore().getMessageManager().removeAllMessages();
					that.handleSucessWarningMsgs("", oError);
				}
			});
		},
		
		/**
		 * Function to close Approval submit note dialogue
		 * @private
		 */		
		onCancelSubmitPress: function () {
			this._getApprovalNotesDialog().close();
		},

		/*
		 * Function is called when you click on Discard Button .
		 * Method to discard the entire revision
		 * Navigates to DetailPage When it is ACR
		 * Navigates to MasterPage when it is CMA
		 * @param oEvent - the click event.
		 * @private
		 */
		onDiscardButtonPress: function (oEvent) {
			var me = this;
			var oView = me.getView();
			var oDataModel = oView.getModel();
			var NoteText = "";
			var oCurrentObject = oEvent.getSource().getBindingContext().getObject();
			MessageBox.confirm(me.bundle.getText("WarningDiscardMsg", [oCurrentObject.ValueFields.RevisionNumber]), {
				title: me.bundle.getText("Confirm"),
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (sAction) {
					if (sAction === "YES") {
						if (oCurrentObject && oCurrentObject.ValueFields.RevisionNumber !== "") {
							oDataModel.callFunction("/Discard", {
								method: "POST",
								urlParameters: {
									"DocumentNumber": oCurrentObject.ValueFields.RevisionNumber,
									"NoteText": NoteText
								},
								success: function (oData, response) {
									oDataModel.updateBindings(true);
									MessageBox.show(
										me.bundle.getText("DiscardInfo", [oCurrentObject.ValueFields.RevisionNumber]), {
											icon: MessageBox.Icon.SUCCESS,
											title: me.bundle.getText("Success"),
											actions: [MessageBox.Action.OK],
											onClose: function (oAction) {
												me._oRouter.navTo("MasterAgreements", {}, false);
											}
										});
								},
								error: function (oError) {
									sap.ui.getCore().getMessageManager().removeAllMessages();
									me.handleSucessWarningMsgs("", oError);
								}
							});
						} else {
							oDataModel.resetChanges();
							me._oRouter.navTo("MasterAgreements", {}, false);
						}
					}
				}
			});
		},

		/*
		 * @param oEvent - the click event.
		 * Navigates to Previous Tab In IconTabbar based on keys
		 */
		onPreviousButtonPress: function (oEvent) {
			var oView = this.getView();
			var Icontab = oView.byId("idIconTabBar");
			var oModel = oView.getModel("EditModel");
			switch (Icontab.getSelectedKey()) {
			case "PricingTabKey":
				Icontab.setSelectedKey("HeaderInfoKey");
				oModel.setProperty("/DiscardBtn", true);
				oModel.setProperty("/PreviousBtn", false);
				oModel.setProperty("/PricingTab", false);
				oModel.setProperty("/HeaderInfoTab", true);
				oModel.setProperty("/ChangeEffectiveDateEnable", true);
				oModel.setProperty("/SaveBtn", true);
				break;
			case "DiscountsTabKey":
				Icontab.setSelectedKey("PricingTabKey");
				oModel.setProperty("/DiscountsTab", false);
				oModel.setProperty("/PricingTab", true);
				oModel.setProperty("/SaveBtn", true);
				break;
			case "SurchargeTabKey":
				Icontab.setSelectedKey("DiscountsTabKey");
				oModel.setProperty("/SurchargeTab", false);
				oModel.setProperty("/DiscountsTab", true);
				oModel.setProperty("/SaveBtn", true);
				break;
			case "AttachmentsTabKey":
				Icontab.setSelectedKey("SurchargeTabKey");
				oModel.setProperty("/AttachmentsTab", false);
				oModel.setProperty("/SurchargeTab", true);
				oModel.setProperty("/SaveBtn", false);
				break;
			case "NotesTabKey":
				Icontab.setSelectedKey("AttachmentsTabKey");
				oModel.setProperty("/NextBtn", true);
				oModel.setProperty("/SaveBtn", false);
				oModel.setProperty("/SubmitBtn", false);
				oModel.setProperty("/NotesTab", false);
				oModel.setProperty("/AttachmentsTab", true);
				break;
			}
			Icontab.rerender();
		},

		/**
		 *  @param oEvent - the click event.
		 * Function is called when click on Next Button .
		 * Method to Save and navigates to Next Tab based on keys
		 * @private
		 */
		onNextButtonPress: function (oEvent) {
			var oSource = oEvent.getSource();
			var oCustomData = oSource.data("NextKey");
			var NextBtnModel = this.getOwnerComponent().getModel("NextBtnModel");
			NextBtnModel.setProperty("/IsNextBtnPressed",true);
			this.onEditDetailsSavePress(oEvent, oCustomData);
		},

		/*
		 * This function switch the tab view buttons/controls according to the tab selected
		 * @param oEvent - the click event.
		 * Navigates to Next Tab In IconTabbar based on keys
		 */
		_onNextPress: function (oEvent) {
			var oView = this.getView();
			var Icontab = oView.byId("idIconTabBar");
			var oModel = oView.getModel("EditModel");
			switch (Icontab.getSelectedKey()) {
			case "HeaderInfoKey":
				Icontab.setSelectedKey("PricingTabKey");
				oModel.setProperty("/DiscardBtn", false);
				oModel.setProperty("/PreviousBtn", true);
				oModel.setProperty("/PricingTab", true);
				oModel.setProperty("/HeaderInfoTab", false);
				oModel.setProperty("/ChangeEffectiveDateEnable", false);
				break;
			case "PricingTabKey":
				Icontab.setSelectedKey("DiscountsTabKey");
				oModel.setProperty("/DiscountsTab", true);
				oModel.setProperty("/PricingTab", false);
				break;
			case "DiscountsTabKey":
				Icontab.setSelectedKey("SurchargeTabKey");
				oModel.setProperty("/SurchargeTab", true);
				oModel.setProperty("/DiscountsTab", false);
				oModel.setProperty("/SaveBtn", false);
				break;
			case "SurchargeTabKey":
				Icontab.setSelectedKey("AttachmentsTabKey");
				oModel.setProperty("/AttachmentsTab", true);
				oModel.setProperty("/SurchargeTab", false);
				oModel.setProperty("/SaveBtn", false);
				break;
			case "AttachmentsTabKey":
				Icontab.setSelectedKey("NotesTabKey");
				oModel.setProperty("/NextBtn", false);
				oModel.setProperty("/SubmitBtn", true);
				oModel.setProperty("/NotesTab", true);
				oModel.setProperty("/AttachmentsTab", false);
				break;
			}
			Icontab.rerender();
		},

		/**
		 * Function is called when we naviagte to pricing Tab .
		 * Method to populate Country dropdown fields in FlatFee table
		 * @private
		 */
		_getCountryDropdown: function () {
			var oView = this.getView();
			var aCountryModel = oView.getModel("CountryModel");
			var sPath = "/SelectSet(EntityName='Header',ComplexType='ValueFields',EntityProperty='Country')";
			var oFliters = new Filter([new Filter("Country", "EQ", "US"), new Filter("Country", "EQ", "CA")], false);
			var oModel = this.getOwnerComponent().getModel();
			oModel.read(sPath, {
				filters: [oFliters],
				urlParameters: {
					"$expand": "FieldProperties/KeyValueSet"
				},
				success: function (oData, oResponse) {
					aCountryModel.setProperty("/", oData);
				},
				error: function (oError) {}
			});
		},

		/**
		 *This function will be called when moved to Next tab or on save.
		 * After getting response from service we are preparing data for EditModel to bind view content.
		 * @param sSelectedKey - key of the current tab
		 * @private
		 */
		_getDataForTabs: function (sSelectedKey) {
			var me = this;
			var oView = this.getView();
			var oModel = oView.getModel();
			var oHeaderData = oView.getModel().getObject("/HeaderSet('" + this.sDocumentNumber + "')/ValueFields");
			var sAgreementNumber = oHeaderData.AgreementNumber;
			var sRevisionNumber = oHeaderData.RevisionNumber;
			var sDocumentNumber = sRevisionNumber ? sRevisionNumber : sAgreementNumber;
			var expandParams;
			if(sSelectedKey === "HeaderInfoKey"){
				expandParams = "ProductSet,PriceExceptionSet,FlatFeeSet,AssetSet";
			} else if(sSelectedKey === "PricingTabKey"){
				expandParams = "ProductSet,PriceExceptionSet,FlatFeeSet,AssetSet,DiscountOffSet,OnInvoiceDiscountSet";
			} else {
				expandParams = "ProductSet,PriceExceptionSet,FlatFeeSet,AssetSet,DiscountOffSet,OnInvoiceDiscountSet";
			}
			$.when(sAgreementNumber && sRevisionNumber).done(function () {
				oModel.setHeaders({
					"get_delta": "X"
				});
				oModel.read("/HeaderSet('" + sDocumentNumber + "')", {
					urlParameters: {
						"$expand": expandParams
					},
					success: function (oData) {
						me._prepareDataForPricingTab(oData.ProductSet.results, oData.PriceExceptionSet.results, oData.FlatFeeSet.results, oData.DiscountOffSet.results, oData.OnInvoiceDiscountSet.results, oData.AssetSet);
						oModel.setHeaders({});
					},
					error: function (oError) {}
				});
			});
		},

		/**
		 * This function will be called After getting the response from /HeaderSet to prepare data that 
		 * is required for pricing tab bindings. This data is kept in EditModel
		 * @param {array} aProducts - Products array from the oData service response
		 * @private
		 */
		_prepareDataForPricingTab: function (aProducts, aPriceExceptions, aFlatFee, aDiscountOffs, aOnInvoiceDiscounts, oAssetSet) {
			var aEditableProducts = [];
			var aEditableFlatFee = [];
			var aEditablePriceExceptions = [];
			var aEditableDiscountOffs = [];
			var aEditableOnInvoiceDiscounts=[];
			var aEditable = [];
			var oEditableAssets = {};
			var oEditModel = this.getView().getModel("EditModel");
			var oEditModelData = oEditModel.getData();

			//Restructuring Products 
			if (aProducts) {
				oEditModel.setProperty("/EditableProducts", aEditableProducts);
				aProducts.forEach(function (oProduct, idx) {
					aEditableProducts.push({
						MaterialNumber: oProduct.MaterialNumber,
						MaterialDesc: oProduct.MaterialDesc,
						DocumentNumber: oProduct.DocumentNumber,
						ValidFrom: oProduct.ValidFrom,
						ValidTo: oProduct.ValidTo,
						NewRate: oProduct.Rate,
						NewPer: oProduct.Per,
						Currency: oProduct.Currency,
						Unit: oProduct.Unit,
						ConditionNumber: oProduct.ConditionNumber,
						ConditionNumber2: oProduct.ConditionNumber2,
						NewConditionType: oProduct.ConditionType,
						NewConditionKey: oProduct.ConditionKey,
						NewConditionKeyDesc: oProduct.ConditionKeyDesc,
						NewGovtBids: oProduct.GovtBids,
						NewPriceInclFreight: oProduct.PriceInclFreight,
						NewOriginalAgreement: oProduct.OriginalAgreement,
						ChangeFlag: oProduct.ChangeFlag,
						Message: oProduct.Message,
						HasPPViolation: oProduct.HasPPViolation,
						PPViolation: oProduct.PPViolation,
						PPSeverity: oProduct.PPSeverity,
						PPViolationText: oProduct.PPViolationText,
						DivisionDesc: oProduct.DivisionDesc,
						IsChPending: oProduct.IsChPending,
						
						//From Delta JSON
						OldRate: oProduct.Delta.Rate,
						OldPer: oProduct.Delta.Per,
						OldConditionType: oProduct.Delta.ConditionType,
						OldConditionKey: oProduct.Delta.ConditionKey,
						OldConditionKeyDesc: oProduct.Delta.ConditionKeyDesc,
						OldGovtBids: oProduct.Delta.GovtBids,
						OldPriceInclFreight: oProduct.Delta.PriceInclFreight,
						OldOriginalAgreement: oProduct.Delta.OriginalAgreement,

						//From DeltCh JSON
						RateFlag: oProduct.DeltaCh.Rate,
						PerFlag: oProduct.DeltaCh.Per,
						ConditionTypeFlag: oProduct.DeltaCh.ConditionType,
						ConditionKeyFlag: oProduct.DeltaCh.ConditionKey,
						GovtBidsFlag: oProduct.DeltaCh.GovtBids,
						PriceInclFreightFlag: oProduct.DeltaCh.PriceInclFreight,
						OriginalAgreementFlag: oProduct.DeltaCh.OriginalAgreement,
						ChangeIcon: ""
					});

					aEditableProducts[idx].MaterialEditable = false;
					aEditableProducts[idx].ProductDeleted = aEditableProducts[idx].ChangeFlag === "D";
					aEditableProducts[idx].ProductUnDeleted = aEditableProducts[idx].ChangeFlag === "R";
					aEditableProducts[idx].ProductInserted = aEditableProducts[idx].ChangeFlag === "I";
					aEditableProducts[idx].ValidRate = true;
					aEditableProducts[idx].MaterialNumberStatus = "None";
					aEditableProducts[idx].NewPerStatus = "None";
					
					//Adding additional property that indicates table change
					if (!Object.getOwnPropertyDescriptor(oEditModelData.EditableProducts[idx], "ProductChanged")) {
						Object.defineProperty(oEditModelData.EditableProducts[idx], "ProductChanged", {
							set: function () {},
							get: function () {
								if (this.ProductDeleted) {
									return "D";
								} else if (this.ProductUnDeleted) {
									return "R";
								} else if (this.ProductInserted) {
									return "I";
								} else if(this.ChangeFlag === "N"){
									return "N";
								} else if ((this.ChangeFlag === "U" || this.ChangeFlag === "" ) && (this.RateFlag || this.PerFlag || this.ConditionKeyFlag ||
									this.GovtBidsFlag || this.PriceInclFreightFlag || this.OriginalAgreementFlag)) {
									return "U";
								} else {
									return "";
								}
							}
						});
					}
				});
			}

			//Restructuring PriceExceptions
			if (aPriceExceptions) {
				oEditModel.setProperty("/EditablePriceExceptions", aEditablePriceExceptions);
				aPriceExceptions.forEach(function (oPriceException, idx) {
					aEditablePriceExceptions.push({
						CustomerNumber: oPriceException.CustomerNumber,
						CustomerDesc: oPriceException.CustomerDesc,
						MaterialNumber: oPriceException.MaterialNumber,
						MaterialDesc: oPriceException.MaterialDesc,
						DocumentNumber: oPriceException.DocumentNumber,
						NewRate: oPriceException.Rate,
						NewConditionType: oPriceException.ConditionType,
						NewConditionKey: oPriceException.ConditionKey,
						NewConditionKeyDesc: oPriceException.ConditionKeyDesc,
						NewPriceInclFreight: oPriceException.PriceInclFreight,
						Currency: oPriceException.Currency,
						NewPer: oPriceException.Per,
						ConditionNumber: oPriceException.ConditionNumber,
						Unit: oPriceException.Unit,
						ChangeFlag: oPriceException.ChangeFlag,
						HasPPViolation: oPriceException.HasPPViolation,
						PPViolation: oPriceException.PPViolation,
						PPSeverity: oPriceException.PPSeverity,
						PPViolationText: oPriceException.PPViolationText,
						DivisionDesc: oPriceException.DivisionDesc,
						IsChPending: oPriceException.IsChPending,
						
						//From Delta JSON
						OldRate: oPriceException.Delta.Rate,
						OldPer: oPriceException.Delta.Per,
						OldConditionType: oPriceException.Delta.ConditionType,
						OldConditionKey: oPriceException.Delta.ConditionKey,
						OldConditionKeyDesc: oPriceException.Delta.ConditionKeyDesc,
						OldPriceInclFreight: oPriceException.Delta.PriceInclFreight,

						//From DeltCh JSON
						PriceExpRateFlag: oPriceException.DeltaCh.Rate,
						PerFlag: oPriceException.DeltaCh.Per,
						PriceExpConditionTypeFlag: oPriceException.DeltaCh.ConditionType,
						PriceExpConditionKeyFlag: oPriceException.DeltaCh.ConditionKey,
						PriceExpPriceInclFreightFlag: oPriceException.DeltaCh.PriceInclFreight,
						ChangeIcon: ""
					});

					aEditablePriceExceptions[idx].CustomerEditable = false;
					aEditablePriceExceptions[idx].MaterialEditable = false;
					aEditablePriceExceptions[idx].PriceExpDeleted = aEditablePriceExceptions[idx].ChangeFlag === "D";
					aEditablePriceExceptions[idx].PriceExpUnDeleted = aEditablePriceExceptions[idx].ChangeFlag === "R";
					aEditablePriceExceptions[idx].PriceExpInserted = aEditablePriceExceptions[idx].ChangeFlag === "I";
					aEditablePriceExceptions[idx].ValidRate = true;
					aEditablePriceExceptions[idx].CustomerNumberState = "None";
					aEditablePriceExceptions[idx].MaterialNumberState = "None";
					aEditablePriceExceptions[idx].NewPerStatus = "None";
					
					//Adding additional property that indicates table change
					if (!Object.getOwnPropertyDescriptor(oEditModelData.EditablePriceExceptions[idx], "PriceExpChanged")) {
						Object.defineProperty(oEditModelData.EditablePriceExceptions[idx], "PriceExpChanged", {
							set: function () {},
							get: function () {
								if (this.PriceExpDeleted) {
									return "D";
								} else if (this.PriceExpUnDeleted) {
									return "R";
								} else if (this.PriceExpInserted) {
									return "I";
								} else if (this.PriceExpRateFlag || this.PerFlag || this.PriceExpConditionKeyFlag || this.PriceExpPriceInclFreightFlag) {
									return "U";
								} else {
									return "";
								}
							}
						});
					}
				});
			}

			//FlatFee related
			if (aFlatFee) {
				oEditModel.setProperty("/EditableFlatFee", aEditableFlatFee);
				aFlatFee.forEach(function (oFlatFee, index) {
					aEditableFlatFee.push({
						ConditionKey: oFlatFee.ConditionKey,
						CustomerNumber: oFlatFee.CustomerNumber,
						CustomerDesc: oFlatFee.CustomerDesc,
						MaterialNumber: oFlatFee.MaterialNumber,
						MaterialDesc: oFlatFee.MaterialDesc,
						DocumentNumber: oFlatFee.DocumentNumber,
						ProgramType: oFlatFee.PriceGroup,
						ProgramTypeDesc: oFlatFee.PriceGroupDesc,
						ChangeFlag: oFlatFee.ChangeFlag,
						NewUnitPrice: oFlatFee.UnitPrice,
						ConditionType: oFlatFee.ConditionType,
						ConditionTable: oFlatFee.ConditionTable,
						ConditionNumber: oFlatFee.ConditionNumber,
						Rate: oFlatFee.Rate,
						Currency: oFlatFee.Currency,
						Per: oFlatFee.Per,
						Unit: oFlatFee.Unit,
						BillingDay: oFlatFee.BillingDay,
						BillingFrequency: oFlatFee.BillingFrequency,
						IsChPending: oFlatFee.IsChPending,

						// Delta
						BillingDayOld: oFlatFee.Delta.BillingDay,
						BillingFrequencyOld: oFlatFee.Delta.BillingFrequency,
						BillingFrequencyDescOld: oFlatFee.Delta.BillingFrequencyDesc,
						OldUnitPrice: oFlatFee.Delta.UnitPrice,
						// DeltaCh
						UnitPriceFlag: oFlatFee.DeltaCh.UnitPrice,
						ChangeIcon: ""
					});
					aEditableFlatFee[index].CustomerEditable = false;
					aEditableFlatFee[index].MaterialEditable = false;
					aEditableFlatFee[index].ProgramTypeDescEditable = false;
					aEditableFlatFee[index].FlatFeeDeleted = aEditableFlatFee[index].ChangeFlag === "D";
					aEditableFlatFee[index].FlatFeeUnDeleted = aEditableFlatFee[index].ChangeFlag === "R";
					aEditableFlatFee[index].FlatFeeInserted = aEditableFlatFee[index].ChangeFlag === "I";
					aEditableFlatFee[index].ValidUnitPrice = true;
					aEditableFlatFee[index].ConditionKeyState = "None";
					aEditableFlatFee[index].CustomerNumberState = "None";
					aEditableFlatFee[index].ProgramTypeDescState = "None";
					//Adding additional property that indicates table change
					if (!Object.getOwnPropertyDescriptor(oEditModelData.EditableFlatFee[index], "FlatFeeChanged")) {
						Object.defineProperty(oEditModelData.EditableFlatFee[index], "FlatFeeChanged", {
							set: function () {},
							get: function () {
								if (this.FlatFeeDeleted) {
									return "D";
								} else if (this.FlatFeeUnDeleted) {
									return "R";
								} else if (this.FlatFeeInserted) {
									return "I";
								} else if (this.UnitPriceFlag || this.BillingDayFlag || this.BillingFrequencyFlag) {
									return "U";
								} else {
									return "";
								}
							}
						});
					}
				});
			}

			//Restructuring DiscountOffSet
			if (aDiscountOffs) {
				oEditModel.setProperty("/EditableDiscountOffSet", aEditableDiscountOffs);
				aDiscountOffs.forEach(function (oDiscountOff, idx) {
					aEditableDiscountOffs.push({
						CustomerNumber: oDiscountOff.CustomerNumber,
						CustomerDesc: oDiscountOff.CustomerDesc,
						PriceGroup: oDiscountOff.PriceGroup,
						PriceGroupDesc: oDiscountOff.PriceGroupDesc,
						MaterialNumber: oDiscountOff.MaterialNumber,
						MaterialDesc: oDiscountOff.MaterialDesc,
						DocumentNumber: oDiscountOff.DocumentNumber,
						ConditionKey: oDiscountOff.ConditionKey,
						Currency: oDiscountOff.Currency,
						OldRate: oDiscountOff.Delta.Rate,
						Rate: oDiscountOff.Rate,
						ValidRate: true,
						//From DeltCh JSON
						oDiscountOffFlag: oDiscountOff.DeltaCh.Rate,
						ChangeFlag: oDiscountOff.ChangeFlag,
						CustomerEditable: false,
						MaterialEditable: false,
						DiscountOffsDeleted: oDiscountOff.ChangeFlag
					});
				});
			}
			if (aOnInvoiceDiscounts) {
				oEditModel.setProperty("/EditableOnInvoiceDiscountSet", aEditableOnInvoiceDiscounts);
				aOnInvoiceDiscounts.forEach(function (OnInvoiceDiscounts, idx) {
					aEditableOnInvoiceDiscounts.push({
						ConditionKey: OnInvoiceDiscounts.ConditionKey,
						CustomerNumber: OnInvoiceDiscounts.CustomerNumber,
						CustomerDesc: OnInvoiceDiscounts.CustomerDesc,
						PriceGroup: OnInvoiceDiscounts.PriceGroup,
						PriceGroupDesc: OnInvoiceDiscounts.PriceGroupDesc,
						MaterialType:OnInvoiceDiscounts.MaterialType,
						MaterialTypeDesc:OnInvoiceDiscounts.MaterialTypeDesc,
						MaterialNumber: OnInvoiceDiscounts.MaterialNumber,
						MaterialDesc: OnInvoiceDiscounts.MaterialDesc,
						DocumentNumber: OnInvoiceDiscounts.DocumentNumber,
						Currency: OnInvoiceDiscounts.Currency,
						OldRate: OnInvoiceDiscounts.Delta.Rate,
						Rate: OnInvoiceDiscounts.Rate,
						//From DeltCh JSON
						OnInvoiceDiscountsFlag: OnInvoiceDiscounts.DeltaCh.Rate,
						ChangeFlag: OnInvoiceDiscounts.ChangeFlag,
						CustomerEditable: false,
						MaterialEditable: false,
						CustomerNumberState:"None",
						PriceGroupState:"None",
						MaterialTypeState:"None",
						RateState:"None",
						ValidRate: true,
						OnInvoiceDiscountsDeleted : OnInvoiceDiscounts.ChangeFlag
					});
				});
			}
			//Asset table data preparation. Here we are following a different approach compared to other tables
			//Reason is to maintain same data property names between view and metadata. It will avoid data mapping 
			//confussion. Same is followed while adding a Asset
			if (oAssetSet) {
				jQuery.extend(true, oEditableAssets, oAssetSet);
				oEditModel.setProperty("/EditableAssets", oEditableAssets.results);
				oEditModel.setProperty("/EditableAssetSelectedKey", (oEditableAssets.results.length > 0) ? oEditableAssets.results[0].ProductHierarchy :
					"");
			}
			oEditModel.checkUpdate(true);
		},

		/** 
		 * This is the change function for Products, Direct Customer Price Exception & Flat Fee Management 
		 * table inputs. In this function we are setting the corresponding change flag based on the change event.
		 * @param {event} oEvent - Change event of Product editable coulmns - Rate, Per, Condtion
		 */
		onPricingTabTableRowDataChange: function (oEvent) {
			var oView = this.getView();
			var oControl = oEvent.getSource();
			var oContext = oControl.getBindingContext("EditModel");
			var oEditModel = oControl.getModel("EditModel");
			oEditModel.setProperty(oContext.sPath + "/" + oControl.data("flag"), true);

			//Products table related
			if (oControl.data("flag") === "GovtBidsFlag" || oControl.data("flag") === "PriceInclFreightFlag" || oControl.data("flag") ===
				"OriginalAgreementFlag") {
				oView.byId("EditProdutsPanel").rerender();
			}
			if (oControl.data("flag") === "RateFlag") {
				var sRateValue = oControl.getValue();
				oEditModel.setProperty(oContext.sPath + "/ValidRate", (!isNaN(sRateValue) && sRateValue.length !== 0));
				oEditModel.checkUpdate(false);
			}
			if (oControl.data("flag") === "ConditionKeyFlag") {
				oEditModel.setProperty(oContext.sPath + "/NewConditionDesc", oControl.getSelectedText());
			}

			//PriceException table related
			if (oControl.data("flag") === "PriceExpConditionKeyFlag" || oControl.data("flag") === "PriceExpPriceInclFreightFlag") {
				oView.byId("EditPriceExcepTable").rerender();
			}
			if (oControl.data("flag") === "PriceExpRateFlag") {
				var sPriceExpRateValue = oControl.getValue();
				oEditModel.setProperty(oContext.sPath + "/ValidRate", (!isNaN(sPriceExpRateValue) && sPriceExpRateValue.length !== 0));
				oEditModel.checkUpdate(false);
			}
			if (oControl.data("flag") === "PriceExpConditionKeyFlag") {
				oEditModel.setProperty(oContext.sPath + "/NewConditionDesc", oControl.getSelectedText());
			}
			//FlatFee Table related 
			if (oControl.data("flag") === "UnitPriceFlag") {
				var sUnitPriceValue = oControl.getValue();
				oEditModel.setProperty(oContext.sPath + "/ValidUnitPrice", (!isNaN(sUnitPriceValue) && sUnitPriceValue.length !== 0));
				oEditModel.checkUpdate(false);
				oView.byId("EditFlatFeeTable").rerender();
			}
		},

		/**
		 * This function is invoked when there is any state change of switch controls in
		 * Products and Price Exception table of pricing tab
		 * @param {event} oEvent event object
		 */
		 onSwitchChange: function(oEvent){
		 	var src = oEvent.getSource();
		 	this._setCustomDataValue(src.getCustomData(), "changed", "yes");
		 	this.onLineChange(oEvent);
		 },
		/**
		 * This function is invoked when there is any input value change in 
		 * Products, Direct Customer Price Exception & Flat Fee Management tables
		 * @param {event} oEvent event object
		 */
		onLineChange: function (oEvent) {
			this.clearInputErrorState(oEvent);
			this.onPricingTabTableRowDataChange(oEvent);
		},

		/**
		 * This is the Product delete icon press function.
		 * In this function we are removing the deleted Product record 
		 * from Products array by changing the ProductChanged & ProductDeleted flags.
		 *  @param {event} oEvent - event of Product deleted press
		 */
		onProductDeletePress: function (oEvent) {
			var oControl = oEvent.getSource();
			var aEditableProducts = oControl.getModel("EditModel").getObject("/EditableProducts");
			var oBindingCtx = oControl.getBindingContext("EditModel");
			var oSelectedProduct = oBindingCtx.getObject();

			//if deleted product is inserted before save removing it from the table
			if (oSelectedProduct.ProductInserted && oSelectedProduct.ChangeFlag !== "I" || oSelectedProduct.ChangeFlag == "E") {
				aEditableProducts.splice(oBindingCtx.sPath.split("/")[2], 1);
			} else {
				oSelectedProduct["ProductDeleted"] = true;
				oSelectedProduct["ProductChangedFlagBeforeDelete"] = oSelectedProduct["ProductChanged"];
				oSelectedProduct["ProductChanged"] = "D";
			}
			oControl.getModel("EditModel").checkUpdate(true);
			this.getView().byId("EditProdutsPanel").rerender();
		},

		/**
		 * This is the Product ,PriceException,FlatFee delete icon press function.
		 * In this function we are removing the deleted record
		 * from Products array by changing the ProductChanged & ProductDeleted flags.
		 *  from PriceException array by changing the PriceExpChanged & PriceExpDeleted flags
		 *  from FlatFee array by changing the FlatFeeChanged & FlatFeeDeleted flags
		 * 	@param {event} oEvent - event of Product ,PriceException,FlatFee deleted press
		 */
		onLineDeletePress: function (oEvent) {
			var that = this;
			var oControl = oEvent.getSource();
			var aEditableLines = oControl.getModel("EditModel").getObject(oControl.data('path'));
			var oBindingCtx = oControl.getBindingContext("EditModel");
			var oSelectedLine = oBindingCtx.getObject();
			var lineInserted = oControl.data("table") === "Products" ? oSelectedLine.ProductInserted :
				oControl.data("table") === "PriceException" ? oSelectedLine.PriceExpInserted :
				oControl.data("table") === "FlatFee" ? oSelectedLine.FlatFeeInserted :
				(oControl.data("table") === "DiscountOff" && oSelectedLine.ChangeFlag === "N")? true :
				(oControl.data("table") === "OnInvoiceDiscounts" && oSelectedLine.ChangeFlag === "N")? true : "";

			//if deleted product is inserted before save removing it from the table
			if (lineInserted && oSelectedLine.ChangeFlag !== "I") {
				aEditableLines.splice(oBindingCtx.sPath.split("/")[2], 1);
			} else {
				switch (oControl.data("table")) {
				case "Products":
					oSelectedLine["ProductDeleted"] = true;
					oSelectedLine["ProductChanged"] = "D";
					break;
				case "PriceException":
					oSelectedLine["PriceExpDeleted"] = true;
					oSelectedLine["PriceExpChanged"] = "D";
					break;
				case "FlatFee":
					oSelectedLine["FlatFeeDeleted"] = true;
					oSelectedLine["FlatFeeChanged"] = "D";
					break;
				case "DiscountOff":				
					//Code to persist ChangeFlag for DiscountOff table and used during undo
					if(oControl.data("table") === "DiscountOff"){
						that.discountOffDeleteOldFlag[oBindingCtx.getPath()] = oSelectedLine.ChangeFlag;
					}
					oSelectedLine.ChangeFlag = "D";
					break;
				case "OnInvoiceDiscounts":				
					//Code to persist ChangeFlag for OnInvoiceDiscounts table and used during undo
					if(oControl.data("table") === "OnInvoiceDiscounts"){
						that.OnInvoiceDiscountsDeleteOldFlag[oBindingCtx.getPath()] = oSelectedLine.ChangeFlag;
					}
					oSelectedLine.ChangeFlag = "D";
					break;
				}
			}
			oControl.getModel("EditModel").checkUpdate(true);
			this.getView().rerender();
		},

		/**
		 * This is the PriceException delete undo icon press function.
		 * In this function we are revertig the deletion process. 
		 * @param {event} oEvent - event of PriceException delete undo icon press 
		 */
		onPriceExcepDeleteUndoPress: function (oEvent) {
			var oControl = oEvent.getSource();
			var oSelectedProduct = oControl.getBindingContext("EditModel").getObject();
			if (oSelectedProduct["ChangeFlag"] === "D") {
				oSelectedProduct["PriceExpUnDeleted"] = true;
				oSelectedProduct["PriceExpDeleted"] = false;
				oSelectedProduct["PriceExpChanged"] = "R";
			} else {
				oSelectedProduct["PriceExpDeleted"] = false;
				oSelectedProduct["PriceExpChanged"] = oSelectedProduct["ChangeFlag"];
			}
			oControl.getModel("EditModel").checkUpdate(true);
			this.getView().byId("EditPriceExpPanel").rerender();
		},

		/**
		 * This is the Product delete undo icon press function.
		 * In this function we are revertig the deletion process. 
		 * @param {event} oEvent - event of Product delete undo icon press
		 */
		onProductDeleteUndoPress: function (oEvent) {
			var oControl = oEvent.getSource();
			var oSelectedProduct = oControl.getBindingContext("EditModel").getObject();
			if (oSelectedProduct["ChangeFlag"] === "D") {
				oSelectedProduct["ProductUnDeleted"] = true;
				oSelectedProduct["ProductDeleted"] = false;
				oSelectedProduct["ProductChanged"] = "R";
			} else {
				oSelectedProduct["ProductDeleted"] = false;
				oSelectedProduct["ProductChanged"] = oSelectedProduct["ChangeFlag"];
			}
			oControl.getModel("EditModel").checkUpdate(true);
			this.getView().byId("EditProdutsPanel").rerender();
		},
		
		/**
		 * Function to handle DiscountOff table row Undo press
		 * @private
		 * @param {sap.ui.base.Event} oEvent object
		 */
		onDiscountsOffUndoPress: function (oEvent) {
			var that = this;
			var oControl = oEvent.getSource();
			var oBindingCtx = oControl.getBindingContext("EditModel");
			var oDiscountsOff = oBindingCtx.getObject();
			if (oDiscountsOff.DiscountOffsDeleted === "D") {
				oDiscountsOff.ChangeFlag = "R";
			}else{
				oDiscountsOff.ChangeFlag = that.discountOffDeleteOldFlag[oBindingCtx.getPath()];
			}
			oControl.getModel("EditModel").checkUpdate(true);
		},
		
		/**
		 * Function to handle OnInvoiceDiscounts table row Undo press
		 * @private
		 * @param {sap.ui.base.Event} oEvent object
		 */
		onOnInvoiceDiscountsUndoPress: function (oEvent) {
			var that = this;
			var oControl = oEvent.getSource();
			var oBindingCtx = oControl.getBindingContext("EditModel");
			var OnInvoiceDiscounts = oBindingCtx.getObject();
			if (OnInvoiceDiscounts.OnInvoiceDiscountsDeleted === "D") {
				OnInvoiceDiscounts.ChangeFlag = "R";
			}else{
				OnInvoiceDiscounts.ChangeFlag = that.OnInvoiceDiscountsDeleteOldFlag[oBindingCtx.getPath()];
			}
			oControl.getModel("EditModel").checkUpdate(true);
			this.getView().byId("OnInvoiceDiscountsPanel").rerender();
		},
		
		/**
		 * @param {event} oEvent - event of Product table add button press
		 * In this function we are adding empty record to product table with default values
		 */
		onAddProductPress: function (oEvent) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var aProductsData = oEditModel.getProperty("/EditableProducts");
			var EditProductsTable = oView.byId("EditProductsTable");
			if(EditProductsTable.getSortedColumns() && EditProductsTable.getSortedColumns().length > 0){
				for(var i=0; i<EditProductsTable.getSortedColumns().length; i++){
					EditProductsTable.getSortedColumns()[i].setSorted(null);
				}
				EditProductsTable.getBinding("rows").sort(null);
			}
			aProductsData.unshift({
				MaterialNumber: "",
				MaterialDesc: "",
				DocumentNumber: "",
				NewRate: "",
				NewPer: "",
				Currency: "",
				NewConditionType: "",
				NewConditionKey: "",
				NewGovtBids: false,
				NewPriceInclFreight: true,
				NewOriginalAgreement: false,
				ChangeFlag: "",
				OldRate: "",
				OldPer: "",
				OldConditionType: "",
				OldConditionKey: "",
				OldConditionKeyDesc: "",
				OldGovtBids: false,
				OldPriceInclFreight: false,
				OldOriginalAgreement: false,
				RateFlag: false,
				PerFlag: false,
				ConditionTypeFlag: false,
				GovtBidsFlag: true,
				PriceInclFreightFlag: true,
				OriginalAgreementFlag: true,
				ChangeIcon: "I",
				MaterialEditable: true,
				ValidRate: true,
				MaterialNumberStatus : "None",
				NewPerStatus : "None",
				ProductDeleted: false,
				ProductInserted: true,
				Unit: "",
				HasPPViolation: false,
				ProductChanged: "N",
				IsChPending: false
			});
			oEditModel.checkUpdate(true);
			EditProductsTable.setFirstVisibleRow(0);
			/*if(EditProductsTable.getSortedColumns() && EditProductsTable.getSortedColumns().length === 0){
				EditProductsTable.setFirstVisibleRow(0);
			} else {
				EditProductsTable.setFirstVisibleRow(aProductsData.length - 1);
			}*/
			EditProductsTable.rerender();
		},

		/**
		 * @param {event} oEvent - event of Product table Materail Colulmn change 
		 * This function is to get entered materail details
		 */
		onMaterialNumberChange: function (oEvent) {
			this.clearInputErrorState(oEvent);
			var oControl = oEvent.getSource();
			var sEnteredMatNum = oControl.getValue();
			
			if(sEnteredMatNum && sEnteredMatNum.trim() !== ""){
				var oEditProductsPanel = this.getView().byId("EditProdutsPanel");
				oEditProductsPanel.setBusy(true);
				this.MNInput = oControl.data("flag");
				var oContext = oControl.getBindingContext("EditModel");
				if (!this.EditProducts) {
					this.EditProducts = {};
				}
				this.EditProducts.SelectedMaterialFldIdx = oContext.sPath.split("/")[2];
				var oModel = oControl.getModel();
				var oEditModel = oControl.getModel("EditModel");
				var aFilter = [];
				aFilter.push(new Filter("MaterialNumber", "Contains", sEnteredMatNum.trim()));
				var sEntryType = "manualEntry";
				this._callMaterialValueHelpSet(oModel, oEditModel, aFilter, sEntryType, oEvent);
				oEditProductsPanel.setBusy(false);
				this.populateConditionInput(oEvent);

				//end
			}else{
				oEditModel.setProperty(oControl.getBindingContext("EditModel").getPath()+"/NewConditionKey","AA");
				oEditModel.updateBindings(true);
			}
		},

		/**
		 * @param {event} oEvent - General event object
		 * This function populates the conditions inut for product and price exception table.
		 */
		populateConditionInput : function (oEvent) {
			var oControl = oEvent.getSource();
			var oEditModel = oControl.getModel("EditModel");
			var oModel = oControl.getModel();
			var sourceTable = oControl.data("flag");
			
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "YYYY-MM-ddT00%3A00%3A00"
				});
			var tFromTime = oDateFormat.format(new Date(this.getOwnerComponent().getModel().getProperty("/HeaderSet('" + oEditModel.getData().sObjectId + "')/ValueFields/ValidFrom")));
			
			
			var sPath = "";
			var materialNumber = oEditModel.getProperty(oControl.getBindingContext("EditModel").getPath() + "/MaterialNumber").trim();
			if(sourceTable === "ProductsMN" && materialNumber !== ""){
				sPath = "/ProductSet(DocumentNumber='"
				+ oEditModel.getData().sObjectId +
				"',MaterialNumber='" 
				+ "000000000000000000".substring(0,(18 - materialNumber.length))
				+ materialNumber +
				"',ValidFrom=datetime'" 
				+ tFromTime + "')";
			}else if(oEditModel.getProperty(oControl.getBindingContext("EditModel").getPath() + "/CustomerNumber").trim() !== "" && materialNumber !== ""){
				sPath = "/PriceExceptionSet(CustomerNumber='" + 
				oEditModel.getProperty(oControl.getBindingContext("EditModel").getPath() + "/CustomerNumber")
				+ "',DocumentNumber='"
				+ oEditModel.getData().sObjectId 
				+ "',MaterialNumber='"
				+ "000000000000000000".substring(0,(18 - materialNumber.length)) 
				+ materialNumber
				+ "',ValidFrom=datetime'"
				+ tFromTime + "')";
			}
			
			if(sPath !== ""){
				oModel.setHeaders({
					"get_delta": "X"
				});
				oModel.read(sPath, {
					success: function (oData, oResponse) {
						oEditModel.setProperty(oControl.getBindingContext("EditModel").getPath() + "/NewConditionKey",oData.ConditionKey);
						oEditModel.setProperty(oControl.getBindingContext("EditModel").getPath() + "/OldConditionKeyDesc",oData.Delta.ConditionKeyDesc);
						oEditModel.updateBindings(true);
						oModel.setHeaders({});
					},
					error: function (oError) {
						oEditModel.setProperty(oControl.getBindingContext("EditModel").getPath() + "/NewConditionKey","");
						oEditModel.setProperty(oControl.getBindingContext("EditModel").getPath() + "/OldConditionKeyDesc","");
						oEditModel.updateBindings(true);
						oModel.setHeaders({});
					}
				});
			}
		},
		
		/**
		 * @param {event} oEvent - event of Product table Materail Colulmn ValueHelp press
		 * This function is to display Material serach & select popup
		 */
		onEditProductsMaterialVHPress: function (oEvent) {
			var oSource = oEvent.getSource();
			this.MNInput = oSource.data("flag");
			this.EditProducts = {};
			this.EditProducts.SelectedMaterialFldId = oEvent.getSource().getId();
			this.EditProducts.SelectedMaterialFldIdx = oEvent.getSource().getBindingContext("EditModel").sPath.split("/")[2];

			// create value help dialog
			if (!this._materialValueHelpDialog) {
				this._materialValueHelpDialog = sap.ui.xmlfragment(
					"com.ecolab.ZASBMasterAgr.fragment.edit.MaterialValueHelp",
					this
				);
				this.getView().addDependent(this._materialValueHelpDialog);
			}
			this._materialValueHelpDialog.open();
		},

		/**
		 * @param {event} evt - Material VH search button press
		 * In this function, we are calling /MaterialValueHelpSet based on the search cretieria.
		 */
		onMaterailNumSerachPress: function (evt) {
			var sObject=evt.getSource().getBindingContext().getObject().ValueFields;

			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var MaterialSearchData = oEditModel.getData().MaterialSearch;
			oEditModel.setProperty("/MaterialSearch/tableBusy", true);

			var aFilter = [];
			if (MaterialSearchData.MaterialNum.trim().length !== 0) {
				aFilter.push(new Filter("MaterialNumber", "Contains", MaterialSearchData.MaterialNum));
				aFilter.push(new Filter("SalesOrg", "EQ", sObject.SalesOrg));
			}
			if (MaterialSearchData.MaterialDesc.trim().length !== 0) {
				aFilter.push(new Filter("MaterialDescription", "Contains", MaterialSearchData.MaterialDesc));
				aFilter.push(new Filter("SalesOrg", "EQ", sObject.SalesOrg));
			}
			if (MaterialSearchData.SelectedStatuses.length !== 0) {
				for (var iStatus = 0; iStatus < MaterialSearchData.SelectedStatuses.length; iStatus++) {
					aFilter.push(new Filter("Status", "EQ", MaterialSearchData.SelectedStatuses[iStatus]));
					aFilter.push(new Filter("SalesOrg", "EQ", sObject.SalesOrg));
				}
			}
			var oModel = oView.getModel();
			oModel.setHeaders({});
			var sEntryType = "byRowSelection";
			this._callMaterialValueHelpSet(oModel, oEditModel, aFilter, sEntryType);

		},

		/**
		 * @param {object} oModel - oData Model to make read call
		 * @param {object} oEditModel - EditModel object
		 * @param {array} aFilter - Filters array Materail Number/Materail Description/Status
		 * In this function, we are reading /MaterialValueHelpSet based on the search cretieria.
		 */
		_callMaterialValueHelpSet: function (oModel, oEditModel, aFilter, sEntryType, oEvent) {
			var me = this;
			oModel.read("/MaterialValueHelpSet", {
				filters: aFilter,
				success: function (oData) {
					if (sEntryType === "byRowSelection") {
						oEditModel.setProperty("/MaterialSearch/MaterialValueHelpSet", oData.results);
						oEditModel.checkUpdate(true);
						oEditModel.setProperty("/MaterialSearch/tableBusy", false);
						sap.ui.getCore().byId("EditMaterialsTable").removeSelections();
					} else {
						if (oData.results.length > 0) {
							oEditModel.setProperty("/MaterialSearch/SelectedMaterial", oData.results[0].MaterialNumber);
							oEditModel.setProperty("/MaterialSearch/SelectedMaterialDesc", oData.results[0].MaterialDescription);
							me.onEditMaterialSearchOkPress(oEvent);
						}
					}
				},
				error: function (oError) {
					oEditModel.setProperty("/MaterialSearch/tableBusy", false);
				}
			});
		},

		/**
		 * @param {event} oEvent - Material VH ok button press
		 * In this function, we are adding selected product to Edit Products table.
		 * If duplicate Product selected, then displaying message.
		 */
		onEditMaterialSearchOkPress: function (oEvent) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var sSelectedMaterial = oEditModel.getProperty("/MaterialSearch/SelectedMaterial");
			var oEditProductTable = oView.byId("EditProductsTable");
			var oEditPriceExpTable = oView.byId("EditPriceExcepTable");
			var oEditFlatFeeTable = oView.byId("EditFlatFeeTable");
			var oDiscountOffTable = oView.byId("DiscountOffTable");
			var aEditableProducts = oEditModel.getObject("/EditableProducts");
			var aEditablePriceExceptions = oEditModel.getObject("/EditablePriceExceptions");
			var aEditableFlatFee = oEditModel.getObject("/EditableFlatFee");
			var aEditableDiscountOffSet = oEditModel.getObject("/EditableDiscountOffSet");
			var iSelectedMatFldIdx = this.EditProducts.SelectedMaterialFldIdx;

			if (this._materialValueHelpDialog) {
				this._materialValueHelpDialog.close();
			}
			if (this.MNInput === "ProductsMN") {
				if (this._getIsDuplicateProduct(sSelectedMaterial, aEditableProducts)) {
					this._deleteRecordOnDuplicateEntry(oEditProductTable, aEditableProducts, iSelectedMatFldIdx);
				} else {
					this._displayMaterialNumber(oEditModel, aEditableProducts, oEditProductTable, "/EditableProducts/" + iSelectedMatFldIdx,
						iSelectedMatFldIdx, sSelectedMaterial);
				}
			}
			if (this.MNInput === "PriceExpMN") {
				if (this._getIsDuplicatePriceExp("Material", sSelectedMaterial, aEditablePriceExceptions)) {
					this._deleteRecordOnDuplicateEntry(oEditPriceExpTable, aEditablePriceExceptions, iSelectedMatFldIdx);
				} else {
					this._displayMaterialNumber(oEditModel, aEditablePriceExceptions, oEditPriceExpTable, "/EditablePriceExceptions/" +
						iSelectedMatFldIdx, iSelectedMatFldIdx, sSelectedMaterial);
				}
			}
			if (this.MNInput === "FlatFeeMN") {
				if (this._getIsDuplicateFlatFee("Material", sSelectedMaterial, aEditableFlatFee)) {
					this._deleteRecordOnDuplicateInFlatFeeEntry(oEditFlatFeeTable, aEditableFlatFee, iSelectedMatFldIdx);
				} else {
					this._displayMaterialNumber(oEditModel, aEditableFlatFee, oEditFlatFeeTable, "/EditableFlatFee/" + iSelectedMatFldIdx,
						iSelectedMatFldIdx, sSelectedMaterial);
				}
			}
			if (this.MNInput === "DiscountsOffMN") {
				if (this._getIsDuplicateDiscountOff("Material", sSelectedMaterial, aEditableDiscountOffSet)) {
					this._deleteRecordOnDuplicateEntry(oDiscountOffTable, aEditableDiscountOffSet, iSelectedMatFldIdx);
				} else {
					this._displayMaterialNumber(oEditModel, aEditableDiscountOffSet, oDiscountOffTable, "/EditableDiscountOffSet/" + iSelectedMatFldIdx,
						iSelectedMatFldIdx, sSelectedMaterial);
				}
			}
			oEditModel.setProperty("/MaterialSearch/MaterialValueHelpSet", []);
			var oEditMaterialsTable = sap.ui.getCore().byId("EditMaterialsTable");
			if (oEditMaterialsTable) {
				sap.ui.getCore().byId("EditMaterialsTable").removeSelections();
			}
			oEditModel.checkUpdate(true);
		},

		/**
		 * @param {object} oEditModel - Edit Model object
		 * @param {array} aEditableRecords - Editable table collection
		 * @param {object} oEditableTable - Editable table control
		 * @param {string} sPath - path of the Table items binding collection
		 * @param {integer} iSelectedMatFldIdx - Selected record index of the table
		 * @param {string} sSelectedMaterial - Selected Materail Number from the value help dialog
		 * In this function, we displaying manually entered material Numner with description
		 */
		_displayMaterialNumber: function (oEditModel, aEditableRecords, oEditableTable, sPath, iSelectedMatFldIdx, sSelectedMaterial) {
			var sTableflag = oEditableTable.data("table");
			var iFocusedRow;
			oEditModel.setProperty(sPath + "/MaterialNumber",
				sSelectedMaterial);
			oEditModel.setProperty(sPath + "/MaterialDesc", oEditModel.getProperty("/MaterialSearch/SelectedMaterialDesc"));
			oEditModel.setProperty(sPath + "/MaterialEditable", false);
			if (aEditableRecords.length <= oEditableTable.getVisibleRowCount()) {
				iFocusedRow = iSelectedMatFldIdx;
			} else {
				if(sTableflag === "Products"){
					iFocusedRow = iSelectedMatFldIdx;
				} else {
					iFocusedRow = oEditableTable.getVisibleRowCount() - 1;
				}
			}
			if (this.MNInput === "FlatFeeMN") {
				var oRateFld = oEditableTable.getRows()[iFocusedRow].getCells()[5];
				jQuery.sap.delayedCall(500, oRateFld, oRateFld.focus);
			} else {
				var aRateFld = oEditableTable.getRows()[iFocusedRow].getCells()[3];
				jQuery.sap.delayedCall(500, aRateFld, aRateFld.focus);
			}

		},

		/**
		 * In this method we will focus on the row which is already existing in table
		 * @ param {object} oEditableTable - Editable table control 
		 * @param {array} aEditableRecords - Editable table collection
		 * @private
		 */
		_getFocusedRow: function (oEditTable, aEditableRecords) {
			var sTableflag = oEditTable.data("table");
			var iVisibleRowCount = oEditTable.getVisibleRowCount();
			var iTableLength = aEditableRecords.length; //removing 1 for newly added
			var iFocusedRow;
			if (iTableLength < iVisibleRowCount) {
				if(sTableflag === "Products"){
					iFocusedRow = this.EditProducts.duplicateMaterialIdx - 1;
				}
			} else if (iTableLength - this.EditProducts.duplicateMaterialIdx < iVisibleRowCount) {
				iFocusedRow = iVisibleRowCount - (iTableLength - this.EditProducts.duplicateMaterialIdx);
				// iFocusedRow = this.EditProducts.duplicateMaterialIdx -  iVisibleRowCount;
			} else {
				iFocusedRow = 0;
			}
			return iFocusedRow;
		},

		/**
		 * In this Method we Delete the New row and Focus on the already existing row
		 * @ oEditTable- oEditTable is the Products,PriceException Tables  
		 * @ aEditableRecords-aEditableRecords is the Products,PriceException,DiscountOff,OnInvoiceDiscounts data
		 * @ iSelectedFldIdx-iSelectedFldIdx is the InputField path 
		 * @ private
		 */
		_deleteRecordOnDuplicateEntry: function (oEditTable, aEditableRecords, iSelectedFldIdx) {
			var sTableflag = oEditTable.data("table");
			if(sTableflag === "Products"){
				oEditTable.setFirstVisibleRow(this.EditProducts.duplicateMaterialIdx - 1);
			} else {
				oEditTable.setFirstVisibleRow(this.EditProducts.duplicateMaterialIdx);
			}
			var sErrorMsg;
			if (sTableflag === "PriceException") {
				sErrorMsg = this.bundle.getText("DuplicatePRiceExpMsg");
			} else if (sTableflag === "Products") {
				sErrorMsg = this.bundle.getText("DuplicateProductFoundMessage");
			} else if (sTableflag === "DiscountOff") {
				sErrorMsg = this.bundle.getText("DuplicateDiscountOffFoundMessage");
			}else if (sTableflag === "OnInvoiceDiscounts") {
				sErrorMsg = this.bundle.getText("DuplicateOnInvoiceDiscountFoundMessage");
			}
			MessageToast.show(sErrorMsg, {
				duration: 3000
			});
			
			var iFocusedRow = this._getFocusedRow(oEditTable, aEditableRecords);
			var tableRowCells = oEditTable.getRows()[iFocusedRow].getCells();
			if(sTableflag === "OnInvoiceDiscounts"){
				for(var i= 0; i< tableRowCells.length; i++){
				if(tableRowCells[i].getEnabled && tableRowCells[i].getEnabled() === true && tableRowCells[i].getCustomData()[0].getValue() === "RateFlag"){
					jQuery.sap.delayedCall(500, tableRowCells[i], tableRowCells[i].focus);
					break;
				}
			}
			}else {
			for(var idx = 0; idx < tableRowCells.length; idx++){
				if(tableRowCells[idx].getEnabled && tableRowCells[idx].getEnabled() === true){
					jQuery.sap.delayedCall(500, tableRowCells[idx], tableRowCells[idx].focus);
					break;
				}
			}
			}
			//removing added row as selected duplicate material
			aEditableRecords.splice(iSelectedFldIdx, 1);
		},

		/**
		 * @param {string} selectedMaterial - Selected material #
		 * @param {array} aEditableRecords - Edit table records
		 * In this function, we are checking the selected material existed in the table or not.
		 */
		_getIsDuplicateProduct: function (selectedMaterial, aEditableRecords) {
			var me = this;
			return aEditableRecords.some(function (oProduct, idx, aProducts) {
				if (idx === 0) {
					return false;
				}
				me.EditProducts.duplicateMaterialIdx = idx;
				return oProduct.MaterialNumber === selectedMaterial;
			});
		},

		/**
		 * @param {string} sSelectedValue - Selected material #
		 * @param {array} aEditTableRecords - Edit table records
		 * In this function, we are checking the selected material existed in the table or not.
		 */
		_getIsDuplicatePriceExp: function (sSelectedFld, sSelectedValue, aEditTableRecords) {
			var me = this;
			if (!this.EditProducts) {
				this.EditProducts = {};
			}
			var aCustomerAndMaterials = aEditTableRecords.map(function (oItem, iIdx) {
				if (aEditTableRecords.length - 1 === iIdx) {
					return sSelectedFld === "Material" ? formatter.trimLeadingZerosSubstr(oItem.CustomerNumber.trim()) + sSelectedValue : sSelectedValue + oItem.MaterialNumber.trim();
				}
				return formatter.trimLeadingZerosSubstr(oItem.CustomerNumber.trim()) + oItem.MaterialNumber;
			});
			return aCustomerAndMaterials.some(function (item, iItemIdx) {
				me.EditProducts.duplicateMaterialIdx = aCustomerAndMaterials.indexOf(item);
				return aCustomerAndMaterials.indexOf(item) !== iItemIdx;
			});
		},

		/**
		 * @param {string} sSelectedValue - Selected material #
		 * @param {array} aEditTableRecords - Edit table records
		 * In this function, we are checking the selected ConditionType,Customer,ProgramType,material existed in the table or not.
		 */
		_getIsDuplicateFlatFee: function (sSelectedFld, sSelectedValue, aEditTableRecords) {
			var me = this;
			if (!this.EditProducts) {
				this.EditProducts = {};
			}
			var aCustomerAndMaterials = aEditTableRecords.map(function (oItem, iIdx) {
				if (aEditTableRecords.length - 1 === iIdx) {
					return sSelectedFld === "Material" ? formatter.trimLeadingZerosSubstr(oItem.CustomerNumber.trim()) + sSelectedValue + oItem.ProgramType + oItem.ConditionKey :
						sSelectedValue + oItem.MaterialNumber.trim() + oItem.ProgramType + oItem.ConditionKey;
				}
				return formatter.trimLeadingZerosSubstr(oItem.CustomerNumber.trim()) + oItem.MaterialNumber + oItem.ProgramType + oItem.ConditionKey;
			});
			return aCustomerAndMaterials.some(function (item, iItemIdx) {
				me.EditProducts.duplicateMaterialIdx = aCustomerAndMaterials.indexOf(item);
				return aCustomerAndMaterials.indexOf(item) !== iItemIdx;
			});
		},
		
		/**
		 * Function to check for record in DiscountOff table and delete that record if duplicate exists
		 * @private
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		checkDuplicateDiscountOff: function (oEvent) {
			var that = this;
			that.clearInputErrorState(oEvent);
			var src = oEvent.getSource();
			var oView = that.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableDiscountOffSet = oEditModel.getProperty("/EditableDiscountOffSet");
			var oEditDiscountOffTable = this.getView().byId("DiscountOffTable");
			if(that._getIsDuplicateDiscountOff("PriceGroup", src.getSelectedKey(), aEditableDiscountOffSet)) {
				that._deleteRecordOnDuplicateEntry(oEditDiscountOffTable, aEditableDiscountOffSet, that.EditProducts.currentDuplicateMaterialIdx);
				oEditModel.checkUpdate(true);
			}
		},
		
		checkDuplicateOnInvoiceDiscountsPriceGroup: function (oEvent) {
			var that = this;
			that.clearInputErrorState(oEvent);
			var src = oEvent.getSource();
			var oView = that.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableOnInvoiceDiscountSet = oEditModel.getProperty("/EditableOnInvoiceDiscountSet");
			var oEditOnInvoiceDiscountTable = this.getView().byId("IdOnInvoiceDiscountTable");
			if(that._getIsDuplicateOnInvoiceDiscounts("PriceGroup", src.getSelectedKey(), aEditableOnInvoiceDiscountSet)) {
				that._deleteRecordOnDuplicateEntry(oEditOnInvoiceDiscountTable, aEditableOnInvoiceDiscountSet, that.EditProducts.currentDuplicateMaterialIdx);
				oEditModel.checkUpdate(true);
			}
		},
		
		checkDuplicateOnInvoiceDiscountsMaterialType: function (oEvent) {
			var that = this;
			that.clearInputErrorState(oEvent);
			var src = oEvent.getSource();
			var oView = that.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableOnInvoiceDiscountSet = oEditModel.getProperty("/EditableOnInvoiceDiscountSet");
			var oEditOnInvoiceDiscountTable = this.getView().byId("IdOnInvoiceDiscountTable");
			if(that._getIsDuplicateOnInvoiceDiscounts("MaterialType", src.getSelectedKey(), aEditableOnInvoiceDiscountSet)) {
				that._deleteRecordOnDuplicateEntry(oEditOnInvoiceDiscountTable, aEditableOnInvoiceDiscountSet, that.EditProducts.currentDuplicateMaterialIdx);
				oEditModel.checkUpdate(true);
			}
		},
		
		/**
		 * Funtion that retruns boolean falg true of any duplicate exists in DiscountOff table
		 * @private
		 * @param {String} sSelectedFld String that contains column of the row that is changed
		 * @param {String} sSelectedValue String that contains changed column value
		 * @param {Arrat} aEditTableRecords array of rows
		 * @return true is return if any duplicate exists
		 */
		_getIsDuplicateDiscountOff: function (sSelectedFld, sSelectedValue, aEditTableRecords) {
			var that = this;
			this.EditProducts = {};
			
			var aCustomerAndMaterials = aEditTableRecords.map(function (oItem, iIdx) {
				if (aEditTableRecords.length - 1 === iIdx) {
					if(sSelectedFld === "Material"){
						return oItem.CustomerNumber.trim() + sSelectedValue + oItem.PriceGroup + oItem.ConditionKey;
					}else if(sSelectedFld === "PriceGroup"){
						return oItem.CustomerNumber.trim() + oItem.MaterialNumber + sSelectedValue + oItem.ConditionKey;
					}
					return sSelectedValue + oItem.MaterialNumber.trim() + oItem.PriceGroup + oItem.ConditionKey;
				}
				return oItem.CustomerNumber.trim() + oItem.MaterialNumber + oItem.PriceGroup + oItem.ConditionKey;
			});
			return aCustomerAndMaterials.some(function (item, iItemIdx) {
				that.EditProducts.duplicateMaterialIdx = aCustomerAndMaterials.indexOf(item);
				that.EditProducts.currentDuplicateMaterialIdx = iItemIdx;
				return aCustomerAndMaterials.indexOf(item) !== iItemIdx;
			});
		},
		
		/**
		 * Funtion that retruns boolean falg true of any duplicate exists in OnInvoice Discounts table
		 * @private
		 * @param {String} sSelectedFld String that contains column of the row that is changed
		 * @param {String} sSelectedValue String that contains changed column value
		 * @param {Arrat} aEditTableRecords array of rows
		 * @return true is return if any duplicate exists
		 */
		_getIsDuplicateOnInvoiceDiscounts: function (sSelectedFld, sSelectedValue, aEditTableRecords) {
			var that = this;
			this.EditProducts = {};
			var aCustomerAndMaterials = aEditTableRecords.map(function (oItem, iIdx) {
				if (aEditTableRecords.length - 1 === iIdx) {
					if(sSelectedFld === "PriceGroup"){
						return oItem.CustomerNumber.trim() + sSelectedValue + oItem.MaterialType + oItem.ConditionKey;
					}
					else if(sSelectedFld === "MaterialType"){
						return oItem.CustomerNumber.trim() + oItem.PriceGroup + sSelectedValue +oItem.ConditionKey;
					}
					return sSelectedValue + oItem.MaterialType.trim() + oItem.PriceGroup + oItem.ConditionKey;
				}
				return oItem.CustomerNumber.trim() + oItem.MaterialType + oItem.PriceGroup + oItem.ConditionKey;
			});
			return aCustomerAndMaterials.some(function (item, iItemIdx) {
				that.EditProducts.duplicateMaterialIdx = aCustomerAndMaterials.indexOf(item);
				that.EditProducts.currentDuplicateMaterialIdx = iItemIdx;
				return aCustomerAndMaterials.indexOf(item) !== iItemIdx;
			});
		},
		
		/**
		 * In this Method we Delete the New row and Focus on the already existing row
		 * @ oEditFlatFeeTable- oEditFlatFeeTable is the FlatFeeTable 
		 * @ aEditableFlatFee-aEditableFlatFee is the FlatFee data
		 * @ iSelectedFldIdx-iSelectedFldIdx is the InputField path 
		 * @ private
		 */
		_deleteRecordOnDuplicateInFlatFeeEntry: function (oEditFlatFeeTable, aEditableFlatFee, iSelectedFldIdx) {
			oEditFlatFeeTable.setFirstVisibleRow(this.EditProducts.duplicateMaterialIdx);
			MessageToast.show(this.bundle.getText("DuplicateFlatFeeMsg"), {
				duration: 3000
			});
			//removing added row as selected duplicate material
			aEditableFlatFee.splice(iSelectedFldIdx, 1);
			
			var iFocusedRow = this._getFocusedRow(oEditFlatFeeTable, aEditableFlatFee);
			var tableRowCells = oEditFlatFeeTable.getRows()[iFocusedRow].getCells();
						
			for(var idx = 0; idx < tableRowCells.length; idx++){
				if(tableRowCells[idx].getEnabled && tableRowCells[idx].getEnabled() === true){
					jQuery.sap.delayedCall(500, tableRowCells[idx], tableRowCells[idx].focus);
					break;
				}
			}			
		},

		/**
		 * @param {sap.ui.base.Event} oEvent - Material VH popup cancel button press
		 * In this function, we are closing the Material VH Popup.
		 */
		onEditMaterialSearchCancelPress: function (oEvent) {
			var oEditModel = this.getView().getModel("EditModel");
			oEditModel.setProperty("/MaterialSearch/SelectedMaterial", "");
			this._materialValueHelpDialog.close();
		},

		/**
		 * @param {sap.ui.base.Event} oEvent - Material VH popup result table select event
		 * In this function, we are setting selected Material in EditModel.
		 */
		onMaterialListTableSelect: function (oEvent) {
			var oEditModel = this.getView().getModel("EditModel");
			var aSelectedCtxs = oEvent.getSource().getSelectedContexts();
			var sMaterailNum = aSelectedCtxs[0].getProperty("MaterialNumber");
			var sMaterailDesc = aSelectedCtxs[0].getProperty("MaterialDescription");
			oEditModel.setProperty("/MaterialSearch/SelectedMaterial", sMaterailNum);
			oEditModel.setProperty("/MaterialSearch/SelectedMaterialDesc", sMaterailDesc);
		},

		/**
		 * @param {sap.ui.base.Event} oEvent - event of Price Exp table add button press
		 * In this function we are adding empty record to Price Exception table with default values
		 */
		onAddPriceExpPress: function (oEvent) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var aPriceExceptions = oEditModel.getProperty("/EditablePriceExceptions");
			aPriceExceptions.push({
				CustomerNumber: "",
				CustomerDesc: "",
				MaterialNumber: "",
				MaterialDesc: "",
				DocumentNumber: "",
				NewRate: "",
				NewPer: "",
				Currency: "",
				NewConditionType: "",
				NewPriceInclFreight: true,
				ChangeFlag: "",
				OldRate: "",
				OldPer: "",
				OldConditionType: "",
				OldConditionDesc: "",
				OldPriceInclFreight: false,
				RateFlag: false,
				PerFlag: false,
				ConditionTypeFlag: false,
				PriceExpPriceInclFreightFlag: true,
				ChangeIcon: "I",
				MaterialEditable: true,
				CustomerEditable: true,
				ValidRate: true,
				PriceExpDeleted: false,
				PriceExpInserted: true,
				Unit: "",
				HasPPViolation: false,
				PriceExpChanged: "I",
				CustomerNumberState : "None",
				MaterialNumberState : "None",
				NewPerStatus : "None",
				IsChPending: false
			});
			oEditModel.checkUpdate(true);
			var EditPriceExcepTable = oView.byId("EditPriceExcepTable");
			EditPriceExcepTable.setFirstVisibleRow(aPriceExceptions.length - 1);
			EditPriceExcepTable.rerender();
		},

		/**
		 * Function launched Asset and Price group selection dialogue. this is used
		 * for asset addition
		 * @param {sap.ui.base.Event} oEvent - event of Asset management add button press
		 */
		handleAssetSearchDlg: function (oEvent) {
			if (!this._oAssetSelectDialog) {
				this._oAssetSelectDialog = new sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.edit.AssetSelectionDlg", this);
				this._oAssetSelectDialog.setModel(this.getView().getModel());
				this._oAssetSelectDialog.setModel(this.getView().getModel("EditModel"), "EditModel");
				this._oAssetSelectDialog.setModel(this.getView().getModel("i18n"), "i18n");
				this.getView().addDependent(this._oAssetSelectDialog);
			}
			var oBinding = sap.ui.getCore().byId("AddAssetDlgPH4List").getBinding("items");
			oBinding.filter(new Filter("SearchField", sap.ui.model.FilterOperator.Contains, ""));
			sap.ui.getCore().byId("AddAssetDlgPH4SearchField").setValue("");
			this.onAddAssetDlgBack();
			this._oAssetSelectDialog.open();
		},
		
		/**
		 * Asset and Price group selection dialogue function to do Price Group search on give string
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		handlePriceGroupSearch: function (oEvent) {
			var sValue = oEvent.getSource().getValue();
			var items = sap.ui.getCore().byId("AddAssetDlgPriceGroupList").getItems();
			for(var idx=0; idx < items.length; idx++){
				if(sValue && sValue.trim().length === 0)
				{
					items[idx].setVisible(true);
				}else if(items[idx].getTitle().indexOf(sValue) !== -1 || items[idx].getDescription().indexOf(sValue) !== -1){
					items[idx].setVisible(true);
				}else{
					items[idx].setVisible(false);
				}
			}
		},
		
		/**
		 * Asset and Price group selection dialogue function to do Asset search on give string
		 * @param {sap.ui.base.Event} oEvent - event of Asset management add button press
		 */
		handleAssetSearch: function (oEvent) {
			var sValue = oEvent.getSource().getValue();
			var oFilter = new Filter("SearchField", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = sap.ui.getCore().byId("AddAssetDlgPH4List").getBinding("items");
			oBinding.filter([oFilter]);
		},

		/**
		 * Asset and Price group selection dialogue close function
		 * @param {sap.ui.base.Event} oEvent - event of Asset management add button press
		 */
		handleAssetSearchClose: function (oEvent) {
			this._oAssetSelectDialog.close();
		},

		/**
		 * Pricing Tab Asset Addition dialog back navigation 
		 * @private
		 */
		onAddAssetDlgBack: function () {
			sap.ui.getCore().byId("AddAssetDlgNavContainer").back();
		},

		/**
		 * Pricing Tab Asset Addition dialog  Asset selection in 
		 * First page. In this function we are persisting selected Product Hierarchy and its descrition
		 * these values are used in onAddAssetPress function. At the end asset selection dialog page 
		 * is changed to Price group selection page
		 * @param {object} oEvent
		 * @private
		 */
		onAssetSelectPress: function (oEvent) {
			var me = this;
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			oEditModel.setProperty("/AssetProductHierarchyForAdd", oEvent.getSource().getTitle());
			oEditModel.setProperty("/AssetProductHierarchyDescForAdd", oEvent.getSource().getDescription());
			sap.ui.getCore().byId("AddAssetDlgNavContainer").to("AddAssetDlgPriceGroupSelectionPage");
		},

		/**
		 * Function to add DiscountOff new row in DiscountOff table
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		 onAddDiscountOffPress: function(oEvent){
			var that = this;
			var oView = that.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableDiscountOffSet = oEditModel.getProperty("/EditableDiscountOffSet");

			if (!aEditableDiscountOffSet) {
				aEditableDiscountOffSet = [];
			}

			aEditableDiscountOffSet.push({
				"Delta": {
					"DocumentNumber": "",
					"ConditionNumber": "",
					"DestZone": "",
					"ConditionTable": "",
					"Region": "",
					"ConditionType": "",
					"Plant": "",
					"DestZoneDesc": "",
					"MaterialType": "",
					"Currency": "",
					"RegionDesc": "",
					"ConditionKeyDesc": "",
					"CustomerDesc": "",
					"PlantDesc": "",
					"CustomerNumber": "  ",
					"MaterialTypeDesc": "",
					"DistributorName": "",
					"DistributorNumber": "",
					"FreeLoads": "",
					"GovtBids": false,
					"ExcessRackCharge": "",
					"HasAgreementPrice": false,
					"CorpSign": false,
					"IsNegativeVariance": false,
					"ConditionKey": "",
					"LegalAgreement": false,
					"BillingFrequencyDesc": "",
					"MaterialDesc": "",
					"HQPay": "",
					"MaterialNumber": "",
					"MPPRAmount": "",
					"SummaryBill": "",
					"BillingDay": "",
					"OriginalAgreement": false,
					"BillingFrequency": "",
					"Per": "",
					"EligibleFOCPeriods": false,
					"PH1": "",
					"AgreementMachOnly": false,
					"PH1Desc": "",
					"PH2": "",
					"SpecialInstructions": false,
					"PH2Desc": "",
					"SecurityDeposit": false,
					"PH3": "",
					"PH3Desc": "",
					"PH4": "",
					"PH4Desc": "",
					"PriceGroup": "",
					"PriceGroupDesc": "",
					"PriceInclFreight": false,
					"PricingAgreement": "",
					"PricingProgram": "",
					"ProductHierarchy": "",
					"ProductHierarchyDesc": "",
					"Rate": "-",
					"SearchField": "",
					"Terms": "",
					"UnitPrice": "",
					"Unit": "",
					"ValidFrom": "\/Date(" + (new Date()).getTime() + ")\/",
					"ValidTo": "\/Date(" + (new Date()).getTime() + ")\/",
					"VarianceRate": ""
				},
				"DeltaCh": {
					"ConditionNumber": false,
					"ConditionTable": false,
					"ConditionType": false,
					"MaterialType": false,
					"Currency": false,
					"CustomerDesc": false,
					"CustomerNumber": false,
					"MaterialTypeDesc": false,
					"DistributorName": false,
					"DistributorNumber": false,
					"GovtBids": false,
					"ConditionKeyDesc": false,
					"Group": false,
					"GroupDesc": false,
					"HasAgreementPrice": false,
					"IsNegativeVariance": false,
					"MainGroup": false,
					"FreeLoads": false,
					"MainGroupDesc": false,
					"ExcessRackCharge": false,
					"MaterialDesc": false,
					"CorpSign": false,
					"MaterialNumber": false,
					"LegalAgreement": false,
					"MPPRAmount": false,
					"ConditionKey": false,
					"HQPay": false,
					"OriginalAgreement": false,
					"SummaryBill": false,
					"BillingDay": false,
					"Per": false,
					"BillingFrequency": false,
					"PH1": false,
					"EligibleFOCPeriods": false,
					"PH1Desc": false,
					"AgreementMachOnly": false,
					"PH2": false,
					"PH2Desc": false,
					"SpecialInstructions": false,
					"PH3": false,
					"SecurityDeposit": false,
					"PH3Desc": false,
					"PH4": false,
					"PH4Desc": false,
					"PriceGroup": false,
					"PriceGroupDesc": false,
					"PriceInclFreight": false,
					"PricingAgreement": false,
					"PricingProgram": false,
					"ProductHierarchy": false,
					"ProductHierarchyDesc": false,
					"Rate": false,
					"SearchField": false,
					"SubGroup": false,
					"SubGroupDesc": false,
					"Terms": false,
					"Unit": false,
					"ValidFrom": false,
					"ValidTo": false,
					"VarianceRate": false,
					"DestZone": false,
					"Region": false,
					"Plant": false,
					"DestZoneDesc": false,
					"RegionDesc": false,
					"PlantDesc": false,
					"UnitPrice": false
				},
				"DocumentNumber": "",
				"ConditionType": "",
				"ConditionTable": "",
				"MaterialNumber": "",
				"CustomerNumber": "  ",
				"MaterialType": "",
				"PriceGroup": "",
				"CustomerDesc": "",
				"PriceGroupDesc": "",
				"MaterialDesc": "",
				"MaterialTypeDesc": "",
				"PH1": "",
				"PH2": "",
				"PH3": "",
				"PH4": "",
				"PH1Desc": "",
				"PH2Desc": "",
				"Unit": "",
				"PH3Desc": "",
				"PH4Desc": "",
				"ConditionNumber": "",
				"Rate": "",
				"Currency": "%",
				"Origin": "",
				"ChangeFlag": "N",
				"ConditionKey": "",
				"Per": "0 ",
				"ConditionDesc": "",
				"ValidFrom": "\/Date(" + (new Date()).getTime() + ")\/",
				"ValidTo": "\/Date(" + (new Date()).getTime() + ")\/"
			});

			oEditModel.updateBindings(true);
		},
		
		/**
		 * Function to add  new row in On Invoice Discounts table
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		 onAddOnInvoiceDiscountPress: function(oEvent){
			var that = this;
			var oView = that.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableOnInvoiceDiscountSet = oEditModel.getProperty("/EditableOnInvoiceDiscountSet");

			if (!aEditableOnInvoiceDiscountSet) {
				aEditableOnInvoiceDiscountSet = [];
			}
			aEditableOnInvoiceDiscountSet.push({
				"ConditionKey": "",
				"CustomerNumber": "",
				"CustomerDesc": "",
				"PriceGroup": "",
				"PriceGroupDesc": "  ",
				"MaterialNumber": "",
				"MaterialDesc": "",
				"MaterialType": "",
				"MaterialTypeDesc": "",
				"OldRate": "",
				"Rate": "",
				"Currency": "%",
				"ChangeFlag": "N",
				"DocumentNumber": "",
				"CustomerEditable":false,
				"MaterialPriceEditable":false,
				"MaterialTypeEditable":false
				
			});
		oEditModel.updateBindings(true);
		},
		
		/**
		 * Pricing Tab Asset Addition dialog after Asset and Price Group selection
		 * In this function we prepare the Asset object with all properties as per metadata and child 
		 * hierarchy Delta is added with all properties to hold the old value bindings. This Asset
		 * object is added to EditModel at /EditableAssetSelectedKey array if there is not existing 
		 * Asset with same ProductHierarchy and PriceGroup values
		 * @param {object} oEvent
		 * @private
		 */
		onAddAssetPress: function (oEvent) {
			var me = this;
			var src = oEvent.getSource();
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableAssets = oEditModel.getProperty("/EditableAssets");

			var sProductHierarchy = oEditModel.getProperty("/AssetProductHierarchyForAdd");
			var sProductHierarchyDesc = oEditModel.getProperty("/AssetProductHierarchyDescForAdd");
			var sPriceGroup = oEvent.getSource().getTitle();

			me._oAssetSelectDialog.close();

			//Asset dupliction check
			var isAssetExists = false;
			aEditableAssets.forEach(function (oAsset, idx) {
				if (oAsset.ProductHierarchy === sProductHierarchy && oAsset.PriceGroup === sPriceGroup) {
					isAssetExists = true;
				}
			});

			if (!isAssetExists) {
				if (!aEditableAssets) {
					aEditableAssets = [];
				}

				aEditableAssets.push({
					"Delta": {
						"DocumentNumber": "",
						"ConditionNumber": "",
						"DestZone": "",
						"ConditionTable": "",
						"Region": "",
						"ConditionType": "",
						"Plant": "",
						"DestZoneDesc": "",
						"MaterialType": "",
						"Currency": "USD",
						"RegionDesc": "",
						"ConditionKeyDesc": "",
						"CustomerDesc": "",
						"PlantDesc": "",
						"CustomerNumber": " ",
						"MaterialTypeDesc": "",
						"DistributorName": "",
						"DistributorNumber": "",
						"FreeLoads": "",
						"GovtBids": false,
						"ExcessRackCharge": "",
						"HasAgreementPrice": false,
						"CorpSign": false,
						"IsNegativeVariance": false,
						"ConditionKey": "",
						"LegalAgreement": false,
						"MaterialDesc": "",
						"HQPay": "",
						"MaterialNumber": "",
						"MPPRAmount": "",
						"SummaryBill": "",
						"BillingDay": "",
						"OriginalAgreement": false,
						"BillingFrequency": "",
						"Per": "",
						"EligibleFOCPeriods": false,
						"PH1": "",
						"AgreementMachOnly": false,
						"PH1Desc": "",
						"PH2": "",
						"SpecialInstructions": false,
						"PH2Desc": "",
						"SecurityDeposit": false,
						"PH3": "",
						"PH3Desc": "",
						"PH4": "",
						"PH4Desc": "",
						"PriceGroup": "",
						"PriceGroupDesc": "",
						"PriceInclFreight": false,
						"PricingAgreement": "",
						"PricingProgram": "",
						"ProductHierarchy": "",
						"ProductHierarchyDesc": "",
						"Rate": "",
						"SearchField": "",
						"Terms": "",
						"UnitPrice": "",
						"Unit": "",
						"ValidFrom": "\/Date(" + (new Date()).getTime() + ")\/",
						"ValidTo": "\/Date(" + (new Date()).getTime() + ")\/",
						"VarianceRate": ""
					},
					"DocumentNumber": "",
					"ConditionType": "",
					"ConditionTable": "",
					"ProductHierarchy": sProductHierarchy,
					"ConditionNumber": "",
					"CustomerNumber": "",
					"CustomerDesc": "",
					"ProductHierarchyDesc": sProductHierarchyDesc,
					"PriceGroup": sPriceGroup,
					"PriceGroupDesc": "",
					"PricingProgram": "",
					"Terms": "",
					"MPPRAmount": "",
					"Rate": "",
					"Currency": "USD",
					"ValidFrom": "\/Date(" + (new Date()).getTime() + ")\/",
					"ValidTo": "\/Date(" + (new Date()).getTime() + ")\/",
					"ConditionDesc": "",
					"FreeLoads": "",
					"ExcessRackCharge": "",
					"CorpSign": false,
					"LegalAgreement": "",
					"HQPay": "",
					"SummaryBill": "",
					"BillingDay": "",
					"BillingFrequency": "M",
					"EligibleFOCPeriods": true,
					"AgreementMachOnly": false,
					"SpecialInstructions": false,
					"SecurityDeposit": false,
					"ChangeFlag": "N",
					"ConditionKey": "",
					"IsChPending": false
				});

				oEditModel.setProperty("/EditableAssetSelectedKey", aEditableAssets[(aEditableAssets.length - 1)].ProductHierarchy);

				oEditModel.updateBindings(true);
			} else {
				//Show dulicate asset message
				MessageToast.show(this.bundle.getText("DuplicateAssetFoundMessage"), {
					duration: 3000
				});
			}

			me._setAsssetCarouselActivePage(sProductHierarchy);
		},

		/**
		 * View only function related to Assets View inside pricing tab
		 * This function links Assset Select control with Carousel Page that displayed
		 */
		onAssetChange: function (oEvent) {
			var me = this;
			var src = oEvent.getSource();
			if (src instanceof sap.m.ComboBox) {
				me._setAsssetCarouselActivePage(src.getSelectedItem().getKey());
			} else if (src instanceof sap.m.Carousel) {
				me._updateAsssetSelectAsAssetCarousel();
			}
		},

		/**
		 * Function to show the Asset in Carousel as sProductHierarchy value
		 * @param {string} sProductHierarchy
		 * @private
		 */
		_setAsssetCarouselActivePage: function (sProductHierarchy) {
			var me = this;
			var oView = me.getView();
			var assetsCarousel = oView.byId("idAssetCarousel");
			var carouselPages = assetsCarousel.getPages();
			carouselPages.forEach(function (oPage, idx) {
				if (me._getCustomDataValue(oPage.getCustomData(), "ProductHierarchy") === sProductHierarchy) {
					assetsCarousel.setActivePage(oPage);
					return;
				}
			});
		},

		/**
		 * Function to update Asset Selection dropdown in price tab if Asset Carousel 
		 * view page changes
		 * @private
		 */
		_updateAsssetSelectAsAssetCarousel: function () {
			var me = this;
			var oView = me.getView();
			var assetsCarousel = oView.byId("idAssetCarousel");
			var oEditModel = oView.getModel("EditModel");
			var assetPageId = assetsCarousel.getActivePage();
			var assetPage = false;

			//get the carousel active page object from page id.
			assetsCarousel.getPages().forEach(function (oPage, idx) {
				if (oPage.getId() === assetPageId) {
					assetPage = oPage;
				}
			});
			oEditModel.setProperty("/EditableAssetSelectedKey", me._getCustomDataValue(assetPage.getCustomData(), "ProductHierarchy"));
		},

		/**
		 * @param {event} oEvent - event of Asset managament table Delete button
		 * Calling this function when user clicks on delete button in Asset Table
		 * 
		 */
		onAssetDeletePress: function (oEvent) {
			var me = this;
			var src = oEvent.getSource();
			var oView = me.getView();
			var assetsCarousel = oView.byId("idAssetCarousel");
			var oEditModel = oView.getModel("EditModel");
			var aEditableAssets = oEditModel.getProperty("/EditableAssets");
			var sProductHierarchy = me._getCustomDataValue(src.getCustomData(), "ProductHierarchy");
			var sPriceGroup = me._getCustomDataValue(src.getCustomData(), "PriceGroup");

			//Data keeping to handle undo operations on assets
			if (!me.assetDeleteOldFlag) {
				me.assetDeleteOldFlag = {};
			}

			aEditableAssets.forEach(function (oAsset, idx) {
				if (oAsset && oAsset.ChangeFlag === "N" && oAsset.ProductHierarchy === sProductHierarchy && oAsset.PriceGroup === sPriceGroup) {
					assetsCarousel.next();
					aEditableAssets.splice(idx, 1);
				} else if (oAsset && oAsset.ChangeFlag !== "N" && oAsset.ProductHierarchy === sProductHierarchy && oAsset.PriceGroup ===
					sPriceGroup) {
					me.assetDeleteOldFlag[sProductHierarchy + "-" + sPriceGroup] = oAsset.ChangeFlag;
					oAsset.ChangeFlag = "D";
				}
			});
			oEditModel.checkUpdate(false);
		},

		/**
		 * @param {event} oEvent - event of Asset managament table Delete Undo button
		 * Calling this function when user clicks on Undo button after delete in Asset Table
		 */
		onAssetDeleteUndoPress: function (oEvent) {
			var me = this;
			var src = oEvent.getSource();
			var oView = me.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditableAssets = oEditModel.getProperty("/EditableAssets");
			var sProductHierarchy = me._getCustomDataValue(src.getCustomData(), "ProductHierarchy");
			var sPriceGroup = me._getCustomDataValue(src.getCustomData(), "PriceGroup");

			aEditableAssets.forEach(function (oAsset, idx) {
				if (oAsset && oAsset.ProductHierarchy === sProductHierarchy && oAsset.PriceGroup === sPriceGroup && me.assetDeleteOldFlag[
						sProductHierarchy + "-" + sPriceGroup]) {
					oAsset.ChangeFlag = me.assetDeleteOldFlag[sProductHierarchy + "-" + sPriceGroup];
					return;
				} else if (oAsset && oAsset.ProductHierarchy === sProductHierarchy && oAsset.PriceGroup === sPriceGroup && !me.assetDeleteOldFlag[
						sProductHierarchy + "-" + sPriceGroup]) {
					oAsset.ChangeFlag = "R";
					return;
				}
			});
			oEditModel.checkUpdate(false);
		},

		/**
		 * Method to validate the rate field in Products Table
		 * @ private
		 */
		_isProductsValid: function () {
			var isValid = true;
			var oEditModel = this.getView().getModel("EditModel");
			var aEditableProducts = oEditModel.getProperty("/EditableProducts");
			var oProduct;
			for(var idx = 0; idx < aEditableProducts.length; idx++){
				oProduct = aEditableProducts[idx];
				if(oProduct.ProductChanged !== "D"){
					if(isNaN(oProduct.NewRate) || oProduct.NewRate.length === 0){
						isValid = false;
						oProduct.ValidRate = false;
					}
					
					if(!oProduct.MaterialNumber || oProduct.MaterialNumber === ""){
						isValid = false;
						oProduct.MaterialNumberStatus = "Error";
					}
					
					if(!oProduct.NewPer || oProduct.NewPer === ""){
						isValid = false;
						oProduct.NewPerStatus = "Error";
					}
				}
			}
			oEditModel.updateBindings(false);
			return isValid;
		},
		
		/**
		 * Method to validate the rate field in PriceException Table
		 * @ private
		 */
		_isPriceExceptionsValid: function () {
			var isValid = true;
			var oEditModel = this.getView().getModel("EditModel");
			var aEditablePriceExceptions = oEditModel.getProperty("/EditablePriceExceptions");
			// return !aEditablePriceExceptions.some(function (oPriceExp, idx, aPriceExps) {
			// 	aEditablePriceExceptions[idx].ValidRate = (!isNaN(oPriceExp.NewRate) && oPriceExp.NewRate.length !== 0);
			// 	oEditModel.checkUpdate(false);
			// 	return !oPriceExp.ValidRate;
			// });
			
			var oPriceExp;
			for(var idx = 0; idx < aEditablePriceExceptions.length; idx++){
				oPriceExp = aEditablePriceExceptions[idx];
				if(oPriceExp.PriceExpChanged !== "D"){
					if(isNaN(oPriceExp.NewRate) || oPriceExp.NewRate.length === 0){
						isValid = false;
						oPriceExp.ValidRate = false;
					}
					
					if(!oPriceExp.CustomerNumber || oPriceExp.CustomerNumber === ""){
						isValid = false;
						oPriceExp.CustomerNumberState = "Error";
					}
					
					if(!oPriceExp.MaterialNumber || oPriceExp.MaterialNumber === ""){
						isValid = false;
						oPriceExp.MaterialNumberState = "Error";
					}				
					
					if(!oPriceExp.NewPer || oPriceExp.NewPer === ""){
						isValid = false;
						oPriceExp.NewPerStatus = "Error";
					}
				}
			}
			oEditModel.updateBindings(false);
			return isValid;
		},
		
		/**
		 * Method to validate the rate field in PriceException Table
		 * @ private
		 */
		_isFlatFeeManagementValid: function () {
			var isValid = true;
			var oEditModel = this.getView().getModel("EditModel");
			var aEditableFlatFees = oEditModel.getProperty("/EditableFlatFee");

			var oFlatFee;
			for(var idx = 0; idx < aEditableFlatFees.length; idx++){
				oFlatFee = aEditableFlatFees[idx];
				if(oFlatFee.FlatFeeChanged !== "D"){
					if(!oFlatFee.ConditionKey || oFlatFee.ConditionKey === ""){
						isValid = false;
						oFlatFee.ConditionKeyState = "Error";
					}
					if(!oFlatFee.ProgramTypeDesc || oFlatFee.ProgramTypeDesc === ""){
						isValid = false;
						oFlatFee.ProgramTypeDescState = "Error";
					}
					if(!oFlatFee.CustomerNumber || oFlatFee.CustomerNumber === ""){
						isValid = false;
						oFlatFee.CustomerNumberState = "Error";
					}
					
					if((oFlatFee.ConditionKey === "Z1MP668" || oFlatFee.ConditionKey === "ZFTP668") && (!oFlatFee.BillingDay || oFlatFee.BillingDay === "")){
						isValid = false;
						oFlatFee.BillingDayState = "Error";
					}else{
						oFlatFee.BillingDayState = "None";
					}
					
					if((oFlatFee.ConditionKey === "Z1MP668" || oFlatFee.ConditionKey === "ZFTP668") && (!oFlatFee.BillingFrequency || oFlatFee.BillingFrequency === "")){
						isValid = false;
						oFlatFee.BillingFrequencyState = "Error";
					}else{
						oFlatFee.BillingFrequencyState = "None";
					}
					
					if(!oFlatFee.MaterialNumber || oFlatFee.MaterialNumber === ""){
						isValid = false;
						oFlatFee.MaterialNumberState = "Error";
					}else{
						oFlatFee.MaterialNumberState = "None";
					}
					
					if(!oFlatFee.NewUnitPrice || oFlatFee.NewUnitPrice === ""){
						isValid = false;
						oFlatFee.ValidUnitPrice = false;
					}
				}
			}
			oEditModel.updateBindings(false);
			return isValid;
		},	
		
		/**
		 * Function to validate DiscountOff table row inputs
		 * @private
		 * @return {boolean} true/false to indicate isValid or not
		 */
		_isDiscountsOffValid: function () {
			var isValid = true;
			var oEditModel = this.getView().getModel("EditModel");
			var aEditableDiscountOffSet = oEditModel.getProperty("/EditableDiscountOffSet");

			var oDiscountOff;
			for(var idx = 0; idx < aEditableDiscountOffSet.length; idx++){
				oDiscountOff = aEditableDiscountOffSet[idx];
				if(oDiscountOff.ChangeFlag !== "D"){
					
					if(oDiscountOff.ConditionKey === "Z1PD657"){ //If condition value is selected
						if(!oDiscountOff.PriceGroup || oDiscountOff.PriceGroup.trim() === ""){
							isValid = false;
							oDiscountOff.PriceGroupState = "Error";
						}	
					}else if(oDiscountOff.ConditionKey === "Z1PD758"){
						if(!oDiscountOff.MaterialNumber || oDiscountOff.MaterialNumber.trim() === ""){
							isValid = false;
							oDiscountOff.MaterialNumberState = "Error";
						}
					}else{
						isValid = false;
						oDiscountOff.ConditionKeyState = "Error";
						oDiscountOff.PriceGroupState = "None";
						oDiscountOff.MaterialNumberState = "None";
					}
					
					if(!oDiscountOff.CustomerNumber || oDiscountOff.CustomerNumber.trim() === ""){
						isValid = false;
						oDiscountOff.CustomerNumberState = "Error";
					}
					if(isNaN(oDiscountOff.Rate) || oDiscountOff.Rate.length === 0){
						isValid = false;
						oDiscountOff.RateState = "Error";
					}					
				}
			}
			oEditModel.updateBindings(false);
			return isValid;
		},
		
		_isOnInVoiceDiscountsOffValid: function () {
			var isValid = true;
			var oEditModel = this.getView().getModel("EditModel");
			var aEditableOnInvoiceDiscountSet = oEditModel.getProperty("/EditableOnInvoiceDiscountSet");

			var aOnInvoiceDiscounts;
			for(var idx = 0; idx < aEditableOnInvoiceDiscountSet.length; idx++){
				aOnInvoiceDiscounts = aEditableOnInvoiceDiscountSet[idx];
				if(aOnInvoiceDiscounts.ChangeFlag !== "D"){
					
					if(aOnInvoiceDiscounts.ConditionKey === "Z1VL657" || aOnInvoiceDiscounts.ConditionKey === "Z1VR657"){ //If condition value is selected
						if(!aOnInvoiceDiscounts.PriceGroup || aOnInvoiceDiscounts.PriceGroup.trim() === ""){
							isValid = false;
							aOnInvoiceDiscounts.PriceGroupState = "Error";
						}
						else if(!aOnInvoiceDiscounts.CustomerNumber || aOnInvoiceDiscounts.CustomerNumber.trim() === ""){
						isValid = false;
						aOnInvoiceDiscounts.CustomerNumberState = "Error";
						}
					}else if(aOnInvoiceDiscounts.ConditionKey === "Z1VL662"){
						if(!aOnInvoiceDiscounts.MaterialType || aOnInvoiceDiscounts.MaterialType.trim() === ""){
							isValid = false;
							aOnInvoiceDiscounts.MaterialTypeState = "Error";
						} else if(!aOnInvoiceDiscounts.CustomerNumber || aOnInvoiceDiscounts.CustomerNumber.trim() === ""){
						isValid = false;
						aOnInvoiceDiscounts.CustomerNumberState = "Error";
						}
					}else if(aOnInvoiceDiscounts.ConditionKey === "Z1VL976"){
						if(!aOnInvoiceDiscounts.CustomerNumber || aOnInvoiceDiscounts.CustomerNumber.trim() === ""){
						isValid = false;
						aOnInvoiceDiscounts.CustomerNumberState = "Error";
						}
					}else if(aOnInvoiceDiscounts.ConditionKey === "Z1VR654"){
						if(!aOnInvoiceDiscounts.ConditionKey || aOnInvoiceDiscounts.ConditionKey.trim() === ""){
						isValid = false;
						aOnInvoiceDiscounts.ConditionKeyState = "Error";
						}
					}else{
						isValid = false;
						aOnInvoiceDiscounts.ConditionKeyState = "Error";
						aOnInvoiceDiscounts.PriceGroupState = "None";
						aOnInvoiceDiscounts.MaterialTypeState = "None";
						aOnInvoiceDiscounts.CustomerNumberState = "None";
					}
					
					if(!aOnInvoiceDiscounts.CustomerNumber || aOnInvoiceDiscounts.CustomerNumber.trim() === ""){
						isValid = false;
						aOnInvoiceDiscounts.CustomerNumberState = "Error";
					}
					if(isNaN(aOnInvoiceDiscounts.Rate) || aOnInvoiceDiscounts.Rate.length === 0){
						isValid = false;
						aOnInvoiceDiscounts.RateState = "Error";
					}					
				}
			}
			oEditModel.updateBindings(false);
			return isValid;
		},
		
		/**
		 * Method to Handle Products,PriceException, post call payload
		 * @ oHeaderInfoPayload- oHeaderInfoPayload is the the Payload .
		 * Here we are preparing the payload for the Products ,PriceException,FlatFee sections
		 * After preparing the payload we are pushing them to corresponding ProductSet,PriceExceptionSet,FlatFeeSet Arrays in HeaderInfo payload 
		 */
		_preparePricingPayload: function (oHeaderInfoPayload) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var aEditProducts = oEditModel.getProperty("/EditableProducts");

			//Preparing Products payload
			var aProductResults = [];
			var oProductResult = {};
			aEditProducts.forEach(function (oProduct, idx) {
				oProductResult = {};
				oProductResult.DocumentNumber = oProduct.DocumentNumber;
				oProductResult.MaterialNumber = oProduct.MaterialNumber;
				oProductResult.MaterialDesc = oProduct.MaterialDesc;
				oProductResult.Rate = oProduct.NewRate + "";
				oProductResult.Per = oProduct.NewPer;
				oProductResult.Currency = oProduct.Currency;
				oProductResult.ConditionType = oProduct.NewConditionType;
				oProductResult.ConditionKey = oProduct.NewConditionKey;
				oProductResult.ConditionDesc = oProduct.NewConditionDesc;
				oProductResult.ConditionNumber = oProduct.ConditionNumber;
				oProductResult.ConditionNumber2 = oProduct.ConditionNumber2;
				oProductResult.Unit = oProduct.Unit;
				oProductResult.OriginalAgreement = oProduct.NewOriginalAgreement;
				oProductResult.GovtBids = oProduct.NewGovtBids;
				oProductResult.PriceInclFreight = oProduct.NewPriceInclFreight;
				oProductResult.SearchField = "";
				oProductResult.ChangeFlag = oProduct.ProductChanged;
				aProductResults.push(oProductResult);
			});
			oHeaderInfoPayload.ProductSet.results = aProductResults;

			//Preparing Price Exceptions
			var aPriceExpResults = [];
			var oPriceExpResult = {};
			var aEditPriceExceptions = oEditModel.getProperty("/EditablePriceExceptions");
			aEditPriceExceptions.forEach(function (oPriceExp, idx) {
				oPriceExpResult = {};
				oPriceExpResult.DocumentNumber = oPriceExp.DocumentNumber;
				oPriceExpResult.CustomerNumber = oPriceExp.CustomerNumber;
				oPriceExpResult.CustomerDesc = oPriceExp.CustomerDesc;
				oPriceExpResult.MaterialNumber = oPriceExp.MaterialNumber;
				oPriceExpResult.MaterialDesc = oPriceExp.MaterialDesc;
				oPriceExpResult.Rate = oPriceExp.NewRate + "";
				oPriceExpResult.Per = oPriceExp.NewPer;
				oPriceExpResult.Currency = oPriceExp.Currency;
				oPriceExpResult.ConditionType = oPriceExp.NewConditionType;
				oPriceExpResult.ConditionKey = oPriceExp.NewConditionKey;
				oPriceExpResult.ConditionDesc = oPriceExp.NewConditionDesc;
				oPriceExpResult.ConditionNumber = oPriceExp.ConditionNumber;
				oPriceExpResult.ConditionNumber2 = oPriceExp.ConditionNumber2;
				oPriceExpResult.Unit = oPriceExp.Unit;
				oPriceExpResult.PriceInclFreight = oPriceExp.NewPriceInclFreight;
				oPriceExpResult.ChangeFlag = oPriceExp.PriceExpChanged;
				aPriceExpResults.push(oPriceExpResult);
			});
			oHeaderInfoPayload.PriceExceptionSet.results = aPriceExpResults;

			//Preparing FlatFee
			var aFlatFeeResults = [];
			var oFlatFeeResult = {};
			var aEditFlatFee = oEditModel.getProperty("/EditableFlatFee");
			aEditFlatFee.forEach(function (oFlatFee, idx) {
				oFlatFeeResult = {};
				oFlatFeeResult.DocumentNumber = oFlatFee.DocumentNumber;
				oFlatFeeResult.ConditionType = oFlatFee.ConditionType;
				oFlatFeeResult.ConditionTable = oFlatFee.ConditionTable;
				oFlatFeeResult.MaterialNumber = oFlatFee.MaterialNumber;
				oFlatFeeResult.CustomerNumber = oFlatFee.CustomerNumber;
				oFlatFeeResult.PriceGroup = oFlatFee.ProgramType;
				oFlatFeeResult.ConditionNumber = oFlatFee.ConditionNumber;
				oFlatFeeResult.Rate = oFlatFee.Rate;
				oFlatFeeResult.Currency = oFlatFee.Currency;
				oFlatFeeResult.Per = oFlatFee.Per;
				oFlatFeeResult.Unit = oFlatFee.Unit;
				oFlatFeeResult.UnitPrice = oFlatFee.NewUnitPrice;
				oFlatFeeResult.ConditionKey = oFlatFee.ConditionKey;
				oFlatFeeResult.ChangeFlag = oFlatFee.FlatFeeChanged;
				oFlatFeeResult.BillingDay = oFlatFee.BillingDay;
				oFlatFeeResult.BillingFrequency = oFlatFee.BillingFrequency;
				aFlatFeeResults.push(oFlatFeeResult);
			});
			oHeaderInfoPayload.FlatFeeSet.results = aFlatFeeResults;

			//Preparing AssetSet
			var aAssetResults = [];
			var oAssetResult = {};
			var aEditableAssets = oEditModel.getProperty("/EditableAssets");
			aEditableAssets.forEach(function (oAsset, idx) {
				oAssetResult = {};
				oAssetResult.DocumentNumber = oAsset.DocumentNumber;
				oAssetResult.ConditionType = oAsset.ConditionType;
				oAssetResult.ConditionTable = oAsset.ConditionTable;
				oAssetResult.ProductHierarchy = oAsset.ProductHierarchy;
				oAssetResult.ConditionNumber = oAsset.ConditionNumber;
				oAssetResult.CustomerNumber = oAsset.CustomerNumber;
				oAssetResult.CustomerDesc = oAsset.CustomerDesc;
				oAssetResult.ProductHierarchyDesc = oAsset.ProductHierarchyDesc;
				oAssetResult.PriceGroup = oAsset.PriceGroup;
				oAssetResult.PriceGroupDesc = oAsset.PriceGroupDesc;
				oAssetResult.PricingProgram = oAsset.PricingProgram;
				oAssetResult.Terms = oAsset.Terms;
				oAssetResult.MPPRAmount = oAsset.MPPRAmount;
				oAssetResult.Rate = oAsset.Rate;
				oAssetResult.Currency = oAsset.Currency;
				oAssetResult.ValidFrom = oAsset.ValidFrom;
				oAssetResult.ValidTo = oAsset.ValidTo;
				oAssetResult.ConditionDesc = oAsset.ConditionDesc;
				oAssetResult.FreeLoads = oAsset.FreeLoads;
				oAssetResult.ExcessRackCharge = oAsset.ExcessRackCharge;
				oAssetResult.CorpSign = oAsset.CorpSign;
				oAssetResult.LegalAgreement = oAsset.LegalAgreement;
				oAssetResult.HQPay = oAsset.HQPay;
				oAssetResult.SummaryBill = oAsset.SummaryBill;
				oAssetResult.BillingDay = oAsset.BillingDay;
				oAssetResult.BillingFrequency = oAsset.BillingFrequency;
				oAssetResult.EligibleFOCPeriods = oAsset.EligibleFOCPeriods;
				oAssetResult.AgreementMachOnly = oAsset.AgreementMachOnly;
				oAssetResult.SpecialInstructions = oAsset.SpecialInstructions;
				oAssetResult.SecurityDeposit = oAsset.SecurityDeposit;
				oAssetResult.ChangeFlag = oAsset.ChangeFlag;
				oAssetResult.ConditionKey = oAsset.ConditionKey;
				aAssetResults.push(oAssetResult);
			});
			oHeaderInfoPayload.AssetSet.results = aAssetResults;

			return oHeaderInfoPayload;
		},
		
		/**
		 * Function to prepare Discounts payload data for save
		 * @private
		 * @param {Object} oHeaderInfoPayload Header data object
		 * @reuturn {Object} Returns Head data object with DiscountOff data
		 */
		_prepareDiscountsPayload: function (oHeaderInfoPayload) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");

			//Preparing DiscountOffSet
			var aoDiscountOffResults = [];
			var oDiscountOffResult = {};
			var aEditableDiscountOffSet = oEditModel.getProperty("/EditableDiscountOffSet");
			aEditableDiscountOffSet.forEach(function (oDiscountOff, idx) {
				oDiscountOffResult = {};
				oDiscountOffResult.DocumentNumber = oDiscountOff.DocumentNumber;
				oDiscountOffResult.ConditionType = oDiscountOff.ConditionType;
				oDiscountOffResult.ConditionTable = oDiscountOff.ConditionTable;
				oDiscountOffResult.MaterialNumber = oDiscountOff.MaterialNumber;
				oDiscountOffResult.CustomerNumber = oDiscountOff.CustomerNumber;
				oDiscountOffResult.MaterialType = oDiscountOff.MaterialType;
				oDiscountOffResult.PriceGroup = oDiscountOff.PriceGroup;
				oDiscountOffResult.CustomerDesc = oDiscountOff.CustomerDesc;
				oDiscountOffResult.PriceGroupDesc = oDiscountOff.PriceGroupDesc;
				oDiscountOffResult.MaterialDesc = oDiscountOff.MaterialDesc;
				oDiscountOffResult.MaterialTypeDesc = oDiscountOff.MaterialTypeDesc;
				oDiscountOffResult.Unit = oDiscountOff.Unit;
				oDiscountOffResult.ConditionNumber = oDiscountOff.ConditionNumber;
				oDiscountOffResult.Rate = oDiscountOff.Rate;
				oDiscountOffResult.Currency = oDiscountOff.Currency;
				oDiscountOffResult.Origin = oDiscountOff.Origin;
				oDiscountOffResult.ChangeFlag = oDiscountOff.ChangeFlag;
				oDiscountOffResult.ConditionKey = oDiscountOff.ConditionKey;
				oDiscountOffResult.Per = oDiscountOff.Per;
				oDiscountOffResult.ConditionDesc = oDiscountOff.ConditionDesc;
				oDiscountOffResult.ValidFrom = oDiscountOff.ValidFrom;
				oDiscountOffResult.ValidTo = oDiscountOff.ValidTo;
				aoDiscountOffResults.push(oDiscountOffResult);
			});
			oHeaderInfoPayload.DiscountOffSet.results = aoDiscountOffResults;

			return oHeaderInfoPayload;
		},
		
		_prepareOnInvoiceDiscountsPayload: function (oHeaderInfoPayload) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");

			//Preparing DiscountOffSet
			var aOnInvoiceDiscountsResults = [];
			var sOnInvoiceDiscountsResult = {};
			var aEditableOnInvoiceDiscountsSet = oEditModel.getProperty("/EditableOnInvoiceDiscountSet");
			aEditableOnInvoiceDiscountsSet.forEach(function (OnInvoiceDiscounts, idx) {
				sOnInvoiceDiscountsResult = {};
				sOnInvoiceDiscountsResult.DocumentNumber = OnInvoiceDiscounts.DocumentNumber;
				sOnInvoiceDiscountsResult.ConditionType = OnInvoiceDiscounts.ConditionType;
				sOnInvoiceDiscountsResult.CustomerNumber = OnInvoiceDiscounts.CustomerNumber;
				sOnInvoiceDiscountsResult.MaterialType = OnInvoiceDiscounts.MaterialType;
				sOnInvoiceDiscountsResult.PriceGroup = OnInvoiceDiscounts.PriceGroup;
				sOnInvoiceDiscountsResult.CustomerDesc = OnInvoiceDiscounts.CustomerDesc;
				sOnInvoiceDiscountsResult.PriceGroupDesc = OnInvoiceDiscounts.PriceGroupDesc;
				sOnInvoiceDiscountsResult.MaterialTypeDesc = OnInvoiceDiscounts.MaterialTypeDesc;
				sOnInvoiceDiscountsResult.Rate = OnInvoiceDiscounts.Rate;
				sOnInvoiceDiscountsResult.Currency = OnInvoiceDiscounts.Currency;
				sOnInvoiceDiscountsResult.ChangeFlag = OnInvoiceDiscounts.ChangeFlag;
				sOnInvoiceDiscountsResult.ConditionKey = OnInvoiceDiscounts.ConditionKey;
				aOnInvoiceDiscountsResults.push(sOnInvoiceDiscountsResult);
			});
			oHeaderInfoPayload.OnInvoiceDiscountSet.results = aOnInvoiceDiscountsResults;

			return oHeaderInfoPayload;
		},
		
		/**
		 * @param {event} oEvent - event of FlatFee table add button press
		 * In this function we are adding empty record to FlatFee table with default values
		 */
		onAddFlatFeePress: function (oEvent) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var aFlatFeeData = oEditModel.getProperty("/EditableFlatFee");
			aFlatFeeData.push({
				CustomerNumber: "",
				CustomerDesc: "",
				ProgramType: "",
				ProgramTypeDesc: "",
				MaterialNumber: "",
				MaterialDesc: "",
				DocumentNumber: "",
				ChangeFlag: "N",
				ConditionTypeFlag: false,
				ConditionKey: "",
				ChangeIcon: "I",
				MaterialEditable: true,
				ValidUnitPrice: true,
				FlatFeeDeleted: false,
				FlatFeeInserted: true,
				FlatFeeChanged: "I",
				FlatFeeEnable: false,
				ProgramTypeDescEnable: false,
				CustomerNumberState : "None",
				ProgramTypeDescState : "None",
				IsChPending: false
			});
			oEditModel.checkUpdate(true);
			var EditProductsTable = oView.byId("EditFlatFeeTable");
			EditProductsTable.setFirstVisibleRow(aFlatFeeData.length - 1);
			EditProductsTable.rerender();
		},

		/**
		 * This is the FlatFee delete undo icon press function.
		 * In this function we are revertig the deletion process. 
		 * @private
		 * @param {sap.ui.base.Event} oEvent - event of FlatFee delete undo icon press
		 */
		onFlatFeeDeleteUndoPress: function (oEvent) {
			var oControl = oEvent.getSource();
			var oSelectedFlatFee = oControl.getBindingContext("EditModel").getObject();
			if (oSelectedFlatFee["ChangeFlag"] === "D") {
				oSelectedFlatFee["FlatFeeUnDeleted"] = true;
				oSelectedFlatFee["FlatFeeDeleted"] = false;
				oSelectedFlatFee["FlatFeeChanged"] = "R";
			} else {
				oSelectedFlatFee["FlatFeeDeleted"] = false;
				oSelectedFlatFee["FlatFeeChanged"] = oSelectedFlatFee["ChangeFlag"];
			}
			oControl.getModel("EditModel").checkUpdate(true);
			this.getView().byId("idFlatFeeTable").rerender();
		},
		
		/**
		 * @param {oEvent} oEvent -event of FlatFee table ProgramTypeDescription column ValueHelp press
		 * In this function, ProgramType VH popup is populated when user presses on Input field 
		 */
		onProgramTypeVHPress: function (oEvent) {
			this.ProgramType = {};
			this.ProgramType.SelectedProgTypFldId = oEvent.getSource().getId();
			this.ProgramType.SelectedProgTypFldIdx = oEvent.getSource().getBindingContext("EditModel").sPath.split("/")[2];
			if (!this._ProgramTypeValueHelpDialog) {
				this._ProgramTypeValueHelpDialog = sap.ui.xmlfragment(
					"com.ecolab.ZASBMasterAgr.fragment.edit.ProgramTypeValueHelp",
					this
				);
				this.getView().addDependent(this._ProgramTypeValueHelpDialog);
			}
			this._ProgramTypeValueHelpDialog.open();
		},

		/**
		 * In this Method, ProgramType VH popup is Closed when user presses on cancel button on the popup 
		 */
		onProgramTypeVHCancel: function () {
			this._ProgramTypeValueHelpDialog.close();
		},

		/**
		 * @param {event} oEvent - ProgramType VH Selected List listitem press
		 * In this function, we are adding selected ProgramType  to FlatFee table.
		 */
		onProgramTypeVHConfirm: function (oEvent, oFirstItem) {
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var oSelctedItem = oEvent.getParameter("listItem");
			var iSelectedProgTypFldId = this.ProgramType.SelectedProgTypFldIdx;
			var aEditableFlatFee = oEditModel.getProperty("/EditableFlatFee");
			var oEditFlatFee = oView.byId("EditFlatFeeTable");
			if (!this._getIsDuplicateFlatFee("ProgramType", oSelctedItem.getTitle(), aEditableFlatFee)) {
				oEditModel.setProperty("/EditableFlatFee/" + iSelectedProgTypFldId + "/ProgramTypeDesc", oSelctedItem.getInfo());
				oEditModel.setProperty("/EditableFlatFee/" + iSelectedProgTypFldId + "/ProgramType", oSelctedItem.getTitle());
				oEditModel.setProperty("/EditableFlatFee/" + iSelectedProgTypFldId + "/ProgramTypeDescEditable", false);
			} else {
				this._deleteRecordOnDuplicateEntry(oEditFlatFee, aEditableFlatFee, iSelectedProgTypFldId);
				oEditModel.checkUpdate(true);
			}
			this._ProgramTypeValueHelpDialog.close();
		},
		/**
		 * Method to populate Sort dialog & Filter dialog in Pricing Section
		 * @private
		 */
		_getProdSortAndFilterDialog: function () {
			if (!this._oProdSortAndFilterDialog) {
				this._oProdSortAndFilterDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.edit.ProductsSort", this);
				this.getView().addDependent(this._oProdSortAndFilterDialog);
			}
			this._oProdSortAndFilterDialog._getNavContainer().attachAfterNavigate({}, function (evt) {
				if (evt.getParameter("isBack")) {
					this._oProdSortAndFilterDialog._getDialog().setContentWidth("auto");
				}
			}, this);

			return this._oProdSortAndFilterDialog;
		},
		ProductsSortPress: function(oEvent){
			var oSource = oEvent.getSource();
			var oCustomData = oSource.data("SortKey");
			if (oCustomData === "Sort") {
				this._getProdSortAndFilterDialog().open("sort");
			}
			this._oProdSortAndFilterDialog._getDialog().setContentWidth("350px");
			this._oProdSortAndFilterDialog.setModel(this.getView().getModel());
			this._oProdSortAndFilterDialog.setModel(sap.ui.getCore().getModel("i18n"), "i18n");
		},
		onProdSortAndFilterConfirm: function (oEvent) {
			var aFilters = [];
			var oStatusFilter = [];
			var oTable = this.getView().byId("EditProductsTable"); //
			var oBinding = oTable.getBinding("rows");

			//Sorting
			var mParams = oEvent.getParameters();
			var sPath;
			var bDescending;
			var aSorters = [];
			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));
			}
			oBinding.sort(aSorters);
		},
		/**
		 * @param {oEvent} oEvent - ProgramType VH popup Search 
		 * In this function, we are searching on PriceGroup,PriceGroupDescription.
		 */
		onProgramTypeVHSearch: function (oEvent) {
			var nPriceGroup = sap.ui.getCore().byId("idPriceGroup").getValue();
			var nPriceGroupDesc = sap.ui.getCore().byId("idPriceGroupDescc").getValue();
			var aProgramTypeFilter = [];
			if (nPriceGroup !== "") {
				aProgramTypeFilter.push(new Filter("PriceGroup", sap.ui.model.FilterOperator.Contains, nPriceGroup));
			}
			if (nPriceGroupDesc !== "") {
				aProgramTypeFilter.push(new Filter("PriceGroupDesc", sap.ui.model.FilterOperator.Contains, nPriceGroupDesc));
			}
			sap.ui.getCore().byId("idProgramTypeList").getBinding("items").filter(aProgramTypeFilter);
		},

		/**
		 * Method to populate Customer ValueHelp Dialog in FlatFee and PriceException Table
		 */
		_getCustomerDailog: function () {
			// create value help dialog
			if (!this._CustomerValueHelpDialog) {
				this._CustomerValueHelpDialog = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.edit.CustomerValueHelp", this);
				this.getView().addDependent(this._CustomerValueHelpDialog);
			}
			this._CustomerValueHelpDialog.open();
		},

		/**
		 * @param {oEvent} oEvent -event of Asset table Column ValueHelp press  (Created Temporary function)
		 * In this function, Customer VH popup is populated when user presses on Input field of Asset table
		 */
		onCustomerAssetPress: function (oEvent) {
			this._getCustomerDailog();
			var oView = this.getView();
			var oCountryModel = oView.getModel("CountryModel");
			var oControl = oEvent.getSource();
			this.customerInput = oControl.data("flag");
			this.Customer = {};
			this.Customer.SelectedCustomerFldId = oControl.getId();
			this.Customer.SelectedCustomerFldIdx = oControl.getBindingContext("oAssetModel").sPath.split("/")[2];
			var oHeaderData = oView.getModel().getObject("/HeaderSet('" + this.sDocumentNumber + "')/ValueFields");
			var oCountry = oHeaderData.Country;
			var oFliters = [new Filter("Country", "EQ", oCountry)];
			var oList = sap.ui.getCore().byId("idCustomerList");
			var oTemplate = new sap.m.StandardListItem({
				title: "{Customer}",
				description: "{Name}"
			});
			oList.bindAggregation("items", "/PartnerValueHelpSet", oTemplate);
			oList.getBinding("items").filter(oFliters);
			oCountryModel.setProperty("/SelectedCountry", oCountry);
		},

		/**
		 * @param {sap.ui.base.Event} oEvent of FlatFee table Sold To  Column ValueHelp press
		 * In this function, Customer VH popup is populated when user presses on Input field 
		 */
		onCustomerVHPress: function (oEvent) {
			this.clearInputErrorState(oEvent);
			this._getCustomerDailog();
			var oFliters;
			var oView = this.getView();
			var oCountryModel = oView.getModel("CountryModel");
			var oControl = oEvent.getSource();
			if(!this.sDocumentNumber){
				this.sDocumentNumber = "";
			}
			var oHeaderData = oView.getModel().getObject("/HeaderSet('" + this.sDocumentNumber + "')/ValueFields");
			var oCountry = oHeaderData.Country;
			if(oControl.data("flag") !== "HeaderInfoCustomer" ){
				this.customerInput = oControl.data("flag");
				this.Customer = {};
				this.Customer.SelectedCustomerFldId = oControl.getId();
				this.Customer.SelectedCustomerFldIdx = oControl.getBindingContext("EditModel").sPath.split("/")[2];
				oFliters = [new Filter("Country", "EQ", oCountry)];
			}else{
				this.customerInput = oControl.data("flag");
				this.Customer = {};
				this.Customer.SelectedCustomerFldId = oControl.getId();
				this.Customer.SelectedCustomerFldIdx = oControl.getBindingContext().getPath();
				if(oCountry === ""){
					var oCountryId = sap.ui.getCore().byId("idCountry");
					var oKey = oCountryId.getSelectedKey();
					if(oKey !== "US"){
						oCountryId.setSelectedKey("US");
					}
					oFliters = [new Filter("Country", "EQ", oCountryId.getSelectedKey())];
				}else{
					oFliters = [new Filter("Country", "EQ", oCountry)];
				}
			}
			var oList = sap.ui.getCore().byId("idCustomerList");
			var oTemplate = new sap.m.StandardListItem({
				title: "{Customer}",
				description: "{Name}"
			});
			oList.bindAggregation("items", "/PartnerValueHelpSet", oTemplate);
			oList.getBinding("items").filter(oFliters);
            if(oCountry !== ""){
				oCountryModel.setProperty("/SelectedCountry", oCountry);
            }

			//CustomData to handle Asset H5#, H5 Name, HQ Pay & Summary Bill inputs
			var oCustomData = new sap.ui.core.CustomData({
				key: "SrcInputContext"
			});
			oCustomData.setValue(oControl.getBindingContext("EditModel") + "/" + oControl.getBindingPath("value"));
			oList.addCustomData(oCustomData);
		},

		/**
		 * @param {event} oEvent - Customer VH Selected list listitem press
		 * In this function, we are adding selected Customer to FlatFee table.
		 */
		onCustomerVHConfirm: function (oEvent, oFirstItem) {
			var src = oEvent.getSource();
			var oSelctedItem;
			if (oEvent.getSource()) {
				oSelctedItem = oEvent.getParameter("listItem");
			}
			var oSelctedItemTitle, oSelctedItemDescription;
			if (!oSelctedItem) {
				oSelctedItemTitle = oFirstItem.Customer;
				oSelctedItemDescription = oFirstItem.Name;
			} else {
				oSelctedItemTitle = oSelctedItem.getTitle();
				oSelctedItemDescription = oSelctedItem.getDescription();
			}
			var aEditModel = this.getView().getModel("EditModel");

			var aCustomData = src?src.getCustomData():false;
			
			//Code for Asset view in Price tab and Discounts off Table. This new way of code added after initial development of PriceException and Flatfee
			if (aCustomData && (this._getCustomDataValue(aCustomData, "SrcInputContext").indexOf("EditableAssets") !== -1)) {
				aEditModel.setProperty(this._getCustomDataValue(aCustomData, "SrcInputContext"), oSelctedItemTitle);

				if (this._getCustomDataValue(aCustomData, "SrcInputContext").indexOf("CustomerNumber") !== -1) {
					aEditModel.setProperty(this._getCustomDataValue(aCustomData, "SrcInputContext").replace("CustomerNumber", "CustomerDesc"), oEvent
						.getParameter("listItem").getProperty("description"));
				}
				aEditModel.updateBindings(false);
			}
			else {
				var iSelectedCustomerFldId = this.Customer.SelectedCustomerFldIdx;
				var oEditPriceExpTable, oEditDiscountOffTable, aEditableOnInvoiceDiscountSet,oEditOnInvoiceDiscountTable, aEditablePriceExceptions, aEditableFlatFee, oEditFlatFee, aEditableDiscountOffSet;
				if (this.customerInput === "FlatFeeCustomer") {
					aEditableFlatFee = aEditModel.getProperty("/EditableFlatFee");
					oEditFlatFee = this.getView().byId("EditFlatFeeTable");
					if (!this._getIsDuplicateFlatFee("Customer", oSelctedItemTitle, aEditableFlatFee)) {
						aEditModel.setProperty("/EditableFlatFee/" + iSelectedCustomerFldId + "/CustomerNumber", oSelctedItemTitle);
						aEditModel.setProperty("/EditableFlatFee/" + iSelectedCustomerFldId + "/CustomerDesc", oSelctedItemDescription);
						aEditModel.setProperty("/EditableFlatFee/" + iSelectedCustomerFldId + "/CustomerEditable", false);
					} else {
						this._deleteRecordOnDuplicateInFlatFeeEntry(oEditFlatFee, aEditableFlatFee, iSelectedCustomerFldId);
						aEditModel.checkUpdate(true);
					}
				}
				else if (this.customerInput === "PriceExpCustomer") {
					aEditablePriceExceptions = aEditModel.getProperty("/EditablePriceExceptions");
					oEditPriceExpTable = this.getView().byId("EditPriceExcepTable");
					if (!this._getIsDuplicatePriceExp("Customer", oSelctedItemTitle, aEditablePriceExceptions)) {
						aEditModel.setProperty("/EditablePriceExceptions/" + iSelectedCustomerFldId + "/CustomerNumber", oSelctedItemTitle);
						aEditModel.setProperty("/EditablePriceExceptions/" + iSelectedCustomerFldId + "/CustomerDesc", oSelctedItemDescription);
						aEditModel.setProperty("/EditablePriceExceptions/" + iSelectedCustomerFldId + "/CustomerEditable", false);
					} else {
						this._deleteRecordOnDuplicateEntry(oEditPriceExpTable, aEditablePriceExceptions, iSelectedCustomerFldId);
						aEditModel.checkUpdate(true);
					}
				}else if (this.customerInput === "DiscountsOffCustomer") {
					aEditableDiscountOffSet = aEditModel.getProperty("/EditableDiscountOffSet");
					oEditDiscountOffTable = this.getView().byId("DiscountOffTable");
					if (!this._getIsDuplicateDiscountOff("Customer", oSelctedItemTitle, aEditableDiscountOffSet)) {
						aEditModel.setProperty("/EditableDiscountOffSet/" + iSelectedCustomerFldId + "/CustomerNumber", oSelctedItemTitle);
						aEditModel.setProperty("/EditableDiscountOffSet/" + iSelectedCustomerFldId + "/CustomerDesc", oSelctedItemDescription);
						aEditModel.setProperty("/EditableDiscountOffSet/" + iSelectedCustomerFldId + "/CustomerEditable", false);
					} else {
						this._deleteRecordOnDuplicateEntry(oEditDiscountOffTable, aEditableDiscountOffSet, iSelectedCustomerFldId);
						aEditModel.checkUpdate(true);
					}
				}else if (this.customerInput === "OnInvoiceDiscountsCustomer") {
					aEditableOnInvoiceDiscountSet = aEditModel.getProperty("/EditableOnInvoiceDiscountSet");
					oEditOnInvoiceDiscountTable = this.getView().byId("IdOnInvoiceDiscountTable");
					if (!this._getIsDuplicateOnInvoiceDiscounts("Customer", oSelctedItemTitle, aEditableOnInvoiceDiscountSet)) {
						aEditModel.setProperty("/EditableOnInvoiceDiscountSet/" + iSelectedCustomerFldId + "/CustomerNumber", oSelctedItemTitle);
						aEditModel.setProperty("/EditableOnInvoiceDiscountSet/" + iSelectedCustomerFldId + "/CustomerDesc", oSelctedItemDescription);
						aEditModel.setProperty("/EditableOnInvoiceDiscountSet/" + iSelectedCustomerFldId + "/CustomerEditable", false);
					} else {
						this._deleteRecordOnDuplicateEntry(oEditOnInvoiceDiscountTable, aEditableOnInvoiceDiscountSet, iSelectedCustomerFldId);
						aEditModel.checkUpdate(true);
					}
				}
				
				if (this._CustomerValueHelpDialog) {
					sap.ui.getCore().byId("idCustomerNumber").setValue("");
					sap.ui.getCore().byId("idCustomerDesc").setValue("");
				}
			}
			if(this.customerInput === "HeaderInfoCustomer"){
				var oModel = this.getView().getModel();
				oModel.setProperty(this.Customer.SelectedCustomerFldIdx + "/ValueFields/BusinessPartner", oSelctedItemTitle);
				oModel.setProperty(this.Customer.SelectedCustomerFldIdx + "/TextFields/BusinessPartner", oSelctedItemDescription);
			}
			if(this._CustomerValueHelpDialog)
			{
				this._CustomerValueHelpDialog.close();
			}
		},

		/**
		 * @param {oEvent} oEvent - Customer VH popup cancel button press
		 * In this function, we are closing the Customer VH Popup.
		 */
		onCustomerVHCancelPress: function () {
			sap.ui.getCore().byId("idCustomerNumber").setValue("");
			sap.ui.getCore().byId("idCustomerDesc").setValue("");
			this._CustomerValueHelpDialog.close();
		},

		/**
		 * @param {oEvent} oEvent - Customer VH popup Search 
		 * In this function, we are searching on Customer,Name and Country.
		 */
		onCustomerVHSearch: function (oEvent) {
			var nCustomerNumber = sap.ui.getCore().byId("idCustomerNumber").getValue();
			var nCustomerDesc = sap.ui.getCore().byId("idCustomerDesc").getValue();
			var nCountry = sap.ui.getCore().byId("idCountry").getSelectedKey();
			var aCustomerFilter = [];
			if (nCustomerNumber !== "") {
				aCustomerFilter.push(new Filter("Customer", "Contains", nCustomerNumber));
			}
			if (nCustomerDesc !== "") {
				aCustomerFilter.push(new Filter("Name", "Contains", nCustomerDesc));
			}
			if (nCountry !== "") {
				aCustomerFilter.push(new Filter("Country", "EQ", nCountry));
			}
			sap.ui.getCore().byId("idCustomerList").getBinding("items").filter(aCustomerFilter);
		},

		/**
		 * @param {event} oEvent - event of FlatFee table ConditionType Column change 
		 * This function is to set ProgramTypeDesc input enabled or Disabled 
		 */
		onConditionType: function (oEvent) {
			this.clearInputErrorState(oEvent);
			var oView = this.getView();
			var oModel = oView.getModel("EditModel");
			var aEditModel = oModel.getProperty("/EditableFlatFee");
			var oSelectedCustomerFldIdx = oEvent.getSource().getBindingContext("EditModel").sPath.split("/")[2];
			var oKey = oEvent.getSource().getSelectedKey();
			if (oKey === "ZFTP668" || oKey === "Z1MP668") {
				aEditModel[oSelectedCustomerFldIdx].ProgramTypeDescEnable = true;
				aEditModel[oSelectedCustomerFldIdx].FlatFeeEnable = true;
			} else if (oKey === "ZFTP758") {
				aEditModel[oSelectedCustomerFldIdx].BillingDay = "";
				aEditModel[oSelectedCustomerFldIdx].BillingFrequency = "";
				aEditModel[oSelectedCustomerFldIdx].ProgramTypeDescEnable = false;
				aEditModel[oSelectedCustomerFldIdx].ProgramTypeDesc="";
				aEditModel[oSelectedCustomerFldIdx].ProgramTypeDescState="None";
				aEditModel[oSelectedCustomerFldIdx].FlatFeeEnable = true;
			}
			oModel.updateBindings(true);
		},
		
		/**
		 * Function to hide/show  PriceGroup/MaterialNumber inputs of DiscoutOff table row. This is done
		 * based on condition type selection
		 * @private
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		 onDiscountsOffConditionType: function (oEvent) {
			this.clearInputErrorState(oEvent);
			var oView = this.getView();
			var oModel = oView.getModel("EditModel");
			var aEditModel = oModel.getProperty("/EditableDiscountOffSet");
			var oSelectedDiscountOffIdx = oEvent.getSource().getBindingContext("EditModel").sPath.split("/")[2];
			var oKey = oEvent.getSource().getSelectedKey();
			if (oKey === "Z1PD657") {
				aEditModel[oSelectedDiscountOffIdx].MaterialNumber = "";
				aEditModel[oSelectedDiscountOffIdx].MaterialNumberState = "None";
			} else if (oKey === "Z1PD758") {
				aEditModel[oSelectedDiscountOffIdx].PriceGroup = "";
				aEditModel[oSelectedDiscountOffIdx].PriceGroupState = "None";
			}
			oModel.updateBindings(true);
		},
		
		/**
		 * Function to hide/show  PriceGroup/MaterialNumber inputs of OnInvoiceDiscounts table row. This is done
		 * based on condition type selection
		 * @private
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		onOnInvoiceDiscountsConditionType: function (oEvent) {
			this.clearInputErrorState(oEvent);
			var oView = this.getView();
			var oModel = oView.getModel("EditModel");
			var aEditModel = oModel.getProperty("/EditableOnInvoiceDiscountSet");
			var oSelectedOnInvoiceDiscountIdx = oEvent.getSource().getBindingContext("EditModel").sPath.split("/")[2];
			var oKey = oEvent.getSource().getSelectedKey();
			if (oKey === "Z1VL657") {
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerEditable = true;
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerNumberState="None";
				aEditModel[oSelectedOnInvoiceDiscountIdx].PriceGroupState="None" ;
			} else if (oKey === "Z1VL662") {
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerEditable = true;
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerNumberState="None";
				aEditModel[oSelectedOnInvoiceDiscountIdx].MaterialTypeState="None" ;
			}else if (oKey === "Z1VL976") {
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerEditable = true;
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerNumberState="None";
			}else if (oKey === "Z1VR657") {
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerEditable = true;
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerNumberState="None";
				aEditModel[oSelectedOnInvoiceDiscountIdx].PriceGroupState="None" ;
			}
			else if (oKey === "Z1VR654") {
				aEditModel[oSelectedOnInvoiceDiscountIdx].CustomerEditable = true;
			}
			oModel.updateBindings(true);
		},
		
		/**
		 * Function to limit DiscountOff table rate input value 
		 * @private
		 * @param {sap.ui.base.Event} oEvent event object
		 */
		 limitDiscountOffRateValue : function(oEvent){
		 	var oSrcControl = oEvent.getSource();
		 	var inputVal = oSrcControl.getValue();
		 	if(inputVal && !isNaN(inputVal)){
		 		var nValue = parseInt(oSrcControl.getValue());
		 		if(nValue > 99.99 || nValue < -99.99){
		 			oSrcControl.setValue(oSrcControl.getBindingContext("EditModel").getObject().rateOldValue);
		 		}else{
		 			oSrcControl.getBindingContext("EditModel").getObject().rateOldValue = nValue;
		 		}
		 	}
		 	
		 },

		/**
		 * @param {sap.ui.base.Event} oEvent - event of FlatFee,Price exception table Sold To # Colulmn change 
		 * This function is to get entered Customer details
		 */
		onCustomerNumberChange: function (oEvent) {
			this.clearInputErrorState(oEvent);
			var oControl = oEvent.getSource();
			var sEnteredCustNum = oControl.getValue();
			
			if(sEnteredCustNum && sEnteredCustNum.trim() !== ""){
				var oEditPriceExpPanel = this.getView().byId("EditPriceExpPanel");
				oEditPriceExpPanel.setBusy(true);
				this.customerInput = oControl.data("flag");
				var oContext = oControl.getBindingContext("EditModel");
				if (!this.Customer) {
					this.Customer = {};
				}
				if(oContext){
					this.Customer.SelectedCustomerFldIdx = oContext.sPath.split("/")[2];
				} else {
					this.Customer.SelectedCustomerFldIdx = oControl.getBindingContext().sPath;
				}
				var oEditModel = oControl.getModel("EditModel");
				var aFilter = [
							new Filter("Customer", "Contains", sEnteredCustNum?sEnteredCustNum.trim():"")
				];
				this._callPartnerValueHelpSet(oEditModel, aFilter, oEvent);
				oEditPriceExpPanel.setBusy(false);
				if(this.customerInput !== "HeaderInfoCustomer"){
					this.populateConditionInput(oEvent);
				}
			}else{
				oControl.setValue("");
			}
		},

		/**
		 * @param {object} oModel - oData Model to make read call
		 * @param {object} oEditModel - EditModel object
		 * @param {array} aFilter - Filters array Customer Number/Country
		 * In this function, we are reading /PartnerValueHelpSet based on the search cretieria.
		 */
		_callPartnerValueHelpSet: function (oEditModel, aFilter, oEvent) {
			var me = this;
			var oModel=this.getView().getModel();
			oModel.read("/PartnerValueHelpSet",{
				filters: aFilter,
				async:false,
			 	success: function a(oData) {
					if (oData.results.length > 0) {
						me.onCustomerVHConfirm(oEvent, oData.results[0]);
					}
				},
				error: function (oError) {
					oEditModel.setProperty("/MaterialSearch/tableBusy", false);
					//To Do - Error handling
				}
			});
		},

		/**
		 * In this function, we are reading records from uploaded excel file. 
		 * We are reading values based on the column position.
		 * * A - Materail
		 * * B - Rate
		 * * C - Per
		 * * D - 100% Disc = Y/N
		 * * E - Program Type
		 * * F - Freight Incl
		 * * G - Bid
		 * * H - On Orig Agreement
		 */
		onProductsUpload: function (oEvent) {
			var me = this;
			var oProductsFileUploader = this.getView().byId("idProductsFileUploader");
			var oView = this.getView();
			var oEditModel = oView.getModel("EditModel");
			var aProductsData = oEditModel.getProperty("/EditableProducts");

			var oDate = new Date();
			var _prepareProductsFromFileRecords = function (aRecords) {
				//START Prepare products table existing content for upload
				var aEditProducts = oEditModel.getProperty("/EditableProducts");

				//Preparing Products payload
				var aProductResults = [];
				aEditProducts.forEach(function (oProduct, idx) {
				aProductResults.push({
						"DocumentNumber": oProduct.DocumentNumber,
						"MaterialNumber": oProduct.MaterialNumber,
						"ValidFrom": oProduct.ValidFrom,
						"ValidTo": oProduct.ValidTo,
						"MaterialDesc": oProduct.MaterialDesc,
						"Rate": oProduct.NewRate + "",
						"Per": oProduct.NewPer,
						"Currency": oProduct.Currency,
						"ConditionType": oProduct.NewConditionType,
						"ConditionKey": oProduct.NewConditionKey,
						"ConditionDesc": oProduct.NewConditionDesc,
						"ConditionNumber": oProduct.ConditionNumber,
						"ConditionNumber2": oProduct.ConditionNumber2,
						"Unit": oProduct.Unit,
						"OriginalAgreement": oProduct.NewOriginalAgreement,
						"GovtBids": oProduct.NewGovtBids,
						"PriceInclFreight": oProduct.NewPriceInclFreight,
						"SearchField": "",
						"ChangeFlag": oProduct.ProductChanged,
						"Message": oProduct.Message,
						"Upload": {
							"MaterialNumber": "",
							"Rate": "",
							"Per": "",
							"Has100PercDisc": "",
							"PriceGroup": "",
							"PriceInclFreight": "",
							"GovtBids": "",
							"OriginalAgreement": ""
						}
					});
				});
				//END Prepare products table existing content for upload

				//START Prepare products from uploaded excel sheet
				for (var index = 0; index < aRecords.length; index++) {
					if (index === 0) {
						continue;
					}
					if (index === 1 && aRecords[index]["A" + Number(index + 1)] && isNaN(aRecords[index]["A" + Number(index + 1)]) && (aRecords[
							index]["A" + Number(index + 1)]).startsWith("Material")) {
						continue;
					}

					var materialNumber = "" + (10000000 + index);
					aProductResults.push({
						"DocumentNumber": "",
						"MaterialNumber": "$000000000" + materialNumber.substring(1),
						"ValidFrom": me.oDateFormat.format(oDate),
						"ValidTo": me.oDateFormat.format(oDate),
						"MaterialDesc": "",
						"Rate": "0",
						"Per": "",
						"Currency": "",
						"ConditionType": "",
						"ConditionKey": "",
						"ConditionDesc": "",
						"ConditionNumber": "",
						"ConditionNumber2": "",
						"Unit": "",
						"OriginalAgreement": false,
						"GovtBids": false,
						"PriceInclFreight": false,
						"SearchField": "",
						"ChangeFlag": "L",
						"Message": "",
						"Upload": {
							"MaterialNumber": aRecords[index]["A" + Number(index + 1)],
							"Rate": aRecords[index]["B" + Number(index + 1)],
							"Per": aRecords[index]["C" + Number(index + 1)],
							"Has100PercDisc": aRecords[index]["D" + Number(index + 1)],
							"PriceGroup": aRecords[index]["E" + Number(index + 1)],
							"PriceInclFreight": aRecords[index]["F" + Number(index + 1)],
							"GovtBids": aRecords[index]["G" + Number(index + 1)],
							"OriginalAgreement": aRecords[index]["H" + Number(index + 1)]
						}
					});
				}
				//END Prepare products from uploaded excel sheet

				var oHeaderInfoPayload = me._prepareHeaderInfoPayload(me.getView());
				var oPayload = me._preparePricingPayload(oHeaderInfoPayload);
				//Merging Product json to Header Info payload
				oPayload.ProductSet.results = aProductResults;
				oPayload.AssetSet.results = [];
				var oModel = oView.getModel();
				oModel.setHeaders({
					'UPLOAD': 'X'
				});
				oModel.create("/HeaderSet", oPayload, {
					method: "POST",
					success: function (oData, oResponse) {
						oModel.setHeaders({});
						me._prepareDataForPricingTab(oData.ProductSet.results);

						//Error dialogue if there any product has errors
						if (me._hasProductsWithErrors(oData.ProductSet.results)) {
							MessageBox.error(me.bundle.getText("ProdUpdGenericError"), {
								title: me.bundle.getText("Error"),
								actions: [MessageBox.Action.OK]
							});
						}

						var EditProductsTable = oView.byId("EditProductsTable");
						EditProductsTable.setFirstVisibleRow(aProductsData.length - 1);
					},
					error: function (error, resp) {
						oModel.setHeaders({});
					}
				});
			};
			this._getFileRecords(oEvent, oProductsFileUploader, _prepareProductsFromFileRecords);
		},

		/**
		 * Shows up error message box one clicking of error icon of product inside pricing tab
		 * @function
		 * @param {sap.ui.base.Event} oEvent
		 * @private
		 */
		handleMessagePress: function (oEvent) {
			var me = this;
			var src = oEvent.getSource();
			if (!me._oPopover) {
				me._oPopover = sap.ui.xmlfragment("com.ecolab.ZASBMasterAgr.fragment.edit.MessagePopover", me);
				me.getView().addDependent(me._oPopover);
			}
			sap.ui.getCore().byId("ProductMessagePopover").setText(src.getTooltip());
			me._oPopover.openBy(src);
		},
		handleCloseButton: function (oEvent) {
			this._oPopover.close();
		},
		_getUploadedConditionKey: function (sDiscount, sProgramType) {
			if (sDiscount === "Y" && sProgramType && sProgramType.trim().length === 0) {
				return "ZF00";
			} else if (sDiscount === "Y" && sProgramType && sProgramType.trim().length !== 0) {
				//Show Error
				MessageBox.error(this.bundle.getText("ConditionTypeErrorMsg"), {
					title: this.bundle.getText("Error"),
					actions: [MessageBox.Action.OK]
				});
				return "Error";
			} else if (sDiscount && sDiscount.trim().length === 0 && sProgramType && sProgramType.trim().length > 0) {
				return "ZFCP" + sProgramType;
			}
		},

		/**
		 * Function that set CustomData value of given key
		 * @param {Array} aCustomData Array of CustomData objects
		 * @param {String} key CustomData key to retrive CustomData Value
		 * @param {String} value key to retrive CustomData Value
		 * @private
		 */
		 
		_setCustomDataValue: function (aCustomData, key, value) {
			aCustomData.forEach(function (oCustomData, idx) {
				if (oCustomData.getKey().trim() === key) {
					oCustomData.setValue(value);
				}
			});
		},
		
		/**
		 * function that return CustomData value of given key
		 * @param {Array} aCustomData Array of CustomData objects
		 * @param {String} key CustomData key to retrive CustomData Value
		 * @private
		 * @return {String} customValue
		 */
		_getCustomDataValue: function (aCustomData, key) {
			var customValue = "";
			aCustomData.forEach(function (oCustomData, idx) {
				if (oCustomData.getKey().trim() === key) {
					customValue = oCustomData.getValue();
				}
			});
			return customValue;
		},

		/*Using 3rd party JS lib to read uploaded Excel file to JSON model*/
		_getFileRecords: function (e, oFileUploader, _prepareProductsFromFileRecords) {
			var ome = this;
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			//Getting lube Products and uploading
			var reader = new FileReader();
			var key = "";
			var me = this;
			var roa = [];
			var lubesJson = {};
			//var name = f.name;
			reader.onload = function (e) {
				var data = e.target.result;
				/* if binary string, read with type 'binary' */
				var result;
				var workbook = XLSX.read(data, {
					type: 'binary'
				});
				/* DO SOMETHING WITH workbook HERE */
				workbook.SheetNames.forEach(function (sheetName) {
					roa = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
				});
				roa.forEach(function (j, k) {
					// Iterate over the keys of object
					Object.keys(j).forEach(function (key) {
						// Copy the value
						var val = j[key],
							newKey = key.replace(/\s+/g, '_');
						// Remove key-value from object
						delete roa[k][key];
						// Add value with new key
						roa[k][newKey] = val;
					});
				});
				_prepareProductsFromFileRecords(roa);
			};
			reader.readAsArrayBuffer(file);
		},
		
		/**
		 * Function is called when click on delete attachment icon
		 * and it deletes the attachment from the list
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onAttachmentDeletePress: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel();
			that.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var currentObject = oEvent.getSource().getBindingContext().getObject();
			var sPath = "/AttachmentSet(ObjectNumber='" + currentObject.ObjectNumber + "',FileID='" + currentObject.FileID + "')";
			sap.m.MessageBox.confirm(that.bundle.getText("attachmentDeleteWarning", [oEvent.getSource().getFileName()]), {
				title: that.bundle.getText("confirmation"),
				icon: sap.m.MessageBox.Icon.WARNING,
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (sAction) {
					if (sAction === that.bundle.getText("confirmYes")) {
						oModel.remove(sPath, {
							success: function () {
								sap.m.MessageToast.show(that.bundle.getText("attachmentDeleted"));
							},
							error: function (oError) {
								sap.ui.getCore().getMessageManager().removeAllMessages();
								that.handleSucessWarningMsgs("",oError);
							}
						});
					}
				}
			});
		},
		/**
		 * Function is called before uploading of an attachment
		 * and to set request headers while uploading
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onUploadChange: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel();
			var token = this.getCSRFToken(oModel);
			oEvent.getSource().setUploadUrl(oModel.sServiceUrl + "/AttachmentSet");
			oEvent.getSource().removeAllHeaderParameters();
			oEvent.getSource().addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "slug",
				value: oEvent.getSource().getValue() + "|" + this.sDocumentNumber
			}));
			oEvent.getSource().addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: token
			}));

			//Code to get the file type and based on that content-type is retrived
			var fileName = oEvent.getSource().getValue();
			var fileType = (fileName.split(".")[fileName.split(".").length-1]).toLowerCase();
			//Adding content-type manually from UI for only .msg file types because browser is not picking automatically
			if(fileType === "msg"){
				oEvent.getSource().addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "Content-Type",
					value: that.fileTypeToMimeType[fileType]
				}));
			}
			oEvent.getSource().setSendXHR(true);
			oEvent.getSource().upload();

		},
		
		/**
		 * Function is called if uploading of an attachment is unsuccessful
		 * and shows warning message 
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onUploadAborted: function (oEvent) {
			var oSource = oEvent.getSource();
		},
		
		/**
		 * Function is called if uploading of an attachment is completed
		 * and shows latest data
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onAprvalAtchmntsUploadComplete: function (oEvent) {
			var that = this;
			that.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var attachmentsListItems = that.getView().byId("idMAAtchmntsUploadCollection").getItems();
			var arrAtchmntFilters = [];
			arrAtchmntFilters.push(
				new Filter({
					path: "ObjectNumber",
					operator: "EQ",
					value1: this.sDocumentNumber
				}));
			if(oEvent.getParameters().status.toString().slice(0,1) === "2"){
				that.getView().byId("idMAAtchmntsUploadCollection").getBinding("items").filter(arrAtchmntFilters);
				sap.ui.getCore().getMessageManager().removeAllMessages();
				that.getView().getModel().attachEventOnce("batchRequestCompleted",function(oControlEvent){
				 	if(that.getView().byId("idMAAtchmntsUploadCollection").getItems().length > attachmentsListItems.length && oControlEvent.getParameter("success")){
						sap.m.MessageToast.show(that.bundle.getText("attachmentSuccess", [that.sDocumentNumber]));
					} else {
						sap.m.MessageBox.show(that.bundle.getText("attachmentFailed"), {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: ["OK"]
						});
					}
				},that);
			} else if(oEvent.getParameters().status.toString().slice(0,1) === "4" || oEvent.getParameters().status.toString().slice(0,1) === "5"){
				sap.ui.getCore().getMessageManager().removeAllMessages();
				sap.m.MessageBox.show(that.bundle.getText("errorText"), {
					title: that.bundle.getText("Error"),
					icon: sap.m.MessageBox.Icon.ERROR,
					actions: [sap.m.MessageBox.Action.OK]
				});
				that.handleSucessWarningMsgs("",oEvent.getParameters());
			}
		},
		
		/**
		 * Function is called if any invalid file format file is getting uploaded
		 * and it shows warning message 
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onTypeMissMatch: function (oEvent) {
			var that = this;
			that.bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var fileTypes = oEvent.getSource().getFileType().toString();
			sap.m.MessageBox.show(that.bundle.getText("invalidFileFormat", [fileTypes]), {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: "Error",
				actions: ["OK"]
			});
		},
		
		/**
		 * Function is called on click of FileName
		 * it download the attachment to the file-system
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onShowFileContent: function (oEvent) {
			var oSource = oEvent.getSource();
			var oDataModel = this.getView().getModel();
			var oCurrentObj = oSource.getBindingContext().getObject();
			window.open(oDataModel.sServiceUrl + "/AttachmentSet(ObjectNumber='" + oCurrentObj.ObjectNumber + "',FileID='" + oCurrentObj.FileID +
				"')/$value");
		},
		
		
		/**
		 * Function to retrive CSRF Token for upload call
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel - oModel object to retrive CSRF Token
		 * @private
		 * @returns {String} CSRF Token string
		 */
		getCSRFToken: function (oModel) {
			var sTokenName = "x-cs" + "rf-token"; // avoid static code check errors
			var sToken = oModel.getHeaders()[sTokenName];
			if (!sToken) {
				oModel.refreshSecurityToken(
					function (e, o) {
						sToken = o.headers[sTokenName];
					},
					function () {
						jQuery.sap.log.error("Could not get XSRF token");
					},
					false);
			}
			return sToken;
		},
		
		/**
		 * Function is called when click on Edit in the EditAgreement Notes tab
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onClickEdit: function (oEvent) {
			var oCore = this.getView();
			oCore.byId("idNoteText").setVisible(false);
			oCore.byId("idNoteTextArea").setVisible(true);
			oCore.byId("idNoteDone").setVisible(true);
			oEvent.getSource().setVisible(false);
		},
		/**
		 * Function is called when click on Done after edit in the EditAgreement Notes tab
		 * @param {sap.ui.base.Event} oEvent - the click event.
		 * @private
		 */
		onClickDone: function (oEvent) {
			var oSource = oEvent.getSource();
			var oCore = this.getView();
			oCore.byId("idNoteText").setVisible(true);
			oCore.byId("idNoteTextArea").setVisible(false);
			oCore.byId("idNoteEdit").setVisible(true);
			oSource.setVisible(false);
		},
		
		/**
		 * Method to load data from the oDatamodel to JSONModel for Attachments
		 * @private
		 */
		_getDataForAttachments: function(){
			var me = this;
			var oView = me.getView();
			var arrAtchmntFilters = [];
			arrAtchmntFilters.push(
				new Filter({
					path: "ObjectNumber",
					operator: "EQ",
					value1: this.sDocumentNumber
				}));
			oView.byId("idMAAtchmntsUploadCollection").getBinding("items").filter(arrAtchmntFilters);
		},
		/**
		 * Method to load data from the oDatamodel to JSONModel
		 * @private
		 */
		_getNotesData: function () {
			var oView = this.getView();
			var oDataModel = oView.getModel();
			var oNotesModel = oView.getModel("NotesModel");
			var RevisionNumber = this.sDocumentNumber;
			if (RevisionNumber !== "" && RevisionNumber !== undefined) {
				var sPath = "/ManagementNoteSet('" + RevisionNumber + "')";
				oDataModel.read(sPath, {
					success: function (oData, oRes) {
						oNotesModel.setProperty("/Notes", oData);
					},
					error: function (data) {
					}
				});
			}
		},
		/**
		 * Function is called when click on trash icon in the header part of the Edit Agreement Page
		 * Method to end the agreement
		 * @param {sap.ui.base.Event} oEvent the click event.
		 * @private
		 */
		onEndingAgreement: function (oEvent) {
			var that = this;
			var changeEffectiveDate = oEvent.getSource().getBindingContext().getObject().ValueFields.EffectiveChangeDate;
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd MMM YYYY",
				UTC: true
			});
			changeEffectiveDate = oDateFormat.format(new Date(changeEffectiveDate));
			sap.m.MessageBox.confirm(that.bundle.getText("WarningEndingAgreementMsg", [changeEffectiveDate, changeEffectiveDate]), {
				title: that.bundle.getText("Confirm"),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
				onClose: function (sAction) {
					if (sAction === that.bundle.getText("Ok")) {
						that.EndAgreement = true;
						that._getApprovalNotesDialog().open();
					}
				
				}
			});
		},
		
		/**
		 * Function that invoied during init. This function prepares filetype to content type 
		 * map that is used in file upload
		 * @private
		 */
		createFileTypeToContentTypeMap : function(){
			var me = this;
			me.fileTypeToMimeType = {};
			me.fileTypeToMimeType["jpg"] = "image/jpeg";
			me.fileTypeToMimeType["jpeg"] = "image/jpeg";
			me.fileTypeToMimeType["jpe"] = "image/jpeg";
			me.fileTypeToMimeType["gif"] = "image/gif";
			me.fileTypeToMimeType["png"] = "image/png";
			me.fileTypeToMimeType["bmp"] = "image/bmp";
			me.fileTypeToMimeType["tif"] = "image/tiff";
			me.fileTypeToMimeType["tiff"] = "image/tiff";
			me.fileTypeToMimeType["ico"] = "image/x-icon";
			
				//Videoformats
			me.fileTypeToMimeType["asf"] = "video/x-ms-asf";
			me.fileTypeToMimeType["asx"] = "video/x-ms-asf";
			me.fileTypeToMimeType["wmv"] = "video/x-ms-wmv";
			me.fileTypeToMimeType["wmx"] = "video/x-ms-wmx";
			me.fileTypeToMimeType["wm"] = "video/x-ms-wm";
			me.fileTypeToMimeType["avi"] = "video/avi";
			me.fileTypeToMimeType["divx"] = "video/divx";
			me.fileTypeToMimeType["flv"] = "video/x-flv";
			me.fileTypeToMimeType["mov"] = "video/quicktime";
			me.fileTypeToMimeType["qt"] = "video/quicktime";
			me.fileTypeToMimeType["mpeg"] = "video/mpeg";
			me.fileTypeToMimeType["mpg"] = "video/mpeg";
			me.fileTypeToMimeType["mpe"] = "video/mpeg";
			me.fileTypeToMimeType["mp4"] = "video/mp4";
			me.fileTypeToMimeType["m4v"] = "video/mp4";
			me.fileTypeToMimeType["ogv"] = "video/ogg";
			me.fileTypeToMimeType["webm"] = "video/webm";
			me.fileTypeToMimeType["mkv"] = "video/x-matroska";
				
				//Textformats
			me.fileTypeToMimeType["txt"] = "text/plain";
			me.fileTypeToMimeType["asc"] = "text/plain";
			me.fileTypeToMimeType["c"] = "text/plain";
			me.fileTypeToMimeType["cc"] = "text/plain";
			me.fileTypeToMimeType["h"] = "text/plain";
			me.fileTypeToMimeType["csv"] = "text/csv";
			me.fileTypeToMimeType["tsv"] = "text/tab-separated-values";
			me.fileTypeToMimeType["ics"] = "text/calendar";
			me.fileTypeToMimeType["rtx"] = "text/richtext";
			me.fileTypeToMimeType["css"] = "text/css";
			me.fileTypeToMimeType["htm"] = "text/html";
			me.fileTypeToMimeType["html"] = "text/html";
				
				//Audioformats
			me.fileTypeToMimeType["mp3"] = "audio/mpeg";
			me.fileTypeToMimeType["m4a"] = "audio/mpeg";
			me.fileTypeToMimeType["m4b"] = "audio/mpeg";
			me.fileTypeToMimeType["ra"] = "audio/x-realaudio";
			me.fileTypeToMimeType["ram"] = "audio/x-realaudio";
			me.fileTypeToMimeType["wav"] = "audio/wav";
			me.fileTypeToMimeType["ogg"] = "audio/ogg";
			me.fileTypeToMimeType["oga"] = "audio/ogg";
			me.fileTypeToMimeType["midi"] = "audio/midi";
			me.fileTypeToMimeType["mid"] = "audio/midi";
			me.fileTypeToMimeType["wma"] = "audio/x-ms-wma";
			me.fileTypeToMimeType["wax"] = "audio/x-ms-wax";
			me.fileTypeToMimeType["mka"] = "audio/x-matroska";
				
				//Miscapplicationformats
			me.fileTypeToMimeType["rtf"] = "application/rtf";
			me.fileTypeToMimeType["js"] = "application/javascript";
			me.fileTypeToMimeType["pdf"] = "application/pdf";
			me.fileTypeToMimeType["swf"] = "application/x-shockwave-flash";
			me.fileTypeToMimeType["class"] = "application/java";
			me.fileTypeToMimeType["tar"] = "application/x-tar";
			me.fileTypeToMimeType["zip"] = "application/zip";
			me.fileTypeToMimeType["gz"] = "application/x-gzip";
			me.fileTypeToMimeType["gzip"] = "application/x-gzip";
			me.fileTypeToMimeType["rar"] = "application/rar";
			me.fileTypeToMimeType["7z"] = "application/x-7z-compressed";
			me.fileTypeToMimeType["exe"] = "application/x-msdownload";
				
				//MSOfficeformats
			me.fileTypeToMimeType["doc"] = "application/msword";
			me.fileTypeToMimeType["pot"] = "application/vnd.ms-powerpoint";
			me.fileTypeToMimeType["pps"] = "application/vnd.ms-powerpoint";
			me.fileTypeToMimeType["ppt"] = "application/vnd.ms-powerpoint";
			me.fileTypeToMimeType["wri"] = "application/vnd.ms-write";
			me.fileTypeToMimeType["xla"] = "application/vnd.ms-excel";
			me.fileTypeToMimeType["xls"] = "application/vnd.ms-excel";
			me.fileTypeToMimeType["xlt"] = "application/vnd.ms-excel";
			me.fileTypeToMimeType["xlw"] = "application/vnd.ms-excel";
			me.fileTypeToMimeType["mdb"] = "application/vnd.ms-access";
			me.fileTypeToMimeType["mpp"] = "application/vnd.ms-project";
			me.fileTypeToMimeType["docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			me.fileTypeToMimeType["docm"] = "application/vnd.ms-word.document.macroEnabled.12";
			me.fileTypeToMimeType["dotx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.template";
			me.fileTypeToMimeType["dotm"] = "application/vnd.ms-word.template.macroEnabled.12";
			me.fileTypeToMimeType["xlsx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			me.fileTypeToMimeType["xlsm"] = "application/vnd.ms-excel.sheet.macroEnabled.12";
			me.fileTypeToMimeType["xlsb"] = "application/vnd.ms-excel.sheet.binary.macroEnabled.12";
			me.fileTypeToMimeType["xltx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.template";
			me.fileTypeToMimeType["xltm"] = "application/vnd.ms-excel.template.macroEnabled.12";
			me.fileTypeToMimeType["xlam"] = "application/vnd.ms-excel.addin.macroEnabled.12";
			me.fileTypeToMimeType["pptx"] = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
			me.fileTypeToMimeType["pptm"] = "application/vnd.ms-powerpoint.presentation.macroEnabled.12";
			me.fileTypeToMimeType["ppsx"] = "application/vnd.openxmlformats-officedocument.presentationml.slideshow";
			me.fileTypeToMimeType["ppsm"] = "application/vnd.ms-powerpoint.slideshow.macroEnabled.12";
			me.fileTypeToMimeType["potx"] = "application/vnd.openxmlformats-officedocument.presentationml.template";
			me.fileTypeToMimeType["potm"] = "application/vnd.ms-powerpoint.template.macroEnabled.12";
			me.fileTypeToMimeType["ppam"] = "application/vnd.ms-powerpoint.addin.macroEnabled.12";
			me.fileTypeToMimeType["sldx"] = "application/vnd.openxmlformats-officedocument.presentationml.slide";
			me.fileTypeToMimeType["sldm"] = "application/vnd.ms-powerpoint.slide.macroEnabled.12";
			me.fileTypeToMimeType["onetoc"] = "application/onenote";
			me.fileTypeToMimeType["onetoc2"] = "application/onenote";
			me.fileTypeToMimeType["onetmp"] = "application/onenote";
			me.fileTypeToMimeType["onepkg"] = "application/onenote";
			me.fileTypeToMimeType["msg"] = "application/vnd.ms-outlook";
				
				//OpenOfficeformats
			me.fileTypeToMimeType["odt"] = "application/vnd.oasis.opendocument.text";
			me.fileTypeToMimeType["odp"] = "application/vnd.oasis.opendocument.presentation";
			me.fileTypeToMimeType["ods"] = "application/vnd.oasis.opendocument.spreadsheet";
			me.fileTypeToMimeType["odg"] = "application/vnd.oasis.opendocument.graphics";
			me.fileTypeToMimeType["odc"] = "application/vnd.oasis.opendocument.chart";
			me.fileTypeToMimeType["odb"] = "application/vnd.oasis.opendocument.database";
			me.fileTypeToMimeType["odf"] = "application/vnd.oasis.opendocument.formula";
				
				//WordPerfectformats
			me.fileTypeToMimeType["wp"] = "application/wordperfect";
			me.fileTypeToMimeType["wpd"] = "application/wordperfect";
				
				//iWorkformats
			me.fileTypeToMimeType["key"] = "application/vnd.apple.keynote";
			me.fileTypeToMimeType["numbers"] = "application/vnd.apple.numbers";
			me.fileTypeToMimeType["pages"] = "application/vnd.apple.pages";
		}
	});
});
