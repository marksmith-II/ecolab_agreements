sap.ui.define([], function () {
	"use strict";
	return {
		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		/**
		 * Handles the Date Format in Master & Detail Pages
		 * @public
		 * @param {string} value is will be formattted 
		 * @returns {string} formatted value
		 */
		formatDate: function (value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance();
				var iDay = value.getUTCDate();
				var iMonth = value.getUTCMonth();
				var sDay = jQuery.sap.padLeft(String(iDay), "0", 2);
				var sMonth = oDateFormat.aMonthsAbbrev[iMonth];
				var sYear = String(value.getUTCFullYear());
				return sDay + " " + sMonth + " " + sYear;
			}

		},

		formatFlatFeeCurrency: function (rate, currency) {
			var oFormatOptions = {};
			if (currency === "USDN") {
				oFormatOptions = {
					minFractionDigits: 2,
					maxFractionDigits: 9
				};
			} else {
				oFormatOptions = {
					minFractionDigits: 2,
					maxFractionDigits: 6
				};
			}
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions);
			return oFloatFormat.format(rate);
		},

		/**
		 * Handle the i18n properties based on flag
		 * @public
		 * @param {boolean} we are getting flag from backend 
		 * @returns {string} i18n Property
		 */
		flagFormatter: function (flag) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (flag) {
				return resourceBundle.getText("Yes");
			} else {
				return resourceBundle.getText("No");
			}
		},

		/**
		 * Handle the Number format
		 * @private
		 * @param {String} we are getting Number  
		 * @returns {string} Number
		 */
		formatNumber: function (number) {
			var oFormatOptions = {
				minIntegerDigits: 1,
				maxIntegerDigits: 8,
				minFractionDigits: 2,
				maxFractionDigits: 4
			};

			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions);
			return oFloatFormat.format(number);
		},

		/**
		 * Handle the Edit Button Text in DetailPage HeaderInfo Section
		 * @private
		 * @param {Boolean} Here IsRevision is a boolean
		 * @param {Boolean} Here HasActiveRevision is a boolean
		 * @param {Boolean} Here IsEditable is a boolean
		 * @param {string} Here RevisionNumber is a string
		 * @returns {string} based on conditions
		 */

		editButtonTextFormat: function (IsRevision, HasActiveRevision, IsEditable, RevisionNumber) {

			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (IsRevision === false && HasActiveRevision === true && IsEditable === true) {
				var RevisionIsInDraft = resourceBundle.getText("RevisionIsInDraft");
				return RevisionIsInDraft.replace("#", RevisionNumber);

			} else if (IsRevision === false && HasActiveRevision === true && IsEditable === false) {
				var RevisionIsInProgress = resourceBundle.getText("RevisionIsInProgress");
				return RevisionIsInProgress.replace("#", RevisionNumber);

			}
		},
		editRBButtonTextFormat: function (IsRevision, HasActiveRevision, UserStatus, IsEditable, RevisionNumber) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (IsRevision && !IsEditable) {
				if (UserStatus === "E0001") {
					return resourceBundle.getText("RevisionInDraft");
				} else if (UserStatus === "E0005") {
					return resourceBundle.getText("RevisionReturn");
				} else if (UserStatus === "E0006") {
					return resourceBundle.getText("RevisonReadyForReview");
				} else if (UserStatus === "E0002") {
					return resourceBundle.getText("RevisonRequestForApproval");
				}
			} else if (IsRevision && IsEditable) {
				if (UserStatus === "E0001") {
					return resourceBundle.getText("RevisionInDraftClickToEditIsRevision");
				} else if (UserStatus === "E0005") {
					return resourceBundle.getText("RevisionReturnClickToEditIsRevision");
				} else if (UserStatus === "E0006") {
					return resourceBundle.getText("RevisonReadyForReviewClickToEditIsRevision");
				} else if (UserStatus === "E0002") {
					return resourceBundle.getText("RevisonIsRoutingForApprovalIsRevision");
				}
			} else if (!IsRevision && IsEditable && HasActiveRevision) {
				if (UserStatus === "E0001") {
					return resourceBundle.getText("RevisionInDraftClickToEdit", [RevisionNumber]);
				} else if (UserStatus === "E0005") {
					return resourceBundle.getText("RevisionReturnClickToEdit");
				} else if (UserStatus === "E0006") {
					return resourceBundle.getText("RevisonReadyForReviewClickToEdit");
				} else if (UserStatus === "E0002") {
					return resourceBundle.getText("RevisonHasBeenApprovalClickToView");
				}
			} else if (!IsRevision && !IsEditable && HasActiveRevision) {
				if (UserStatus === "E0001") {
					return resourceBundle.getText("RevisionInDraftClickToView", [RevisionNumber]);
				} else if (UserStatus === "E0005") {
					return resourceBundle.getText("RevisionReturnClickToView");
				} else if (UserStatus === "E0006") {
					return resourceBundle.getText("RevisonReadyForReviewClickToView");
				} else if (UserStatus === "E0002") {
					return resourceBundle.getText("RevisonHasBeenApprovalClickToView");
				}
			} else if (!IsRevision && !HasActiveRevision) {
				return resourceBundle.getText("Edit");
			}

		},

		/**
		 * Function to remove leading Zeros
		 * @private
		 * @param {string} Here str is a string
		 * @returns {string}
		 */

		trimLeadingZerosSubstr: function (str) {
			if (str) {
				var xLastChr = str.length - 1,
					xChrIdx = 0;
				while (str[xChrIdx] === "0" && xChrIdx < xLastChr) {
					xChrIdx++;
				}
				return xChrIdx > 0 ? str.substr(xChrIdx) : str;
			} else {
				return "";
			}
		},

		/**
		 * Function to set the i18n value if Notes is empty
		 * @private
		 * @param {string} Here Notes is a string
		 * @returns {string}
		 */
		handleEditNotesText: function (Notes) {
			var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (Notes === "") {
				return resourceBundle.getText("NoComments");
			} else {
				return Notes;
			}
		},
		formatMANavigation: function (IsViewable, IsStakeholder) {
			var Inactive = "Inactive";
			var Navigation = "Navigation";
			if (IsViewable === false) {
				return Inactive;
			} else if (IsViewable === true && IsStakeholder === true) {
				return Navigation;
			} else if (IsViewable === true && IsStakeholder === false) {
				return Navigation;
			}
		},
		/**
		 * Handle the Number format and if number is Zero then it will return empty
		 * @private
		 * @param {String} we are getting Number  
		 * @returns {string} Number
		 */
		formatMSLRate: function (number) {
			if (number !== "0.00") {
				var oFormatOptions = {
					minIntegerDigits: 1,
					maxIntegerDigits: 8,
					minFractionDigits: 2,
					maxFractionDigits: 4
				};

				var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions);
				return oFloatFormat.format(number);
			} else {
				number = "";
				return number;
			}
		},
		// To change FromScalesValues in Rebates Detail View   in the payout Rules Section
		formatFromNumber: function (number) {
			var oFormatOptions = {
				minIntegerDigits: 1,
				maxIntegerDigits: 15,
				minFractionDigits: 2,
				maxFractionDigits: 4
			};
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions);
			return oFloatFormat.format(number);
		},
		// To change ToScalesValues in Rebates Detail View  in the payout Rules Section
		formatToNumber: function (number) {
			if (number === "0.00") {
				return "+";
			} else {
				var oFormatOptions = {
					minIntegerDigits: 1,
					maxIntegerDigits: 8,
					minFractionDigits: 2,
					maxFractionDigits: 4
				};

				var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions);
				return oFloatFormat.format(number);
			}
		},
		// To change panel title based on Products or MSL pricing M.Smith
		headerName: function (value, value1, value2) {
			if (value === false) {
				return value1;
			} else if (value === true) {
				return value2 ;
			}
		}

	};
});