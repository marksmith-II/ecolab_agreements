sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel({
				isPhone: sap.ui.Device.system.phone
			});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFdModel: function () {
			/******************Master Filter Dialogue Model*****************/
			var oFilterModel = new JSONModel({
				"H5": "",
				"Description": "",
				"ExternalDescription": "",
				"validFrom": "",
				"validTo": "",
				"Status": [],
				"Owner": [],
				"Selectedkey": [],
				"Statuskey": []
			});
			return oFilterModel;
		},
		createProductModel: function () {
			/******************Products Filter Dialogue Model*****************/
			var oFilterModel = new JSONModel({
				"MaterialNum": "",
				"MaterialDesc": "",
				"Condition": "",
				"ConditionVal": "",
				"FreightIncl": "",
				"OnOrgAgmt": "",
				"Bid": "",
				"Status": []

			});

			return oFilterModel;
		},

		createProductStatusModel: function () {
			/******************Product Status dropdown Model*****************/
			var oProdStatusModel = new JSONModel({});

			return oProdStatusModel;
		}

	};

});