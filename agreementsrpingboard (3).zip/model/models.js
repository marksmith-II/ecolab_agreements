sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel({
				isPhone: sap.ui.Device.system.phone
			});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFdModel: function () {
			/******************Master Filter Dialogue Model*****************/
			var oFilterModel = new JSONModel({
				"H5": "",
				"Description": "",
				"ExternalDescription": "",
				"validFrom": "",
				"validTo": "",
				"Status": [],
				"Owner": [],
				"Selectedkey": [],
				"Statuskey": []
			});
			return oFilterModel;
		},
		createProductModel: function () {
			/******************Products Filter Dialogue Model*****************/
			var oFilterModel = new JSONModel({
				"MaterialNum": "",
				"MaterialDesc": "",
				"Condition": "",
				"ConditionVal": "",
				"FreightIncl": "",
				"OnOrgAgmt": "",
				"Bid": "",
				"Status": []

			});

			return oFilterModel;
		},
		createMslPricingModel: function () {
			/******************MLS Pricing Filter Dialogue Model*****************///M.Smith
			var oFilterModel = new JSONModel({
				"MaterialNumber": "",
				"MaterialDesc": "",
				"TierID": "",
				"TierRate": "",
				"Condition": "",
				"ConditionVal": "",
				"FreightIncl": "",
				"OnOrgAgmt": "",
				"Bid": "",
				"Status": []

			});

			return oFilterModel;
		},
		
		createMslHiddenFieldModel: function () {
			/******************MLS Hidden Fields Model*****************///M.Smith
			var oHiddenModel = new JSONModel({
				"HiddenField": false,
				"HiddenField2": false,
				"Editable": true 
				

			});

			return oHiddenModel;
},
		createProductStatusModel: function () {
			/******************Product Status dropdown Model*****************/
			var oProdStatusModel = new JSONModel({});

			return oProdStatusModel;
		},
		createDistBuyPriceModel: function () {
			/******************Dist Buy Price  Filter Dialogue Model*****************/
			var oDistBuyPriceFilterModel = new JSONModel();

			return oDistBuyPriceFilterModel;
		}

	};

});